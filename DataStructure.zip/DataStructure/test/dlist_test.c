#include "../include/dlist.h"
#include <assert.h>				/* To check the functions input */
#include <stdio.h>

#define UNUSED(x) (void)(x)

#define DUMMY 0xDEADBEEF

int IsEqualInt(const void *node_val, const void *param, const void *data)
{
	assert(node_val && param);
	
	UNUSED(data);
	
	return (*(int *)node_val == *(int *)param);
}

int PrintIntAndDefaultString(void *node_val, void *param)
{
	if (node_val && param)
	{
		printf("%d   %s\n", *(int *)node_val, (char *)param);
		
		return 1;
	}
	
	return 0;
}

void Test(void)
{
	cmp_func_t compare_func = &IsEqualInt;
	act_func_t print_func = &PrintIntAndDefaultString;
	
	dlist_t *dlist1 = DListCreate();
	dlist_t *dlist2 = DListCreate();
	
	dlist_iter_t *iter1 = NULL;
	dlist_iter_t *iter2 = NULL;
	dlist_iter_t *iter3 = NULL;
	dlist_iter_t *iter4 = NULL;
	dlist_iter_t *iter5 = NULL;
	dlist_iter_t *iter7 = NULL;
	
	int a = 10;
	int b = 11;
	int c = 12;
	int d = 13;
	int e = 14;
	int f = 500;
	int g = 501;
	int h = 502;
	
	if (!dlist1)
	{
		return;
	}
	if (!dlist2)
	{
		DListDestroy(dlist1);
		
		return;
	}

	assert(0 == DListSize(dlist1));
	assert(0 == DListSize(dlist2));
	assert(1 == DListIsEmpty(dlist1));
	assert(1 == DListIsEmpty(dlist2));

	assert((void *)DUMMY == DListGetData(DListBegin(dlist1)));
	assert((void *)DUMMY == DListGetData(DListBegin(dlist2)));
	assert((void *)DUMMY == DListGetData(DListEnd(dlist1)));
	assert((void *)DUMMY == DListGetData(DListEnd(dlist2)));
	
	assert(DListEnd(dlist1) == DListInsertAfter(dlist1, DListEnd(dlist1), &a));
	assert(0 == DListSize(dlist1));
	assert(1 == DListIsEmpty(dlist1));
	/*printf("a is %p  result is %p\n", &a, (DListGetData(DListInsert(dlist1, DListEnd(dlist1), &a))));*/
	iter1 = DListInsert(dlist1, DListEnd(dlist1), &a);
	assert(&a == (DListGetData(iter1)));
	assert(1 == DListSize(dlist1));
	assert(0 == DListIsEmpty(dlist1));
	iter2 = DListInsertAfter(dlist1, DListBegin(dlist1), &b);
	assert(&b == (DListGetData(iter2)));
	assert(2 == DListSize(dlist1));
	assert(0 == DListIsEmpty(dlist1));
	
	iter3 = DListInsert(dlist1, iter1, &c);
	assert(&c == (DListGetData(iter3)));
	assert(3 == DListSize(dlist1));
	assert(0 == DListIsEmpty(dlist1));
	
	assert(DListEnd(dlist1) == DListInsertAfter(dlist1, DListEnd(dlist1), &a));
	assert(3 == DListSize(dlist1));
	assert(0 == DListIsEmpty(dlist1));
	
	assert(DListIsSameIter(iter1, DListErase(iter3)));
	assert(2 == DListSize(dlist1));
	assert(0 == DListIsEmpty(dlist1));

	/*printf("a is %p  %p  result is %p\n",iter1,iter3, DListErase(iter2));*/
	assert(DListIsSameIter(iter2, DListErase(iter1)));
	assert(1 == DListSize(dlist1));
	assert(0 == DListIsEmpty(dlist1));
	assert(DListIsSameIter(DListEnd(dlist1), DListErase(iter2)));
	assert(0 == DListSize(dlist1));
	assert(1 == DListIsEmpty(dlist1));
	
	
	iter1 = DListPushBack(dlist1, &a);
	assert(&a == (DListGetData(iter1)));
	assert(1 == DListSize(dlist1));
	assert(0 == DListIsEmpty(dlist1));
	DListPopBack(dlist1);
	iter2 = DListPushFront(dlist1, &b);
	assert(&b == (DListGetData(iter2)));
	assert(1 == DListSize(dlist1));
	assert(0 == DListIsEmpty(dlist1));
	DListPopFront(dlist1);
	assert(0 == DListSize(dlist1));
	assert(1 == DListIsEmpty(dlist1));
	
	iter1 = DListPushBack(dlist1, &a);
	assert(&a == (DListGetData(iter1)));
	assert(1 == DListSize(dlist1));
	assert(0 == DListIsEmpty(dlist1));
	iter2 = DListPushFront(dlist1, &b);
	assert(&b == (DListGetData(iter2)));
	assert(2 == DListSize(dlist1));
	assert(0 == DListIsEmpty(dlist1));
	iter3 = DListPushBack(dlist1, &c);
	iter4 = DListPushBack(dlist1, &d);
	iter5 = DListPushBack(dlist1, &e);
	assert(5 == DListSize(dlist1));
	
	assert(DListIsSameIter(iter5, DListFind(dlist1, DListBegin(dlist1), DListEnd(dlist1), compare_func, &e, NULL)));
	assert(DListIsSameIter(DListEnd(dlist1), DListFind(dlist1, DListBegin(dlist1), iter4, compare_func, &d, NULL)));
	
	assert(1 == DListForEach(DListBegin(dlist1), DListEnd(dlist1), print_func, ":)"));
	puts("(:   (:");
	assert(1 == DListForEach(DListBegin(dlist1), iter1, print_func, ":)"));
		
	DListPushBack(dlist2, &f);
	iter7 = DListPushBack(dlist2, &g);
	DListPushBack(dlist2, &h);
	
	
	
	
	puts("Before Spice: First:");
	assert(1 == DListForEach(DListBegin(dlist1), DListEnd(dlist1), print_func, ":)"));
	puts("Before Spice: Second:");
	assert(1 == DListForEach(DListBegin(dlist2), DListEnd(dlist2), print_func, ":)"));
	DListSpliceBefore(iter7, iter2, iter5);
	puts("After Spice: First:");
	assert(1 == DListForEach(DListBegin(dlist1), DListEnd(dlist1), print_func, ":)"));
	puts("After Spice: Second:");
	assert(1 == DListForEach(DListBegin(dlist2), DListEnd(dlist2), print_func, ":)"));
	
	DListDestroy(dlist1);
	DListDestroy(dlist2);
	
	
	
	puts("(: ~~ OK ~~ :)");
}

int main()
{
	Test();
	
	return EXIT_SUCCESS;
}

