#include "../include/dlist.h"
#include "../include/sortedlist.h"

#include <stdio.h>
#include <stdlib.h> /* EXIT_SUCCESS */
#include <assert.h> /* assert */

#define UNUSED(x)(void)(x)

static void PrintList(const sorted_list_t *list);

static int AreEqual(const void *val, void *param);
static int PrintNum(void *val, void *param);
static int IsBefore(const void *data1, const void *data2, void *param);

void SortedListTest(void);
void MergeTest1(void);
void MergeTest2(void);
void MergeTest3(void);
void MergeTest4(void);

int main()
{
	SortedListTest();
	MergeTest1();	
	MergeTest2();	
	MergeTest3();	
	MergeTest4();
	
	return EXIT_SUCCESS;
}

/***********************************************************************/

void SortedListTest()
{
	int val2 = 12;
	int val3 = 4;
	int val4 = 9;
	int val5 = 1;
	int val6 = 10;

	int foreach = 0;
	void *removed = 0;

	sorted_list_iter_t erased = 0;
	sorted_list_iter_t found = 0;
	sorted_list_iter_t iter1 = 0;
	sorted_list_iter_t iter2 = 0;
	sorted_list_iter_t iter3 = 0;
	sorted_list_iter_t iter4 = 0;
	

	sorted_list_t *list = SortedListCreate(&IsBefore, NULL);
	
	puts("---------------- Empty DList ----------------------");	
	printf("\nSize of DList is: %lu\n", SortedListSize(list));
	assert(0 == SortedListSize(list));
	printf("Is DList empty? %s\n", (1 ==  SortedListIsEmpty(list)) ? "YES" : "NO");
	assert(1 == SortedListIsEmpty(list));

	puts("-------------- Insert test --------------------");	
	iter1 = SortedListInsert(list, &val4);
	iter2 = SortedListInsert(list, &val5);
	iter3 = SortedListInsert(list, &val2);

	printf("\nSize of DList is: %lu\n", SortedListSize(list));
	assert(3 == SortedListSize(list));
	printf("Is DList empty? %s\n", (0 ==  SortedListIsEmpty(list)) ? "YES" : "NO");
	assert(0 == SortedListIsEmpty(list));

	puts("-------------- Insert test ----------------------");		
	iter4 = SortedListInsert(list, &val3);

	puts("-------------- Begin test ----------------------");	
	printf("\nValue of first element is: %d\n", *(int *)SortedListGetData(SortedListBegin(list)));	
	assert(1 == *(int *)SortedListGetData(SortedListBegin(list)));
	
	puts("-------------- Prev test --------------------");
	printf("\nPrev element is: %d\n", *(int *)SortedListGetData(SortedListPrev(iter4)));
	assert(1 == *(int *)SortedListGetData(SortedListPrev(iter4)));
	printf("Prev element is: %d\n", *(int *)SortedListGetData(SortedListPrev(iter3)));
	assert(9 == *(int *)SortedListGetData(SortedListPrev(iter3)));
	
	puts("-------------- Next test --------------------");
	printf("\nNext element is: %d\n", *(int *)SortedListGetData(SortedListNext(iter4)));
	assert(9 == *(int *)SortedListGetData(SortedListNext(iter4)));
	printf("nNext element is: %d\n", *(int *)SortedListGetData(SortedListNext(iter2)));
	assert(4 == *(int *)SortedListGetData(SortedListNext(iter2)));

	puts("-------------- IsSame test --------------------");
	printf("\nIters same? %s\n", (1 == SortedListIsSameIter(iter1, iter2)) ? "YES" : "NO");
	assert(0 == SortedListIsSameIter(iter1, iter2));
	printf("Iters same? %s\n", (1 == SortedListIsSameIter(iter2, SortedListBegin(list))) ? "YES" : "NO");
	assert(1 == SortedListIsSameIter(iter2, SortedListBegin(list)));
	
	puts("--------------- Foreach test ---------------------");
	foreach = SortedListForEach(SortedListBegin(list), SortedListEnd(list), &PrintNum, "*");
	assert(1 == foreach);

	puts("\n--------------- Find test ---------------------");
	found = SortedListFind(list, SortedListBegin(list), SortedListEnd(list), &AreEqual, &val2);
	printf("\nElement found is: %d\n", *(int *)SortedListGetData(found));
	assert(12 == *(int *)SortedListGetData(found));

	puts("\n-------------- Pop back test --------------------");
	removed = SortedListPopBack(list);
	printf("\nValue of removed element is: %d\n", *(int *)removed);
	assert(12 == *(int *)removed);

	puts("\n-------------- Pop front test --------------------");
	removed = SortedListPopFront(list);
	printf("\nValue of removed element is: %d\n", *(int *)removed);
	assert(1 == *(int *)removed);
	printf("\nSize of DList is: %lu\n", SortedListSize(list));
	assert(2 == SortedListSize(list));
	puts("\n-------------- Print List --------------------");
	PrintList(list);

	puts("\n--------------- Find test ---------------------");
	found = SortedListFind(list, SortedListBegin(list), SortedListEnd(list), &AreEqual, &val3);
	printf("\nElement found is: %d\n", *(int *)SortedListGetData(found));
	assert(4 == *(int *)SortedListGetData(found));

	puts("\n-------------- Erase test --------------------");
	erased = SortedListErase(iter4);
	printf("\nValue of removed next element is: %d\n", *(int *)SortedListGetData(erased));
	assert(9 == *(int *)SortedListGetData(erased));
	puts("\n-------------- Print List --------------------");	
	PrintList(list);		
	SortedListInsert(list, &val5);
	SortedListInsert(list, &val6);
	
	puts("\n-------------- Print List --------------------");
	PrintList(list);	
	assert(3 == SortedListSize(list));
	erased = SortedListErase(iter1);	
	printf("\nValue of removed next element is: %d\n", *(int *)SortedListGetData(erased));
	assert(10 == *(int *)SortedListGetData(erased));
	puts("\n-------------- Print List --------------------");
	PrintList(list);
	erased = SortedListErase(SortedListBegin(list));	
	printf("\nValue of removed next element is: %d\n", *(int *)SortedListGetData(erased));
	assert(10 == *(int *)SortedListGetData(erased));
	PrintList(list);
	erased = SortedListErase(SortedListBegin(list));
	puts("\n-------------- Print List --------------------");
	PrintList(list);
	
	SortedListDestroy(list);

	puts("\nSUCCESS - Test 1");

}

/***********************************************************************/
void MergeTest1()
{
	int val1 = 1;
	int val2 = 4;
	int val3 = 3;
	int val4 = 7;
	int val5 = 6;
	int val6 = 5;

	sorted_list_t *list1 = SortedListCreate(&IsBefore, NULL);
	sorted_list_t *list2 = SortedListCreate(&IsBefore, NULL);
	
	puts("\n-------------- Merge list 2 before list 1--------------------");
	SortedListInsert(list1, &val1);
	SortedListInsert(list1, &val2);
	SortedListInsert(list1, &val3);
	SortedListInsert(list2, &val4);
	SortedListInsert(list2, &val5);
	SortedListInsert(list2, &val6);

	puts("\n-------------- List 1--------------------");
	PrintList(list1);
	puts("\n-------------- List 2 --------------------");
	PrintList(list2);
	SortedListMerge(list1, list2);

	assert(val6 == *(int *)SortedListGetData(SortedListNext(SortedListFind(list1, SortedListBegin(list1), SortedListEnd(list1), &AreEqual, &val2))));
	assert(6 == SortedListSize(list1));
	assert(1 == SortedListIsEmpty(list2));


	puts("\n-------------- List 1--------------------");
	PrintList(list1);
	puts("\n-------------- List 2 --------------------");
	PrintList(list2);

	SortedListDestroy(list1);
	SortedListDestroy(list2);
	
	puts("\nSUCCESS - Test 2");
}

/***********************************************************************/
void MergeTest2(void)
{
	int val1 = 1;
	int val2 = 4;
	int val3 = 3;
	int val4 = 7;
	int val5 = 6;
	int val6 = 5;

	sorted_list_t *list1 = SortedListCreate(&IsBefore, NULL);
	sorted_list_t *list2 = SortedListCreate(&IsBefore, NULL);
	
	SortedListInsert(list1, &val5);
	SortedListInsert(list1, &val6);
	SortedListInsert(list1, &val4);
	
	SortedListInsert(list2, &val1);
	SortedListInsert(list2, &val3);
	SortedListInsert(list2, &val2);

	puts("\n-------------- List 1--------------------");
	PrintList(list1);
	puts("\n-------------- List 2 --------------------");
	PrintList(list2);
	
	
	
	puts("\n-------------- Merge list 2 before list 1--------------------");
	SortedListMerge(list1, list2);
	
	assert(val6 == *(int *)SortedListGetData(SortedListNext(SortedListFind(list1, SortedListBegin(list1), SortedListEnd(list1), &AreEqual, &val2))));
	assert(6 == SortedListSize(list1));
	assert(1 == SortedListIsEmpty(list2));

	puts("\n-------------- List 1--------------------");
	PrintList(list1);
	puts("\n-------------- List 2 --------------------");
	PrintList(list2);

	SortedListDestroy(list1);
	SortedListDestroy(list2);

	puts("\nSUCCESS - Test 3");
}

/***********************************************************************/
void MergeTest3(void)
{
	int val1 = 1;
	int val2 = 1;
	int val3 = 1;
	int val4 = 1;
	int val5 = 1;
	
	int val6 = 1;
	int val7 = 1;
	int val8 = 1;

	sorted_list_t *list1 = SortedListCreate(&IsBefore, NULL);
	sorted_list_t *list2 = SortedListCreate(&IsBefore, NULL);
	
	SortedListInsert(list1, &val1);
	SortedListInsert(list1, &val2);
	SortedListInsert(list1, &val4);
	SortedListInsert(list1, &val3);
	SortedListInsert(list1, &val5);
	
	SortedListInsert(list2, &val6);
	SortedListInsert(list2, &val7);
	SortedListInsert(list2, &val8);
	
	puts("\n-------------- List 1--------------------");
	PrintList(list1);
	puts("\n-------------- List 2 --------------------");
	PrintList(list2);
	
	puts("\n-------------- Merge list 2 before list 1--------------------");
	SortedListMerge(list1, list2);

	assert(8 == SortedListSize(list1));
	assert(1 == SortedListIsEmpty(list2));

	puts("\n-------------- List 1--------------------");
	PrintList(list1);
	puts("\n-------------- List 2 --------------------");
	PrintList(list2);

	SortedListDestroy(list1);
	SortedListDestroy(list2);
	
	puts("\nSUCCESS - Test 4");
}
/***********************************************************************/
void MergeTest4()
{
	int val1 = 1;
	int val2 = 4;
	int val3 = 8;
	
	int val4 = 6;
	int val5 = 3;
	int val6 = 2;
	int val7 = 9;
	int val8 = 10;

	sorted_list_t *list1 = SortedListCreate(&IsBefore, NULL);
	sorted_list_t *list2 = SortedListCreate(&IsBefore, NULL);
	
	SortedListInsert(list1, &val1);
	SortedListInsert(list1, &val2);
	SortedListInsert(list1, &val3);
	
	SortedListInsert(list2, &val4);
	SortedListInsert(list2, &val5);
	SortedListInsert(list2, &val6);
	SortedListInsert(list2, &val7);
	SortedListInsert(list2, &val8);
	
	puts("\n-------------- List 1--------------------");
	PrintList(list1);
	puts("\n-------------- List 2 --------------------");
	PrintList(list2);
	
	puts("\n-------------- Merge list 2 before list 1--------------------");
	SortedListMerge(list1, list2);

	assert(val2 == *(int *)SortedListGetData(SortedListNext(SortedListFind(list1, SortedListBegin(list1), SortedListEnd(list1), &AreEqual, &val5))));
	assert(val4 == *(int *)SortedListGetData(SortedListNext(SortedListFind(list1, SortedListBegin(list1), SortedListEnd(list1), &AreEqual, &val2))));
	assert(val7 == *(int *)SortedListGetData(SortedListNext(SortedListFind(list1, SortedListBegin(list1), SortedListEnd(list1), &AreEqual, &val3))));

	assert(8 == SortedListSize(list1));
	assert(1 == SortedListIsEmpty(list2));

	puts("\n-------------- List 1--------------------");
	PrintList(list1);
	puts("\n-------------- List 2 --------------------");
	PrintList(list2);

	SortedListDestroy(list1);
	SortedListDestroy(list2);
	
	puts("\nSUCCESS - Test 5");



}

/***********************************************************************/
static void PrintList(const sorted_list_t *list)
{
    sorted_list_iter_t *it = NULL;
	
    for (it = SortedListBegin(list); !SortedListIsSameIter(it, SortedListEnd(list)) ;it = SortedListNext(it))
    {   
        printf("%d ", *(int *)SortedListGetData(it));
    }
    puts("");
}
/***********************************************************************/

static int AreEqual(const void *val, void *param)
 {	
	assert(val && param);
	return (*((int *)val) == *((int *)param));
 }

	
/***********************************************************************/
static int PrintNum(void *val, void *param)
{
	printf("%d %s", *(int *)val, (char *)param);
	return 1;
}

static int IsBefore(const void *data1, const void *data2, void *param)
{
	UNUSED(param);
	
	return(*(int *)data1 < *(int *)data2);
	
}
