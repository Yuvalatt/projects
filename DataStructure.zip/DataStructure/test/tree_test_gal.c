#include "../include/tree.h"
#include <stdlib.h>             /* for malloc */
#include <assert.h>             /* for assertions */
#include <stdio.h>
#include <time.h>

#define ARR_SIZE 5000
#define TOP_LIM 100003

#define UNUSED(x) (void)(x)

static void Test(void);
static void Test1(void);

int main(void)
{
        Test();

    Test1();

    return EXIT_SUCCESS;
}

static int IntCmp(const void *data1, const void *data2, const void *param)
{
    int diff = (*(int *) data1 - *(int *) data2);

    UNUSED(param);

    if (diff > 0)
    {
        return 1;
    }
    if (diff < 0)
    {
        return -1;
    }
    return 0;
}

static int QsortCmp(const void *x, const void *y)
{
	assert(x && y);
	
	return (*(const int *)x - *(const int *)y);
}

static int Print(void *val, void *param)
{
	printf("%d\n", *(int *) val);
	
    UNUSED(param);

	return 1;
}

int arr[ARR_SIZE] = {0};
static int arr2[ARR_SIZE] = {0};

static int PrintToArr(void *value, void *param)
{
	arr2[*(size_t *) param] = *(int *) value;

    *(size_t *) param += 1;
	
	return 1;
}

static void Test(void)
{
    tree_t *tree = TreeCreate(IntCmp, NULL);
    static int arr1[ARR_SIZE] = {0};
    size_t i = 0;
    tree_iter_t iter = NULL;
    int tmp = 50000;
    srand(time(NULL));

    assert(tree);
    assert(TreeIsEmpty(tree));

    	/*for (i = 0; i < ARR_SIZE; i++)
	{
        printf("tree count  : %lu, i: %lu\n", TreeCount(tree), i);
        assert(TreeCount(tree) == i); puts("hi");

	while (!TreeIsSameIter(TreeEnd(tree), TreeFind(tree, &tmp)))
        {
            tmp = abs(rand()) % TOP_LIM;
        }

        arr[i] = tmp;
        arr1[i] = tmp;
        arr2[i] = tmp;
        iter = TreeInsert(tree, arr + i);*/
        assert(!TreeIsSameIter(iter, TreeEnd(tree)));
    }

    assert(TreeCount(tree) == ARR_SIZE);

    qsort(arr1, ARR_SIZE, sizeof(int), QsortCmp);

    i = 0;
    assert(TreeForEach(tree, TreeBegin(tree), TreeEnd(tree), PrintToArr, &i));
    
    for (i = 0; i < ARR_SIZE; i++)
	{
		assert(arr1[i] == arr2[i]);
	}

 /*   puts("my sorted arr\tqsorted arr\torigin arr\n");

    for (i = 0; i < ARR_SIZE; i++)
	{
		printf("%d\t\t", arr2[i]);
        printf("%d\t\t", arr1[i]);
        printf("%d\n", arr[i]);
	}

    puts("***********");*/

    assert(!TreeIsEmpty(tree));

    TreeDestroy(tree);

    puts("SUCCESS");
}

#define ARR9_SIZE 15

static void Test1(void)
{
    tree_t *tree = TreeCreate(IntCmp, NULL);
    static int arr9[ARR9_SIZE] = {13, 3, 4, 12, 14, 10, 5, 1, 8, 2, 7, 9, 11, 6, 18};
    static tree_iter_t iter[ARR9_SIZE] = {0};
    size_t i = 0;
    srand(time(NULL));

    assert(tree);
    assert(TreeIsEmpty(tree));

    for (i = 0; i < ARR9_SIZE; i++)
	{
        assert(TreeCount(tree) == i);
        iter[i] = TreeInsert(tree, arr9 + i);
        assert(!TreeIsSameIter(iter, TreeEnd(tree)));
    }

    assert(TreeCount(tree) == ARR9_SIZE);

    assert(!TreeIsEmpty(tree));

    assert(TreeRemove(iter[14]) == &arr9[14]);
    assert(TreeRemove(iter[3]) == &arr9[3]);
    assert(TreeRemove(iter[0]) == &arr9[0]);
    /*assert(!TreeForEach(tree, TreeBegin(tree), TreeEnd(tree), Print, NULL));
*/
    assert(TreeCount(tree) == (ARR9_SIZE - 3));

    TreeDestroy(tree);

    puts("test 1 SUCCESS");
}





