#include <assert.h>
#include <stdio.h>
#include "../include/uid.h"
#include "../include/task.h"
#include "../include/sch.h"

#define UNUSED(X)(void)(X)

enum status {SUCCESS = 0, FAIL = 1};

void Test1(void);
void Test2(void);
void Test3(void);

int Magenta(void *param);
int Blue(void *param);
int Yellow(void *param);
int Cyan(void *param);

int Print1(void *param);
int Print2(void *param);
int Print3(void *param);
int Print4(void *param);

int Stop(void *scheduler);

int main()
{	
	Test1();
	Test2();
	Test3();

	return EXIT_SUCCESS;
}

void Test1(void)
{
	sch_t *sch = SCHCreate();
	uniqid_t u1 = {0};
	uniqid_t u2 = {0};
	uniqid_t u3 = {0};
	uniqid_t u4 = {0};
	uniqid_t u5 = {0};
	int removed = 0;
	int run_status = 0;

	puts("\033[0;34m \n~~~~~~~~~~~~~ SCHCreate ~~~~~~~~~~~~~\033[0m");
	printf("SCH Size is: %lu \n", SCHSize(sch));
	printf("Is SCH Empty? %s \n", SCHIsEmpty(sch) ? "YES" : "NO");
	assert(0 == SCHSize(sch));
	assert(1 == SCHIsEmpty(sch));

	puts("\n \033[0;34m~~~~~~~~~~~~~ SCHAddTask ~~~~~~~~~~~~~\033[0m");
	u1 = SCHAddTask(sch, Print1, NULL, 10);
	u2 = SCHAddTask(sch, Print1, NULL, 5);
	assert(!UIDIsBad(&u1));
	assert(!UIDIsBad(&u2));
	printf("SCH Size is: %lu \n", SCHSize(sch));
	printf("Is SCH Empty? %s \n", SCHIsEmpty(sch) ? "YES" : "NO");
	assert(2 == SCHSize(sch));
	assert(!SCHIsEmpty(sch));
	
	puts("\n \033[0;34m~~~~~~~~~~~~~ SCHRemoveTask ~~~~~~~~~~~~~\033[0m");
	removed = SCHRemoveTask(sch, u1);
	printf("remove is %d\n", removed);
	assert(0 == removed);
	removed = SCHRemoveTask(sch, u2);
	assert(0 == removed);
	printf("SCH Size is: %lu \n", SCHSize(sch));
	printf("Is SCH Empty? %s \n", SCHIsEmpty(sch) ? "YES" : "NO");
	assert(0 == SCHSize(sch));
	assert(1 == SCHIsEmpty(sch));
	
	puts("\n \033[0;34m~~~~~~~~~~~~~ SCHRun ~~~~~~~~~~~~~\033[0m");
	
	u1 = SCHAddTask(sch, Print1, NULL, 2);
	u2 = SCHAddTask(sch, Print2, NULL, 3);
	u3 = SCHAddTask(sch, Print2, NULL, 4);
	u4 = SCHAddTask(sch, Stop, sch, 15);
	u5 = SCHAddTask(sch, Print2, NULL, 2);
	
	run_status = SCHRun(sch);
	
	assert(0 == run_status);
	
	SCHDestroy(sch);
	
	puts("\n\033[1;34mSUCCESS - Test1\033[0m \n\n\n");
}

void Test2()
{
	sch_t *sch = SCHCreate();
	
	uniqid_t u1 = {0};
	uniqid_t u2 = {0};
	uniqid_t u3 = {0};
	uniqid_t u4 = {0};

	assert(0 == SCHSize(sch));
	assert(1 == SCHIsEmpty(sch));
	assert(!UIDIsBad(&u1));
	assert(!UIDIsBad(&u2));
	
	u1 = SCHAddTask(sch, Print4, NULL, 0);
	u2 = SCHAddTask(sch, Print3, NULL, 1);	
	u3 = SCHAddTask(sch, Print1, NULL, 3);	
	u4 = SCHAddTask(sch, Stop, sch, 2);
	
	
	assert(4 == SCHSize(sch));
	assert(!SCHIsEmpty(sch));
	
	SCHRun(sch);
	
	printf("%c[%d;%dm %c[%dm\n",27,1, 36,27,0);
	
	SCHDestroy(sch);

	sch = NULL;

	puts("\n\033[1;34mSUCCESS - Test2\033[0m \n\n\n");

}


void Test3()
{
	sch_t *sch = SCHCreate();
	
	uniqid_t u1 = {0};
	uniqid_t u2 = {0};
	uniqid_t u3 = {0};
	uniqid_t u4 = {0};
	uniqid_t u5 = {0};
	uniqid_t u6 = {0};

	assert(0 == SCHSize(sch));
	assert(1 == SCHIsEmpty(sch));
	assert(!UIDIsBad(&u1));
	assert(!UIDIsBad(&u2));

	
	u1 = SCHAddTask(sch, Magenta, NULL, 1);
	u2 = SCHAddTask(sch, Blue, NULL, 5);	
	u3 = SCHAddTask(sch, Stop, sch, 20);
	u4 = SCHAddTask(sch, Yellow, NULL, 5);
	u5 = SCHAddTask(sch, Cyan, NULL, 3);
	u6 = SCHAddTask(sch, Yellow, NULL, 6);
	
	assert(0 == SCHIsEmpty(sch));
	assert(6 == SCHSize(sch));
	
	SCHRun(sch);
	
	printf("%c[%d;%dm %c[%dm\n",27,1, 36,27,0);
	
	SCHDestroy(sch);
	sch = NULL;
	
	puts("\n\033[1;34mSUCCESS - Test3\033[0m \n\n\n");
}

int Print1(void *param)
{
	time_t now = time(0);
	
	printf("Current date and time: %s\n", ctime(&now));
	
	return SUCCESS;
	
}

int Print2(void *param)
{
	
	printf("%c[%d;%dm H A P P Y    T H U R S D A Y %c[%dm\n",27,1, 36,27,0);
	
	return SUCCESS;
}

int Print3(void *param)
{
	
	printf("%c[%d;%dm SEC = 1 %c[%dm\n",27,1,32,27,0);

	return SUCCESS;
}


int Print4(void *param)
{
	puts("HI");
	
	return SUCCESS;
}


int Stop(void *scheduler)
{
	SCHStop((sch_t *)scheduler);
	
	return SUCCESS;
}

int Magenta(void *param)
{
	UNUSED(param);

	printf("\033[031;45m \033[20m\n");

	return SUCCESS;
}

int Blue(void *param)
{
	UNUSED(param);

	printf("\033[031;44m \033[20m\n");

	return SUCCESS;
}

int Yellow(void *param)
{
	UNUSED(param);

	printf("\033[031;43m \033[20m\n");

	return SUCCESS;
}

int Cyan(void *param)
{
	UNUSED(param);

	printf("\033[031;46m \033[20m\n");

	return SUCCESS;
}



