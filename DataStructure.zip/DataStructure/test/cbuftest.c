#include "../include/cbuf.h"
#include <stdio.h>
#include <stdlib.h> /* EXIT_SUCCESS */
#include <assert.h> /* assert */
#include <string.h> /* strlen */

void Test1(void);
void Test2(void);
void Test3(void);
void Test4(void);
void Test5(void);
void Test6(void);

int main()
{
	Test1();
	Test2();
	Test3();
	Test4();
	Test5();
	Test6();
	
	return EXIT_SUCCESS;
}

void Test1()      /* Write & Read -Less than capacity */
{
	c_buf_t *cbuf = CBufCreate(10);
	size_t fs = 0;
	size_t cap = 0;
	int empty = 0;
	char *data ="Data!";
	char data2[10]= "";
	size_t count_written = 0;
	size_t count_read = 0;
	
	empty = CBufIsEmpty(cbuf);
	assert(1 == empty);
	fs =  CBufFreeSpace(cbuf);
	assert(10 == fs);
	cap = CBufCapacity(cbuf);
	assert(10 == cap);
	
	count_written =  CBufWrite(cbuf, data, 3);
	assert( 3 == count_written);
	fs =  CBufFreeSpace(cbuf);
	assert(7 == fs);
	empty = CBufIsEmpty(cbuf);
	assert(0 == empty);
	
	count_read = CBufRead(cbuf, data2, 3);
	assert(3 == count_read);
	fs =  CBufFreeSpace(cbuf);
	assert(10 == fs);
	empty = CBufIsEmpty(cbuf);
	assert(1 == empty);
	
	CBufDestroy(cbuf);
	
	puts("SUCCESS - Test 1");
}

void Test2()      /* Reading - No data */
{
	char *data ="";
	size_t count_read = 0;
	int empty = 0;
	
	c_buf_t *cbuf = CBufCreate(10);
	count_read = CBufRead(cbuf, data, 3);
	empty = CBufIsEmpty(cbuf);
	
	assert(0 == count_read);
	assert(ENODATA == g_cbuf_errno);
	assert(1 == empty);
	
	CBufDestroy(cbuf);
	puts("SUCCESS - Test 2");
}

void Test3()    /* Writing - No freespace */
{
	c_buf_t *cbuf = CBufCreate(5);
	char *data ="Data!";
	size_t count_written = 0;
	size_t fs = 0;
	
	count_written =  CBufWrite(cbuf, data, 5);
	count_written =  CBufWrite(cbuf, data, 5);
	fs = CBufFreeSpace(cbuf);
	
	assert(0 == count_written);
	assert(EOVERFLOW == g_cbuf_errno);
	assert(0 == fs);
	
	CBufDestroy(cbuf);
	puts("SUCCESS - Test 3");
}

void Test4()    /* Write & read more than written */
{
	c_buf_t *cbuf = CBufCreate(10);
	char *data ="Data!";
	char data2[10]= "";
	size_t count_written = 0;
	size_t count_read = 0;
	size_t fs = 0;
	
	count_written =  CBufWrite(cbuf, data, 5);
	fs = CBufFreeSpace(cbuf);
	assert(5 == fs);
	assert(5 == count_written);
	count_read = CBufRead(cbuf, data2, 8);
	assert(5 == count_read);
	
	CBufDestroy(cbuf);
	puts("SUCCESS - Test 4");
}

void Test5()      	/*  Circular Read & Write - Trying to write more than read  */   
{
	c_buf_t *cbuf = CBufCreate(10);
	size_t fs = 0;
	size_t cap = 0;
	int empty = 0;
	char *data ="Data!";
	char *dat ="Hey";
	char *dat2="abcd";
	char data2[10]= "";	
	size_t count_written = 0;
	size_t count_read = 0;
		
	cap = CBufCapacity(cbuf);
	assert(10 == cap);
	empty = CBufIsEmpty(cbuf);
	assert(1 == empty);
	count_written =  CBufWrite(cbuf, data, 3);
	assert( 3 == count_written);
	fs =  CBufFreeSpace(cbuf);
	assert(7 == fs);
	count_read = CBufRead(cbuf, data2, 3);
	assert( 3 == count_read);
	empty = CBufIsEmpty(cbuf);
	assert(1 == empty);
	fs =  CBufFreeSpace(cbuf);
	assert(10 == fs);
	count_written =  CBufWrite(cbuf, data + 3, 2);
	assert(2 == count_written);
	fs =  CBufFreeSpace(cbuf);
	assert(8 == fs);	
	count_read = CBufRead(cbuf, data2 + 3 , 2);
	assert(2 == count_read);
	count_written =  CBufWrite(cbuf, dat, strlen(dat));
	fs =  CBufFreeSpace(cbuf);
	assert(7 == fs);
	count_written =  CBufWrite(cbuf, dat2, strlen(dat2));
	assert(4 == count_written);
	fs =  CBufFreeSpace(cbuf);
	assert(3 == fs);
	count_written =  CBufWrite(cbuf, dat2, strlen(dat2));
	assert(3 == count_written);
	count_written =  CBufWrite(cbuf, dat2, strlen(dat2));
	assert(0 == count_written);
	count_read = CBufRead(cbuf, data2, 10);
	assert(10 == count_read);
	
	CBufDestroy(cbuf);
	
	puts("SUCCESS - Test 5");
}

void Test6() /*  Circular Read & Write - Trying to read more than wrote  */
{
	c_buf_t *cbuf = CBufCreate(10);
	size_t fs = 0;
	int empty = 0;
	char *data = "123456789123";
	char *data1 = "aaaaa";
	char data2[10]= "";	
	size_t count_written = 0;
	size_t count_read = 0;
		
	count_written = CBufWrite(cbuf, data, 12);
	assert(10 == count_written);
	fs =  CBufFreeSpace(cbuf);
	assert(0 == fs);
	count_read = CBufRead(cbuf, data2, 3);
	assert(3 == count_read);
	fs =  CBufFreeSpace(cbuf);
	assert(3 == fs);
	count_written = CBufWrite(cbuf, data1, strlen(data1));
	assert(3 == count_written);
	fs =  CBufFreeSpace(cbuf);
	assert(0 == fs);
	count_written = CBufWrite(cbuf, data1, strlen(data1));
	assert(0 == count_written);
	fs =  CBufFreeSpace(cbuf);
	assert(0 == fs);
	empty = CBufIsEmpty(cbuf);
	assert(0 == empty);
	count_read = CBufRead(cbuf, data2 + 3, 5);
	assert(5 == count_read);
	count_read = CBufRead(cbuf, data2 + 8, 10);
	assert(5 == count_read);

	CBufDestroy(cbuf);
	puts("SUCCESS - Test 6");
}
