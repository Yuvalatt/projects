#include "../include/vsm.h"

#include <stdio.h> 
#include <assert.h>  /* assert */ 
#include <stdlib.h>  /* EXIT_SUCCESS */


void Test1(void);
void Test2(void);

int main()
{
	#ifndef DEBUG
	Test1(); 		/* DEBUG */
	#else
	Test2();		/*NO DEBUG */
	#endif

	return EXIT_SUCCESS;
}

void Test1(void)
{	
	void *start = NULL;	
	vsm_t *vsm = NULL;
	void *ptr1 = NULL;
	void *ptr2 = NULL;
	void *ptr3 = NULL;
	void *ptr4 = NULL;
	void *ptr5 = NULL;
	void *ptr6 = NULL;
	void *ptr7 = NULL;
	
	start = malloc(500 * sizeof(char));
	if (NULL != start)
	{
		vsm = VSMInit(start, 500);
	}
	
	printf("Count free: %lu\n", VSMCountFree(vsm));
 
	assert(476 == VSMCountFree(vsm));
	assert(476 == GetLargest(vsm));
	
	ptr1 = VSMAlloc(vsm, 100); 			/*aligned size  - 104 */

	printf("Count free: %lu\n", VSMCountFree(vsm));
	assert(356 == VSMCountFree(vsm));
	assert(356 == GetLargest(vsm));
	
	ptr2 = VSMAlloc(vsm, 150); 			/*aligned size  - 152 */
	printf("Count free: %lu\n", VSMCountFree(vsm));
	assert(188 == VSMCountFree(vsm));
	assert(188 == GetLargest(vsm));
	
	VSMFree(ptr1);
	printf("Count free: %lu\n", VSMCountFree(vsm));
	assert(292 == VSMCountFree(vsm));
	assert(188 == GetLargest(vsm));
	
	VSMFree(ptr2);
	printf("Count free: %lu\n", VSMCountFree(vsm));
	assert(476 == VSMCountFree(vsm));
	assert(476 == GetLargest(vsm));
	
	ptr3 = VSMAlloc(vsm, 150);
	assert(ptr1 == ptr3);
	assert(308 == VSMCountFree(vsm));
	assert(308 == GetLargest(vsm));
	
	ptr4 = VSMAlloc(vsm, 100);			/*aligned size  - 104 */
	printf("Count free: %lu\n", VSMCountFree(vsm));
	assert(188 == VSMCountFree(vsm));
	assert(188 == GetLargest(vsm));
	
	ptr5 = VSMAlloc(vsm, 2000);			/*aligned size  - 200 */

	printf("Ptr: %lu\n",(size_t)ptr5);
	assert(0 == ptr5);
	printf("Count free: %lu\n", VSMCountFree(vsm));
	assert(188 == VSMCountFree(vsm));
	assert(188 == GetLargest(vsm));
	
	ptr6 = VSMAlloc(vsm, 10);			/*aligned size  - 16 */
	printf("Count free: %lu\n", VSMCountFree(vsm));
	assert(156 == VSMCountFree(vsm));
	assert(156 == GetLargest(vsm));
	
	ptr7 = VSMAlloc(vsm, 144);			/*aligned size  - 16 */
	printf("Count free: %lu\n", VSMCountFree(vsm));
	assert(ptr7);	
	assert(0 == VSMCountFree(vsm));
	assert(0 == GetLargest(vsm));

	free(vsm);	
		
	puts("SUCCESS -VSM-DEBUG");
}


void Test2(void)
{	
	void *start = NULL;	
	vsm_t *vsm = NULL;
	void *ptr1 = NULL;
	void *ptr2 = NULL;
	void *ptr3 = NULL;
	void *ptr4 = NULL;
	void *ptr5 = NULL;
	void *ptr6 = NULL;
	
	start = malloc(500 * sizeof(char));
	if (NULL != start)
	{
		vsm = VSMInit(start, 500);
	}
	
	printf("Count free: %lu\n", VSMCountFree(vsm));
 
	assert(484 == VSMCountFree(vsm));
	assert(484 == GetLargest(vsm));
	
	ptr1 = VSMAlloc(vsm, 100); 			/*aligned size  - 104 */

	printf("Count free: %lu\n", VSMCountFree(vsm));
	assert(364 == VSMCountFree(vsm));
	assert(364 == GetLargest(vsm));
	
	ptr2 = VSMAlloc(vsm, 150); 			/*aligned size  - 152 */
	printf("Count free: %lu\n", VSMCountFree(vsm));
	assert(196 == VSMCountFree(vsm));
	assert(196 == GetLargest(vsm));
	
	VSMFree(ptr1);
	printf("Count free: %lu\n", VSMCountFree(vsm));
	assert(300 == VSMCountFree(vsm));
	assert(196 == GetLargest(vsm));
	
	VSMFree(ptr2);
	printf("Count free: %lu\n", VSMCountFree(vsm));
	assert(484 == VSMCountFree(vsm));
	assert(484 == GetLargest(vsm));
	
	ptr3 = VSMAlloc(vsm, 150);
	assert(ptr1 == ptr3);
	assert(316 == VSMCountFree(vsm));
	assert(316 == GetLargest(vsm));
	
	ptr4 = VSMAlloc(vsm, 100);			/*aligned size  - 104 */
	printf("Count free: %lu\n", VSMCountFree(vsm));
	assert(196 == VSMCountFree(vsm));
	assert(196 == GetLargest(vsm));
	
	ptr5 = VSMAlloc(vsm, 2000);			/*aligned size  - 200 */

	printf("Ptr: %lu\n",(size_t)ptr5);
	assert(0 == ptr5);
	printf("Count free: %lu\n", VSMCountFree(vsm));
	assert(196 == VSMCountFree(vsm));
	assert(196 == GetLargest(vsm));
	
	ptr6 = VSMAlloc(vsm, 10);			/*aligned size  - 16 */
	assert(164 == VSMCountFree(vsm));
	assert(164 == GetLargest(vsm));
	
	free(vsm);	
		
	puts("SUCCESS - VSM - Release");
}
