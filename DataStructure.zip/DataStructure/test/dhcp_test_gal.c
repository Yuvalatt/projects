#include <stdlib.h>		/* for EXIT_SUCCESS */
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include "../include/dhcp.h"
#include "../include/barr.h"

#define TIME_LIM 5
#define CIDR 16
#define BITS_IN_BYTE 8
#define BITS_IN_INT (sizeof(int) * BITS_IN_BYTE)
#define POWER2(exp) (((size_t) 0x1) << (exp))		/* 2 ^ exp */

static void Test(void);
static void CharBarrTest(void);

int main(void)
{
	Test();
	CharBarrTest();

	return EXIT_SUCCESS;
}

static void PrintIP(unsigned char addr[4])
{
	int i = 0;

	printf("allocated successfully ip addr: ");

	for (i = 0; i < 4; i++)
	{
		printf("%u", addr[i]);
		if (i != 3)
		{
			putchar('.');
		}
	}

	putchar('\n');
}

static void Test(void)
{
	size_t i = 0;
	unsigned char base_addr[4] = {42, 13, 54, 24};
	unsigned char net_addr[4] = {12, 17, 0, 0};
	size_t num_of_ips = POWER2(BITS_IN_INT - CIDR) - 3;
	size_t cap = 0;
	unsigned char *return_ip = NULL;
	time_t start = time(NULL);
	dhcp_t *dhcp = DHCPCreate(net_addr, CIDR);
	assert(dhcp);

	assert(num_of_ips == DHCPCountFree(dhcp));

	return_ip = (unsigned char *) malloc(num_of_ips * 4);
	assert(return_ip);

	cap = num_of_ips;

	while (time(NULL) - start < TIME_LIM)
	{
		for (i = 0; i < cap; i++, num_of_ips--)
		{
			assert(num_of_ips == DHCPCountFree(dhcp));
			assert(SUCCESS == DHCPAllocIP(dhcp, NULL, &return_ip[4*i]));
			/*PrintIP(&return_ip[4*i]);*/
		}

		assert(num_of_ips == DHCPCountFree(dhcp));
		assert(0 == num_of_ips);

		for (i = 0; i < cap; i++, num_of_ips++)
		{
			assert(num_of_ips == DHCPCountFree(dhcp));
			assert(SUCCESS == DHCPFreeIP(dhcp, &return_ip[4*i]));
		}

		assert(num_of_ips == DHCPCountFree(dhcp));
		assert(POWER2(BITS_IN_INT - CIDR) - 3 == num_of_ips);
	}

	free(return_ip);
	DHCPDestroy(dhcp);

	puts("SUCCESS");
}

static void BarrPrintBinary(barr_t barr)
{
	barr_t mask = (1UL << 63);
	size_t i = 0;
	
	while (i < 64)
	{
		if (0 == (i % 8))
		{
			puts("\n");
		}
		printf("%d", (int) ((barr & mask) >> 63));
		barr <<= 1;
		++i;
	}
		puts("\n");

}

static void CharSwap(unsigned char *x, unsigned char *y)
{
	unsigned char tmp = *x;
	*x = *y;
	*y = tmp;
}

static barr_t CharToBarr(unsigned char addr[4])
{
	barr_t barr = BarrAllOff();

	/* little endian rearrange */
	CharSwap(&addr[0], &addr[3]);
	CharSwap(&addr[1], &addr[2]);

	memcpy(&barr, addr, 4);

	return barr;
}

static void BarrToChar(barr_t barr, unsigned char addr[4])
{
	memcpy(addr, &barr, 4);
}

static void CharBarrTest(void)
{
	unsigned char addr[4] = {1, 20, 39, 23};
	unsigned char res[4] = {0};

	puts("barr is");
	BarrPrintBinary(CharToBarr(addr));

	BarrToChar(CharToBarr(addr), res);
	PrintIP(res);
}
