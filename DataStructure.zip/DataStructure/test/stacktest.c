#include "../include/stack.h"
#include <stdio.h>
#include <stdlib.h> /* EXIT_SUCCESS */
#include <assert.h> /* assert */

#define ARRAY_SIZE(arr)(sizeof(arr) / sizeof(arr[0])) 

void Test1(void);

void Test1(void)
{
	int a[] = {2, 4, 78, 0, 22, 3, 5, 6, 7, 9};
	size_t stack_size = 0;
	size_t i = 0;	
	int *int_ptr = 0;
	
	stack_t *stack = StackCreate(10, 4);
	
	for (i = 0; i < ARRAY_SIZE(a); ++i)
	{
		StackPush(stack, &a[i]);
		stack_size = StackSize(stack);
		assert(stack_size == (i + 1));
	}
	
	for (i = 0; i < ARRAY_SIZE(a) ; ++i)
	{
		int_ptr = StackPeek(stack);
		printf("\nElement on top is: %d \n", *int_ptr);
		assert(stack_size == (ARRAY_SIZE(a) - i));
		StackPop(stack);	
		stack_size = StackSize(stack);
		printf("Size of stack is: %lu \n", stack_size);

	}

	StackDestroy(stack);
	puts("\nSUCCESS - Test 1\n\n");
}

int main()
{
	Test1();
	return EXIT_SUCCESS;
}
