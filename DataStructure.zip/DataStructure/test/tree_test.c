#include "../include/tree.h"

#include <stdio.h>
#include <stdlib.h> /* EXIT_SUCCESS */
#include <assert.h> /* assert */

#define UNUSED(x)(void)(x)


static int PrintNum(void *val, void *param);
static int IsBefore(const void *data1, const void *data2, const void *param);

void TreeTest(void);

int main()
{
	TreeTest();	
	return EXIT_SUCCESS;
}

void TreeTest(void)
{
	tree_iter_t iter1 = NULL;
	tree_iter_t iter2 = NULL;
	tree_iter_t iter3 = NULL;
	tree_iter_t iter4 = NULL;
	tree_iter_t iter5 = NULL;
	tree_iter_t iter6 = NULL;
	tree_iter_t iter7 = NULL;
	tree_iter_t iter8 = NULL;
	tree_iter_t iter9 = NULL;
	tree_iter_t iter10 = NULL;
	
	int data[] = {41, 32, 56, 43, 16, 2, 42, 90, 29, 67};
	int val1 = 67;
	int val2 = 93;
	int val3 = 45;
	int val4 = 49;
	
	tree_t *tree = TreeCreate(&IsBefore, NULL);
	size_t size = 0;

	printf("Is tree empty? %s \n", (1 == TreeIsEmpty(tree) ? "YES" : "NO"));
	assert(1 == TreeIsEmpty(tree));
	
	iter1 = TreeInsert(tree, &data[0]);
	iter2 = TreeInsert(tree, &data[1]);
	iter3 = TreeInsert(tree, &data[2]);
	iter4 = TreeInsert(tree, &data[3]);
	iter5 = TreeInsert(tree, &data[4]);
	iter6 = TreeInsert(tree, &data[5]);
	iter7 = TreeInsert(tree, &data[6]);
	iter8 = TreeInsert(tree, &data[7]);
	iter9 = TreeInsert(tree, &data[8]);
	iter10 = TreeInsert(tree, &data[9]);
	
	printf("Is tree empty? %s \n", (1 == TreeIsEmpty(tree) ? "YES" : "NO"));
	
	assert(41 == *(int *)TreeGetData(iter1));
	assert(32 == *(int *)TreeGetData(iter2));
	assert(56 == *(int *)TreeGetData(iter3));
	assert(42 == *(int *)TreeGetData(TreeNext(iter1)));
	assert(32 == *(int *)TreeGetData(TreePrev(iter1)));
	assert(41 == *(int *)TreeGetData(TreeNext(iter2)));
	assert(41 == *(int *)TreeGetData(TreeNext(iter2)));
	assert(42 == *(int *)TreeGetData(TreePrev(TreePrev(iter3))));
	assert(42 == *(int *)TreeGetData(TreeNext(TreeNext(iter2))));
	assert(0 == TreeIsEmpty(tree));
	TreeForEach(tree, TreeBegin(tree), TreeEnd(tree), &PrintNum, NULL);
	assert(67 == *(int *)TreeGetData(TreeFind(tree, &val1)));
	assert(10 == TreeCount(tree));
	
	puts("\n\nTRAVERSAL:");
	PrintTraversal(tree);
	puts("");
		
	TreeRemove(iter2);
	printf("\nNumber of nodes in tree: %lu \n", TreeCount(tree));
	assert(9 == TreeCount(tree));
	TreeForEach(tree, TreeBegin(tree), TreeEnd(tree), &PrintNum, NULL);
	
	TreeRemove(iter6);
	printf("\nNumber of nodes in tree: %lu \n", TreeCount(tree));
	assert(8 == TreeCount(tree));
	TreeForEach(tree, TreeBegin(tree), TreeEnd(tree), &PrintNum, NULL);
	
	size = TreeCount(tree);
	printf("\n\nPostOrderTraversal - Number of nodes in tree: %lu \n", size);

	TreeRemove(iter3);
	printf("\nNumber of nodes in tree: %lu \n", TreeCount(tree));
	assert(7 == TreeCount(tree));
	TreeForEach(tree, TreeBegin(tree), TreeEnd(tree), &PrintNum, NULL);
	
	TreeInsert(tree, &val3);
	TreeInsert(tree, &val4);
	
	printf("\nNumber of nodes in tree: %lu \n", TreeCount(tree));
	TreeForEach(tree, TreeBegin(tree), TreeEnd(tree), &PrintNum, NULL);
	assert(9 == TreeCount(tree));
	
	TreeRemove(iter4);
	printf("\nNumber of nodes in tree: %lu \n", TreeCount(tree));
	assert(8 == TreeCount(tree));
	TreeForEach(tree, TreeBegin(tree), TreeEnd(tree), &PrintNum, NULL);
	

	TreeDestroy(tree);
	tree = NULL;

	puts("\nSUCCESS - TreeCreateTest");
}
	
/***********************************************************************/
static int PrintNum(void *val, void *param)
{
	UNUSED(param);
	printf("%d ", *(int *)val);
	return 1;
}

static int IsBefore(const void *data1, const void *data2, const void *param)
{
	UNUSED(param);
	
	if(*(int *)data1 < *(int *)data2)
	{
		return -1;
	}
	else if (*(int *)data1 > *(int *)data2)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

