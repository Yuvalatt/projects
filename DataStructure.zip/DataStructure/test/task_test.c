#include "../include/uid.h"
#include "../include/task.h"

#include <assert.h>
#include <stdio.h>

#define UNUSED(X)(void)(X)

int Print(void *param);

int main()
{
	task_t *task1 = TaskCreate(Print, NULL, 5);
	task_t *task2 = TaskCreate(Print, NULL, 3);
	
	time_t start_time1 = TaskGetActTime(task1);
	time_t start_time2 = TaskGetActTime(task2);

	printf("~~~~~ Task ID is: %lu ~~~~~~\n",TaskGetId(task1));
	printf("current time is: %lu \n",start_time1);
	TaskRun(task1);
	TaskTimeUpdate(task1);
	printf("current time is: %lu \n",TaskGetActTime(task1));
	assert((TaskGetActTime(task1) - start_time1) ==  TaskGetPeriodInSec(task1));
	TaskRun(task1);
	TaskDestroy(task1);

	printf("\n~~~~~ Task ID is: %lu ~~~~~~\n",TaskGetId(task2));
	printf("current time is: %lu \n",start_time2);
	assert(start_time1 == start_time2);
	TaskRun(task2);
	TaskTimeUpdate(task2);
	printf("current time is: %lu \n",TaskGetActTime(task2));
	assert((TaskGetActTime(task2) - start_time2) ==  TaskGetPeriodInSec(task2));
	TaskRun(task2);
	TaskDestroy(task2);


	return EXIT_SUCCESS;
}


int Print(void *param)
{
	UNUSED(param);

	puts("******************************************");

	return PERIODIC;
}

