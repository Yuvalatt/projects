#include <assert.h> /* assert */
#include <stdio.h>  /* puts */

#include "../include/heap.h"

#define UNUSED(x) ((void) (x))
#define ARR_SIZE 10

 void PrintHeap(heap_t *heap);
int MaxHeapCmpFunc(const void *data1, const void *data2, const void *param);
int FindMatch(const void *data, const void *data_to_find, const void *param);
void TestHeap(void);

int main(void)
{
    TestHeap();
    return EXIT_SUCCESS;
}

void TestHeap(void)
{
    int i = 0;
    static int arr[ARR_SIZE] = {2, 10, 12, 3, 4, 56, 32, 9, 5, 11};
    static int arr2[12] = {20, 10, 17, 3, 4, 15, 16, 2, 1, -3, -5, 11};
    heap_t *heap = HeapCreate(MaxHeapCmpFunc, NULL);
    heap_t *heap2 = HeapCreate(MaxHeapCmpFunc, NULL);
    if (!heap)
    {
        exit(EXIT_FAILURE);
    }
    if (!heap2)
    {
        exit(EXIT_FAILURE);
    }

    assert(0 == HeapSize(heap));
    assert(1 == HeapIsEmpty(heap));
   for (i = 0; i < ARR_SIZE; ++i)
    {
	puts("push");
        assert(i == (int)HeapSize(heap));
        HeapPush(heap, &arr[i]);
        PrintHeap(heap);
    }
    assert(0 == HeapIsEmpty(heap));
    assert(56 == *(int *) HeapPeek(heap));
    
    for (i = 0; i < ARR_SIZE; ++i)
    {
        assert(10 - i == (int)HeapSize(heap));
        PrintHeap(heap);
        HeapPop(heap);
    }

    for (i = 0; i < ARR_SIZE; ++i)
    {
        assert(i == (int) HeapSize(heap));
        HeapPush(heap, &arr[i]);
    }
    assert(56 == *(int *) HeapPeek(heap));
    assert(56 == *(int *) HeapPop(heap));
    assert(32 == *(int *) HeapPeek(heap));
    assert(32 == *(int *) HeapPop(heap));
    assert(12 == *(int *) HeapPeek(heap));
    assert(12 == *(int *) HeapPop(heap));
    
    PrintHeap(heap);

    for (i = 0; i < 12; ++i)
    {
        assert(i == (int)HeapSize(heap2));
        HeapPush(heap2, &arr2[i]);
        PrintHeap(heap2);
    }
    PrintHeap(heap2);
    puts("example of heapifying up after removing 1:");
    assert(3 == *(int *) HeapRemove(heap2,FindMatch, &arr2[3], NULL));
    PrintHeap(heap2);

    puts("example of heapifying down after removing 17:");
    assert(17 == *(int *) HeapRemove(heap2,FindMatch, &arr2[2], NULL));
    PrintHeap(heap2);

    HeapDestroy(heap);
    HeapDestroy(heap2);
}

/*******************************************************
 **************    scaffoldings    *********************
*******************************************************/
int MaxHeapCmpFunc(const void *data1, const void *data2, const void *param)
{
    int diff = *(int *) data1 - *(int *) data2;
    
    UNUSED(param);

    if (0 < diff)
    {
        return 1;
    }
    if (0 > diff)
    {
        return -1;
    }
    return 0;
}

int FindMatch(const void *data, const void *data_to_find, const void *param)
{
    UNUSED(param);
    return *(int *) data == *(int *) data_to_find;
}

/*static void PrintHeap(heap_t *heap)
{
    size_t i = 0;
    void *first  = HeapPeek(heap);
    
    for (i = 1; i < HeapSize(heap); ++i)
    {
        printf("%d -> ", *(int *) ((char *)first + i * 8));
    }
    puts("");
}*/
