#include <stdio.h>
#include <stdlib.h> 			/* EXIT_SUCCESS */
#include <assert.h> 			/*  assert      */
#include <string.h>
#include "../include/dhcp.h"
#include "../include/barr.h"
#include "../include/dynvec.h"

#define POWER2(x)((int)0x1<<(x))

static void DHCPTest(void);
static void BarrTest(void);


int main()
{
	BarrTest();	
	DHCPTest();

	return EXIT_SUCCESS;
}

static void BarrTest(void)
{
	barr_t barr = 0;		
	unsigned char arr[4] = {0,0,255,255};   
		
	memcpy((char *)&barr + 4, (char *)&arr, 4 * sizeof(unsigned char));
		
	printf("arr[2] = %u\n", (unsigned char *)arr[2]);
	printf("arr[3] = %u\n",(unsigned char *) arr[3]);
	
	printf("num of on bits: %lu \n", BarrCountOn(barr));	
	printf("num of off bits: %lu \n", BarrCountOff(barr));
	
	printf("is bit 0 on ? %d\n", BarrIsOn(barr, 0));		/*  0 - Left bit    */
	printf("is bit 47 on ? %d\n", BarrIsOn(barr, 47));		/*  47 - Left bi    */	
	printf("is bit 48 on ? %d\n", BarrIsOn(barr, 48)); 	 	/*  48 - Right bit  */
	printf("is bit 63 on ? %d\n", BarrIsOn(barr, 63)); 		/*  63 - Right bit  */
	
	puts("\n-------------------------------------------------\n");
}

/***********************************************************************/
static void DHCPTest(void)
{		
	dhcp_t *dhcp = NULL;
	status_t stat = 0;
	size_t size = 0;
	
	unsigned char net[4] = {10, 1, 0, 0};
	
	unsigned char req1[4] = {0, 0, 0, 0};
	unsigned char req2[4] = {0, 0, 0, 0};
	unsigned char req3[4] = {0, 0, 0, 0};
	unsigned char req4[4] = {0, 0, 0, 0};
	unsigned char req5[4] = {0, 0, 0, 0};

	unsigned char ip1[4] = {10, 1, 22, 17};
	unsigned char ip2[4] = {10, 1, 22, 17};
	unsigned char ip3[4] = {10, 1, 255, 0};


	unsigned int cidr = 16;

	dhcp = DHCPCreate(net, cidr);
	assert(dhcp);

	printf("\nCount free: %lu\n\n" , DHCPCountFree(dhcp));
	assert(65533 ==  DHCPCountFree(dhcp));
	
	stat = DHCPAllocIP(dhcp, NULL, req1);
	assert(0 == stat);
	printf("REQ_IP: %u %u %u %u \n", req1[0], req1[1], req1[2], req1[3]);
	assert(0 == stat);

	stat = DHCPAllocIP(dhcp, ip1, req2);
	assert(0 == stat);
	printf("REQ_IP: %u %u %u %u \n", req2[0], req2[1], req2[2], req2[3]);
	assert(0 == stat);

	stat = DHCPAllocIP(dhcp, ip2, req3);
	assert(0 == stat);
	printf("REQ_IP: %u %u %u %u \n", req3[0], req3[1], req3[2], req3[3]);

	stat = DHCPAllocIP(dhcp, NULL, req4);
	assert(0 == stat);
	printf("REQ_IP: %u %u %u %u \n", req4[0], req4[1], req4[2], req4[3]);	

	printf("\nCount free: %lu\n\n" , DHCPCountFree(dhcp));
	assert(65529 ==  DHCPCountFree(dhcp));	

	stat = DHCPAllocIP(dhcp, ip3, req5);
	assert(0 == stat);
	printf("REQ_IP: %u %u %u %u \n", req5[0], req5[1], req5[2], req5[3]);

	puts("");
	PrintFullTrie(dhcp);
	printf("\nCount free: %lu\n\n" , DHCPCountFree(dhcp));

	puts("---------------FREE-------------------");
	stat = DHCPFreeIP(dhcp, req5);
	assert(0 == stat);
	printf("Count free: %lu\n\n", DHCPCountFree(dhcp));

	/*
	stat = DHCPFreeIP(dhcp, req4);
	assert(0 == stat);
	stat = DHCPFreeIP(dhcp, req3);
	assert(0 == stat);
	
	puts("");
	PrintFullTrie(dhcp);
	printf("Count free: %lu\n\n", DHCPCountFree(dhcp));
	assert(65531 ==  DHCPCountFree(dhcp));

	stat = DHCPFreeIP(dhcp, net);*/
	DHCPDestroy(dhcp);
	
	puts("\nSUCCESS - DHCPTest");
}



