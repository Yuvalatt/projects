#include "../include/calculator.h"
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>

static void Test(void);

int main(void)
{
    Test();

    return EXIT_SUCCESS;
}

static void Test(void)
{
    status_t status = SUCCESS;
/*
    printf("%f\n", Calculator("50---9", &status));
*/
    assert(8 == Calculator("3+5", &status));
    assert(status == SUCCESS);
    
    assert(28 == Calculator("3+5+1+8+6+5", &status));
    assert(status == SUCCESS);
    
    assert(35 == Calculator("20 +   \t\n\v\f\r15", &status));
    assert(status == SUCCESS);
    
    assert(15 == Calculator("3*5", &status));
    assert(status == SUCCESS);

    assert(-20 == Calculator("7 + 68 - 95", &status));
    assert(status == SUCCESS);

    assert(41 == Calculator("100 - 3 + -51 - 5", &status));
    assert(status == SUCCESS);
    /*
    assert(0 == Calculator("50---9", &status));
    assert(status == INVALID_NUM);
*/

    assert(0 == Calculator("30*/9", &status));
    assert(status == INVALID_NUM);

    assert(0 == Calculator("100*50$", &status));
    assert(status == INVALID_OPERATOR);

    assert(0 == Calculator("1a3 * 5", &status));
    assert(status == INVALID_OPERATOR);

    status = SUCCESS;
    assert(96 == Calculator("(3+5) * (4 + 8)", &status));
    assert(status == SUCCESS);

    assert(96 == Calculator("(((3)+5) * ((4 + 8)))", &status));
    assert(status == SUCCESS);

    assert(9 == Calculator("3^2^1", &status));
    assert(status == SUCCESS);

    assert(140 == Calculator("(((3)+5) * +1 * 2^4 +((4 + 8)))", &status));
    assert(status == SUCCESS);

    /*assert(0 == Calculator("(1+3))", &status));
    assert(status == UNEVEN_PAR);*/
    /*status = SUCCESS;
    assert(0 == Calculator("((1+3)", &status));
    assert(status == INVALID_OPERATOR);*/

    puts("SUCCESS");
}
