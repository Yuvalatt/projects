#include "../include/slist.h"
#include "../include/stack.h"

#include <stdio.h>
#include <stdlib.h>   /* EXIT_SUCCESS */
#include <assert.h>   /* assert */
#include <string.h>   /* teting */

void RecTest(void);
void StrcpyTest(void);
void StrcatTest(void);
void StrstrTest(void);
void FlipTest(void);
void HanoiTest(void);
void StrcmpTest(void);
void StrlenTest(void);
void FibTest(void);
void StackSortTest(void);

int main()
{
	FibTest();
	StrlenTest();
	StrcmpTest();
	StrcpyTest();
	StrcatTest();
	StrstrTest();
	FlipTest();	
	HanoiTest();
	StackSortTest();
	
	return EXIT_SUCCESS;
}

/***********************************************************************/
void FibTest()
{	
	printf("RFibonacci result is: %lu \n", RFibonacci(10));
	printf("RFibonacci result is: %lu \n", RFibonacci(20));
	printf("RFibonacci result is: %lu \n", RFibonacci(30));
	printf("RFibonacci result is: %lu \n", RFibonacci(40));
	printf("RFibonacci result is: %lu \n", RFibonacci(50));
	
	puts("-------------------------------------------------");
	printf("IFibonacci result is: %lu \n", IFibonacci(10));
	printf("IFibonacci result is: %lu \n", IFibonacci(20));
	printf("IFibonacci result is: %lu \n", IFibonacci(30));
	printf("IFibonacci result is: %lu \n", IFibonacci(40));
	printf("IFibonacci result is: %lu \n", IFibonacci(50)); 
	
	puts("\nSUCCESS - Fibonacci Test\n");
}

/***********************************************************************/
void StrcpyTest()
{
	char source[200]="aaa";
	char dest[200]="bbb";

	char source1[200]="aaa";
	char dest1[200]="bbb";

	puts("-------------------------------------------------");
	Strcpy(dest, source);
	strcpy(dest1, source1);

	printf("Strcpy dest = %s \n", dest);
	assert(0 == strcmp(dest1, dest));
	
	printf("SUCCESS - StrcpyTest\n");
}

void StrcatTest()
{
	char dest[100] = "Hi";
	char *src = "you!";
	
	char dest1[100] = "Hi";
	char *src1 = "you!";

	puts("-------------------------------------------------");
	Strcat(dest, src);
	printf("\nStrcat dest = %s \n", dest);
	
	strcat(dest1, src1);	
	printf("Strcat dest = %s \n\n", dest1);

	assert(0 == strcmp(dest, dest1));

	printf("SUCCESS - StrcatTest\n");
}

void StrstrTest()
{
	char *haystack = "abcdxcde";
	char *needle = "cde";
	char *haystack1 = "abcdxcde";
	char *needle1 = "cde";
	
	puts("-------------------------------------------------");
	printf("\nStrstr needle = %s \n", Strstr(haystack, needle));
	printf("Strstr needle = %s \n", strstr(haystack1, needle1));

	assert(0 == strcmp(strstr(haystack, needle), needle));
	assert(0 == strcmp(strstr(haystack1, needle1), needle1));

	printf("\nSUCCESS - StrstrTest\n");
}

void StrcmpTest(void)
{
	puts("-------------------------------------------------");

	printf("Strcmp is: %d \n", Strcmp("abc", "abc"));
	assert(strcmp("abc", "abc") == Strcmp("abc", "abc"));

	printf("Strcmp is: %d \n", Strcmp("eabc", "abc"));
	assert(strcmp("abc", "abc") == Strcmp("abc", "abc"));	

	printf("Strcmp is: %d \n", Strcmp("ac", "abc"));
	assert(strcmp("ac", "abc") == Strcmp("ac", "abc"));
	
	puts("\nSUCCESS - Strcmp Test\n");
}

void StrlenTest(void)
{
	puts("-------------------------------------------------");
	printf("Strlen is: %d \n", Strlen("123456"));
	assert(strlen("123456") == Strlen("123456"));
	printf("Strlen is: %d \n", Strlen(""));
	assert(strlen("") == Strlen(""));
	printf("Strlen is: %d \n", Strlen("  "));
	assert(strlen("  ") == Strlen("  "));
	puts("\nSUCCESS - Strlen Test\n");
}

/***********************************************************************/
static void PrintList(slist_node_t *head)
{
	slist_node_t *current = head;
	slist_node_t *next = NULL;
	int i = 1;
	
	assert(head);
	
	while(NULL != current)
	{
		next = current->next;
		printf("%d -> ", *(int *)current->val);
		current = next;
		++i;	
	}
	printf("NULL\n");
}

/***********************************************************************/
void FlipTest()
{
	int val1 = 1;
	int val2 = 2;
	int val3 = 3;	
	int i = 1;

	slist_node_t *node1 = NULL;
	slist_node_t *node2 = NULL;
	slist_node_t *node3 = NULL;
	slist_node_t *current = NULL;
	slist_node_t *next = NULL;	

	node1 = SListCreateNode(&val1, NULL);     /* Create nodes */
	node2 = SListCreateNode(&val2, node1);    
	node3 = SListCreateNode(&val3, node2);

	puts("-------------------------------------------------");

	PrintList(node3);
	node3 = (slist_node_t *)FlipList(node3);
	PrintList(node3);

	current = node3;
	
	/* Test output */
	while(NULL != current)
	{
		next = current->next;
		printf("%d -> ", *(int *)current->val);
		assert(i == *(int *)current->val);
		current = next;
		++i;	
	}

	puts("\nSUCCESS - Fliplist Test\n");
}

/***********************************************************************/
void HanoiTest(void)
{
	puts("-------------------------------------------------");
	Hanoi(3, 1, 3);
}

/***********************************************************************/
void StackSortTest(void)
{
	int a[] = {1, 2, 4, 5};
	int b[] = {2, 6, 1, 8, 3, 4, 5, 7};

	size_t i = 0;	
	int *int_ptr = 0;
	int num = 3;

	stack_t *stack = NULL;
	stack_t *stack2 = NULL;

	puts("-------------------------------------------------");

	stack = StackCreate(5, sizeof(int));
	
	for (i = 0; i < 4; ++i)
	{
		StackPush(stack, &a[i]);
	}
	
	SortedStackInsert(stack, num);

	for (i = 0; i < 5; ++i)
	{
		int_ptr = StackPeek(stack);
		printf("Element on top is: %d \n", *int_ptr);
		assert(*int_ptr == (5 - i));
		StackPop(stack);
	}

	StackDestroy(stack);

	puts("\nSUCCESS - SortedInsertTest\n\n");

	puts("-------------------------------------------------");

	stack2 = StackCreate(8, sizeof(int));

	for (i = 0; i < 8; ++i)
	{
		StackPush(stack, &b[i]);
	}

	RecursiveStackSort(stack2);

	for (i = 0; i < 8; ++i)
	{
		int_ptr = StackPeek(stack2);
		printf("Element on top is: %d \n", *int_ptr);
		assert(*int_ptr == (8 - i));
		StackPop(stack2);
	}
	
	StackDestroy(stack2);
	puts("\nSUCCESS - StackSortTest\n\n");
}
