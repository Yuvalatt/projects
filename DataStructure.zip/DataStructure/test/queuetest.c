#include "../include/queue.h"
#include "../include/slist.h"

#include <stdio.h> 
#include <stdlib.h> /* EXIT_SUCCESS */
#include <assert.h> /* assert */

void QueueTest(void);

void QueueTest(void)
{
	int val1 = 1;
	int val2 = 2;
	int val3 = 3;
	int val4 = 4;
	int val5 = 5;
	int val6 = 6;
	int val7 = 7;

	queue_t *queue1 = QueueCreate();
	queue_t *queue2 = QueueCreate();
	
	assert(1 == QueueIsEmpty(queue1)); 
	assert(0 == QueueSize(queue1));
	QueueEnqueue(queue1, &val1);	
	QueueEnqueue(queue1, &val2);
	QueueDequeue(queue1);
	assert(2 == *(int *)(QueuePeek(queue1)));
	QueueEnqueue(queue1, &val2);
	QueueEnqueue(queue1, &val3);
	assert(2 == *(int *)(QueuePeek(queue1)));
  	assert(3 == QueueSize(queue1));
	QueueDequeue(queue1);
	assert(2 == *(int *)(QueuePeek(queue1)));
	assert(2 == QueueSize(queue1));
	assert(2 == *(int *)(QueuePeek(queue1)));
	assert(0 == QueueSize(queue2));
	QueueEnqueue(queue2, &val4);
	QueueEnqueue(queue2, &val5);
	QueueEnqueue(queue2, &val6);
	assert(3 == QueueSize(queue2));
	assert(4 == *(int *)(QueuePeek(queue2)));
	QueueAppend(queue1, queue2);
	assert(5 == QueueSize(queue1));
	assert(2 == *(int *)(QueuePeek(queue1)));
	QueueEnqueue(queue1, &val7);
	assert(6 == QueueSize(queue1));
	QueueDequeue(queue1);
	assert(3 == *(int *)(QueuePeek(queue1)));
	QueueDequeue(queue1);
	assert(4 == *(int *)(QueuePeek(queue1)));	
	QueueDequeue(queue1);
	assert(5 == *(int *)(QueuePeek(queue1)));
	QueueDequeue(queue1);
	assert(6 == *(int *)(QueuePeek(queue1)));
	QueueDequeue(queue1);
	assert(7 == *(int *)(QueuePeek(queue1)));
	QueueDequeue(queue1);	
	assert(0 == QueueSize(queue1));
	
	QueueDestroy(queue1);
	QueueDestroy(queue2);
	
	puts("SUCCESS - Queue Test");
}

int main()
{
	QueueTest();
	return EXIT_SUCCESS;
}
