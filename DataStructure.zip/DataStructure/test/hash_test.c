#include "../include/dlist.h"
#include "../include/hash.h"

#include <stdlib.h> 		/* EXIT_SUCCESS */
#include <assert.h> 		/* assert */
#include <stdio.h>
#include <string.h>

#include <unistd.h>       	/* mmap libraries */
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>

#define UNUSED(x)(void)(x)
#define HASH_SIZE 1000

static void HashTest(void);

static int PrintStr(void *val, void *param);
static size_t Hash(const void *data);
static int HashInit(hash_t *hash, char *file_start, int *word_count);
static void HashClose(int fd, char *file_start);
static int StrCmp(const void *str1, const void *param, const void *str2);

int main()
{
	HashTest();

	return EXIT_SUCCESS;
}

/***********************************************************************/
static void HashTest()
{
	int fd = 0;
	void *find = NULL;
	char *file_start = NULL;

	char *str1 = "wowowow";
	char *str2 = "Yuv";	
	char *str3 = "Attar";
	
	hash_statistic_t stat = {0};
		
	int val = 0;	
	int *word_count = &val;
	int start_size = 0;

	hash_t *hash = NULL;

	hash= HashCreate(HASH_SIZE, &Hash, &StrCmp, NULL);

	printf("Is hash empty ? %s \n", (0 == HashIsEmpty(hash)) ? "NO" : "YES");
	assert(1 == HashIsEmpty(hash));
	printf("Hash size is: %lu \n", HashSize(hash));
	assert(0 == HashSize(hash));	
	
	puts("\n----------- Hash Init -------------");
	fd = HashInit(hash, file_start, word_count);	

	printf("Is hash empty ? %s \n", (0 == HashIsEmpty(hash)) ? "NO" : "YES");
	assert(0 == HashIsEmpty(hash));


	printf("Num of words found is: %d \n", *word_count);
	start_size = HashSize(hash);
	assert(*word_count == HashSize(hash));

	puts("\n-------------- For each ------------------");
	HashForEach(hash, &PrintStr, NULL);

	puts("\n-------------- Before Insert ------------------");
	printf("Hash size is: %lu \n", start_size);

	puts("\n-------------- Hash Insert ------------------");
	HashInsert(hash, str1);
	HashInsert(hash, str2);		

	assert((start_size + 2) == HashSize(hash));
	HashInsert(hash, str3);
	assert((start_size + 3) == HashSize(hash));
	printf("Hash size is: %lu \n", HashSize(hash));
	
	puts("\n-------------- Find ------------------");
	find = HashFind(hash, "omelet");
	printf("Found data is: %s \n", (char *)find);
	assert(0 == strcmp("omelet", find));

	find = HashFind(hash, "Yuv");
	printf("Found data is: %s \n", (char *)find);
	assert(0 == strcmp("Yuv", find));

	find = HashFind(hash, "zipper");
	printf("Found data is: %s \n", (char *)find);
	assert(0 == strcmp("zipper", find));

	puts("\n-------------- Remove ------------------");
	HashRemove(hash, str1);
	HashRemove(hash, str2);
	HashRemove(hash, str3);
	printf("Hash size is: %lu \n", HashSize(hash));
	assert(start_size == HashSize(hash));

	puts("\n-------------- Statistics ------------------");
	stat = GetStatistic(hash);
	printf("Max collision is: %lu \n", stat.max_collision);
	printf("Average collision is: %f \n", stat.average_collision);
	printf("STD is: %f \n", stat.STD_collision);

	HashDestroy(hash);
	HashClose(fd, file_start);

	puts("\nSUCCESS - Hash Test");
}

/***********************************************************************/
static int PrintStr(void *val, void *param)
{
	UNUSED(param);
	printf("%s\n", (char *)val);

	return 1;
}

/***********************************************************************/
static int StrCmp(const void *str1, const void *param, const void *str2)
{
	UNUSED(param);

	return (0 == strcmp((char *)str1, (char *)str2));
}

/***********************************************************************/
unsigned long hash2(unsigned char *str)
{
    unsigned long hash = 5381;
    int c;

	while (c = *str++)
	{
            hash = ((hash << 5) + hash) + c;
	}

    return hash;
}
/***********************************************************************/
static size_t Hash(const void *data)
{
	return hash2((unsigned char *)data) % HASH_SIZE;
}

/***********************************************************************/
static int HashInit(hash_t *hash, char *file_start, int *word_count)
{
	size_t i = 0;
	int fd = -1;	
	int status = 0;
	struct stat file_stat = {0};

	char *char_runner = NULL;
	char *word_runner = NULL;

   	 if ((-1 == (fd = open("dict_cpy", O_RDWR))))
	{
		puts("Error: file open");
        exit(1);
	}
	
	status = fstat(fd, &file_stat);
	if (SUCCESS != status)
	{
		 puts("Error: fstat");
		 exit(1);
	}
	
	char_runner = (char *)mmap(NULL, file_stat.st_size, PROT_WRITE, MAP_PRIVATE, fd, 0);
	if (char_runner == MAP_FAILED)
	{
		 puts("Error: mmap failure");
		 exit(1);
	}

	word_runner = char_runner;

	for (i = 1; i <= file_stat.st_size; i++)
	{
		if ('\n' == *char_runner)
		{
			*char_runner = '\0';

			HashInsert(hash, word_runner);

			word_runner = char_runner + 1;

			*(word_count) += 1;
		}

		++char_runner;
		
	}

	file_start = char_runner - file_stat.st_size;

	return fd;
}

/***********************************************************************/
static void HashClose(int fd, char *file_start)
{
	struct stat file_stat = {0};
	size_t status = 0;

	status = fstat(fd, &file_stat);
	if (SUCCESS != status)
	{
		 puts("Error: fstat");
		 exit(1);
	}
	
	if (SUCCESS != close(fd))
	{
		puts("Error: file close");
		exit(1);
	}

	if (SUCCESS != munmap(file_start, file_stat.st_size))
	{
		 puts("Error: munmap failure");
		 exit(1);
	}
}
