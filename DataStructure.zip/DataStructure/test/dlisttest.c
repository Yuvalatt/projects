#include "../include/dlist.h"

#include <stdio.h>
#include <stdlib.h> /* EXIT_SUCCESS */
#include <assert.h> /* assert */

#define UNUSED(x)(void)(x)

void DListTest(void);
void PrintList(dlist_t *dlist);
int AreEqual(const void *val, const void *param, const void *data);
int PrintNum(void *node_val, void *param);

int main()
{
	DListTest();
	return EXIT_SUCCESS;
}

/***********************************************************************/

void DListTest()
{
	int val1 = 6;
	int val2 = 12;
	int val3 = 4;
	int val4 = 9;
	int val5 = 1;

	int foreach = 0;

	size_t count = 0; 
	size_t empty_flag = 0;

	dlist_iter_t iter1 = 0;
	dlist_iter_t iter2 = 0;
	dlist_iter_t iter3 = 0;
	dlist_iter_t iter4 = 0;

	dlist_t *dlist1 = DListCreate();
	dlist_t *dlist2 = DListCreate();

	puts("---------------- Empty DList ----------------------");
	count = DListSize(dlist1); 	
	printf("\nSize of DList is: %lu\n", count);
	assert(0 == count);
	empty_flag = DListIsEmpty(dlist1);
	printf("Is DList empty? %s\n", (1 == empty_flag) ? "YES" : "NO");
	assert(1 == empty_flag);
	
	puts("-------------- Insert test --------------------");	
	iter1 = DListInsert(dlist1, DListEnd(dlist1), &val1);	
	count = DListSize(dlist1);
	printf("\nSize of DList is: %lu\n", count);
	assert(1 == count);
	empty_flag = DListIsEmpty(dlist1);
	printf("Is DList empty? %s\n", (1 == empty_flag) ? "YES" : "NO");
	assert(0 == empty_flag);
	printf("Value of first element is: %d\n", *(int *)DListGetData(iter1));	
	assert(6 == *(int *)DListGetData(DListBegin(dlist1)));
	
	puts("-------------- Insert After test --------------------");	
	iter2 = DListInsertAfter(dlist1, iter1, &val2);	
	printf("\nValue of second element is: %d\n", *(int *)DListGetData(iter2));
	assert(12 == *(int *)DListGetData(iter2));
	count = DListSize(dlist1);
	printf("Size of DList is: %lu\n", count);
	assert(2 == count);	
	printf("Value of first element is: %d\n", *(int *)DListGetData(DListBegin(dlist1)));
	assert(6 == *(int *)DListGetData(DListBegin(dlist1)));
	PrintList(dlist1);

	puts("-------------- Insert test ----------------------");		
	iter3 = DListInsert(dlist1, DListBegin(dlist1), &val3);
	printf("\nValue of first element is: %d\n", *(int *)DListGetData(DListBegin(dlist1)));	
	assert(4 == *(int *)DListGetData(DListBegin(dlist1)));
	PrintList(dlist1);

	puts("-------------- Prev test --------------------");
	printf("\nPrev element is: %d\n", *(int *)DListGetData(DListPrev(iter1)));
	assert(4 == *(int *)DListGetData(DListPrev(iter1)));
	printf("Prev element is: %d\n", *(int *)DListGetData(DListPrev(iter2)));
	assert(6 == *(int *)DListGetData(DListPrev(iter2)));
	PrintList(dlist1);

	puts("-------------- Next test --------------------");
	printf("\nNext element is: %d\n", *(int *)DListGetData(DListNext(iter3)));
	assert(6 == *(int *)DListGetData(DListNext(iter3)));
	printf("nNext element is: %d\n", *(int *)DListGetData(DListNext(iter1)));
	assert(12 == *(int *)DListGetData(DListNext(iter1)));

	puts("-------------- IsSame test --------------------");
	printf("\nIters same? %s\n", (1 == DListIsSameIter(iter1, iter2)) ? "YES" : "NO");
	assert(0 == DListIsSameIter(iter1, iter2));
	printf("Iters same? %s\n", (1 == DListIsSameIter(iter3, DListBegin(dlist1))) ? "YES" : "NO");
	assert(1 == DListIsSameIter(iter3, DListBegin(dlist1)));

	puts("-------------- Erase test --------------------");
	printf("\nSize of DList is: %lu\n", DListSize(dlist1));	
	DListErase(iter1);
	PrintList(dlist1);	
	printf("Size of DList is: %lu\n", DListSize(dlist1));
	assert(2 == DListSize(dlist1));
	printf("Next element is: %d\n", *(int *)DListGetData(DListNext(iter3)));
	assert(12 == *(int *)DListGetData(DListNext(iter3)));	
	
	puts("-------------- Push front test --------------------");
	iter4 = DListPushFront(dlist2, &val4);
	printf("\nFirst element is: %d\n", *(int *)DListGetData(DListBegin(dlist2)));
	assert(9 == *(int *)DListGetData(DListBegin(dlist2)));
	PrintList(dlist2);
	
	puts("-------------- Push back test --------------------");
	iter4 = DListPushBack(dlist2, &val2);
	printf("\nFirst element is: %d\n", *(int *)DListGetData(DListBegin(dlist2)));
	assert(9 == *(int *)DListGetData(DListBegin(dlist2)));
	PrintList(dlist2);
	
	puts("-------------- Push front test --------------------");
	iter4 = DListPushFront(dlist2, &val1);
	printf("\nFirst element is: %d\n", *(int *)DListGetData(DListBegin(dlist2)));
	assert(6 == *(int *)DListGetData(DListBegin(dlist2)));
	count = DListSize(dlist2); 	
	printf("Size of DList is: %lu\n\n", count);
	assert(3 == count);
	PrintList(dlist2);
	
	puts("--------------- Find test ---------------------");
	iter4 = DListFind(dlist2, DListBegin(dlist2), DListEnd(dlist2), &AreEqual, &val2, "gggg");
	printf("\nFirst element is: %d\n", *(int *)DListGetData(iter4));
	assert(12 == *(int *)DListGetData(iter4));

	puts("--------------- Foreach test ---------------------");
	foreach = DListForEach(DListBegin(dlist2), DListEnd(dlist2), &PrintNum, "*");
	assert(1 == foreach);

	puts("\n-------------- Pop front test --------------------");
	DListPopFront(dlist2);	
	assert(2 == DListSize(dlist2));
	assert(9 == *(int *)DListGetData(DListBegin(dlist2)));
	PrintList(dlist2);
	
	puts("\n-------------- Pop back test --------------------");
	DListPopBack(dlist2);
	PrintList(dlist2);
	assert(1 == DListSize(dlist2));
	DListPopBack(dlist2);
	assert(0 == DListSize(dlist2));

	puts("\n-------------- Splice test --------------------");
	iter1 = DListPushFront(dlist2, &val5);
	DListPushFront(dlist2, &val5);
	iter4 = DListPushFront(dlist2, &val5);
	DListPushFront(dlist2, &val5);
	PrintList(dlist2);
	
	DListPushFront(dlist1, &val4);
	iter2 = DListPushFront(dlist1, &val4);
	PrintList(dlist1);

	puts("\n-------------- Splice test --------------------");	
	DListSpliceBefore(DListEnd(dlist2), DListBegin(dlist1), DListEnd(dlist1));
	PrintList(dlist1);
	assert(8 ==  DListSize(dlist2));
	assert(DListNext(iter1) == iter2);
	PrintList(dlist2);
	DListPushFront(dlist1, &val4);
	DListPushFront(dlist1, &val4);
	iter3 = DListPushFront(dlist1, &val4);
	
	puts("\n-------------- Splice test --------------------");
	DListSpliceBefore(DListBegin(dlist1), DListBegin(dlist2), iter1);
	assert(6 ==  DListSize(dlist1));
	assert(5 ==  DListSize(dlist2));
	

	PrintList(dlist2);
	PrintList(dlist1);
	
	DListDestroy(dlist1);
	DListDestroy(dlist2);

	puts("\nSUCCESS - Test 1");
}

/***********************************************************************/
void PrintList(dlist_t *dlist)
{
	dlist_iter_t iter = NULL;

	for(iter = DListBegin(dlist); !DListIsSameIter(iter, DListEnd(dlist)); iter = DListNext(iter))
	{
		printf("%d -> ",  *(int *)DListGetData(iter));
	}
	printf("NULL\n");
}
/***********************************************************************/

 int AreEqual(const void *val, const void *param, const void *data)
 {	
	assert(val && param);
	UNUSED(data);	
	return (*((int *)val) == *((int *)param));
 }

/***********************************************************************/
int PrintNum(void *val, void *param)
{
	printf("%d %s", *(int *)val, (char *)param);
	return 1;
}
