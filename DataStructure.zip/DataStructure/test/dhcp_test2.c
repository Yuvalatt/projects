#include <assert.h> /* assert */
#include <stdlib.h> /* malloc */
#include <stdio.h> /* printf */
#include <time.h>  /* clock() */

#include "../include/dhcp.h"

void TestDHCPBasic(void);
void TestDHCPHard(void);

int main(void)
{
    TestDHCPBasic();
    TestDHCPHard();

    return EXIT_SUCCESS;
}

void TestDHCPBasic(void)
{
    int i = 0;
    unsigned char net_addr[4] = {10, 20, 30, 0};
    unsigned int cidr = 24;
    unsigned char addr[4][4] = {0};
    size_t size = (1 << (32 - cidr)) - 3;
    unsigned char address[4][4] = {{1, 2, 3, 0},
                                   {4, 5, 6, 1},
                                   {7, 8, 9, 2},
                                   {0, 0, 0, 3}};
    

    dhcp_t *dhcp1 = DHCPCreate(net_addr, cidr);
    dhcp_t *dhcp2 = DHCPCreate(net_addr, cidr);

    /*IsValidIp2Free(cidr, 0);
    IsValidIp2Free(cidr, 255);
    IsValidIp2Free(cidr, 254);
*/
    for (i = 0; i < 4; ++i)
    {
        assert(size - i == DHCPCountFree(dhcp1));
        assert(SUCCESS == DHCPAllocIP(dhcp1, address[i], addr[i]));
 /*       printf("addr [0]%u [1]%u [2]%u [3]%u\n", addr[i][0], addr[i][1], addr[i][2], addr[i][3]);*/
    }

    for (i = 4; i < 0; ++i)
    {
        assert(i == (int) DHCPCountFree(dhcp1));
        assert(SUCCESS == DHCPFreeIP(dhcp1, addr[i]));
    }
    
    puts("");

    for (i = 0; i < 4; ++i)
    {
        assert(size - i == DHCPCountFree(dhcp2));
        assert(SUCCESS == DHCPAllocIP(dhcp2, address[0], addr[i]));
        /*printf("addr [0]%u [1]%u [2]%u [3]%u\n", addr[i][0], addr[i][1], addr[i][2], addr[i][3]);*/
    }

    DHCPDestroy(dhcp1);
    DHCPDestroy(dhcp2);
    puts("Basic - SUCCESS"); 
}

void TestDHCPHard(void)
{
    int i = 0;
    time_t start_time;
    unsigned char net_addr[4] = {88, 99, 30, 0};
    unsigned char broadcast[4] = {88, 99, 225, 255};
    unsigned char server[4] = {88, 99, 225, 254};
    unsigned int cidr = 16;
    unsigned char addr[(1 << 16) - 3][4];
    size_t size = (1 << (32 - cidr)) - 3;
    
    dhcp_t *dhcp1 = DHCPCreate(net_addr, cidr);
    dhcp_t *dhcp2 = DHCPCreate(net_addr, cidr);
    
    for (i = 0; i < (int) size; ++i)
    {
        assert(size - i == DHCPCountFree(dhcp1));
        assert(SUCCESS == DHCPAllocIP(dhcp1, NULL, addr[i]));
        /*printf("addr[%d] -- [0]%u [1]%u [2]%u [3]%u\n", i, addr[i][0], addr[i][1], addr[i][2], addr[i][3]);*/
    }
    assert(ALLOCATION_FAILURE == DHCPAllocIP(dhcp1, NULL, addr[i]));

    for (i = 0; i < (int)size; ++i)
    {
        assert(size - (size - i) == DHCPCountFree(dhcp1));
        assert(SUCCESS == DHCPFreeIP(dhcp1, addr[i]));
    }
   /* assert(INVALID_IP == DHCPFreeIP(dhcp1, addr[151]));*/

    assert(INVALID_IP == DHCPFreeIP(dhcp1, net_addr));
    assert(INVALID_IP == DHCPFreeIP(dhcp1, broadcast));
    assert(INVALID_IP == DHCPFreeIP(dhcp1, server));

    DHCPDestroy(dhcp1);


    start_time = clock();

    while (3 > ((clock() - start_time) / CLOCKS_PER_SEC))
    {
        for (i = 0; i < (int) size; ++i)
        {
            assert(size - i == DHCPCountFree(dhcp2));
            assert(SUCCESS == DHCPAllocIP(dhcp2, NULL, addr[i]));
            /*printf("addr[%d] -- [0]%u [1]%u [2]%u [3]%u\n", i, addr[i][0], addr[i][1], addr[i][2], addr[i][3]);*/
        }
        assert(ALLOCATION_FAILURE == DHCPAllocIP(dhcp2, NULL, addr[i]));

        for (i = 0; i < (int) size; ++i)
        {
            assert(size - (size - i) == DHCPCountFree(dhcp2));
            assert(SUCCESS == DHCPFreeIP(dhcp2, addr[i]));
        }
        assert(INVALID_IP == DHCPFreeIP(dhcp2, addr[151]));
    }
/*
    for (i = 1; i < (int) (size - 1); i += 2)
    {
        assert(size - (size - (i/2) == DHCPCountFree(dhcp2)));
        assert(SUCCESS == DHCPFreeIP(dhcp2, addr[i]));
    }
*/    
    DHCPDestroy(dhcp2);

    puts("Hard - SUCCESS");
}

