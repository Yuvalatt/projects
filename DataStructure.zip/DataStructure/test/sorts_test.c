#include <stdio.h> 
#include <assert.h>  	/* assert */ 
#include <stdlib.h>  	/* EXIT_SUCCESS */
#include <string.h> 	/* memcpy */
#include <time.h>	/* clock */
#include <math.h>
#include "../include/sorts.h"

#define ARRAY_SIZE 5000
#define RANGE 10
#define UNUSED(x)(void)(x)

typedef void (*sort_func_t)(void *base, size_t nmemb, size_t size, cmp_func_t cmp_func);
void SortTest(sort_func_t sort_func, int *arr, size_t size, size_t element_size, cmp_func_t cmp_func);
static void CompareArrays(int arr1[], int arr2[], size_t size);

static void ArrayInit(int arr[], size_t elements);
static void PrintArray(int arr[], size_t elements);
static int IsBefore(const void *num1, const void *num2);

static int IsBigger(const void *num1, const void *num2);
static size_t GetElementKey(const void *element, const void *args);
static size_t GetKey(const void *element, const void *args); /* Returns the entire number as a key */
static int CmpFunc(const void *num1, const void *num2);

int main()
{
	size_t i = 0;	
	clock_t start_t, end_t, total_t;
	int merge_arr[] = {12, 14, 13, 5, 6, 2, 8};
	int data[] = {14, 2, 7, 5, 19, 12, 13, 15};	
	 int sorted[] = {1, 2, 3, 4, 5, 6, 7, 8};
	
	void *found = 0;
	int val = 3;
	
	int *arr = NULL;	
	int *arr2 = NULL;
	int *arr3 = NULL;
	int *arr4 = NULL;
	int *arr5 = NULL;
	

	arr = (int *)malloc(ARRAY_SIZE * sizeof(int));
	if (NULL != arr)
	{
		ArrayInit(arr, ARRAY_SIZE);
	}
	/*arr2 = (int *)malloc(ARRAY_SIZE * sizeof(int));
	if (NULL != arr2)
	{
		memcpy(arr2, arr, sizeof(int) * ARRAY_SIZE);
	}
	arr3 = (int *)malloc(ARRAY_SIZE * sizeof(int));
	if (NULL != arr3)
	{
		memcpy(arr3, arr, sizeof(int) * ARRAY_SIZE);
	}*/
	/*arr4 = (int *)malloc(ARRAY_SIZE * sizeof(int));
	if (NULL != arr4)
	{
		memcpy(arr4, arr, sizeof(int) * ARRAY_SIZE);
		
	}
*/
	arr5 = (int *)malloc(ARRAY_SIZE * sizeof(int));
	if (NULL != arr5)
	{
		memcpy(arr5, arr, sizeof(int) * ARRAY_SIZE);	
	}
	
	/*puts("Original array:");
	PrintArray(arr, ARRAY_SIZE);
	*/
	puts("quick sort:");
	start_t = clock();
	qsort(arr, ARRAY_SIZE, sizeof(int), &IsBefore);
	end_t = clock();
	printf("Total time in SEC: %ld\n", end_t - start_t);

	/*puts("Radix sort Test:");
	TestRadixSort(arr3, ARRAY_SIZE, sizeof(int), GetElementKey, NULL, 256);
	PrintArray(arr3, ARRAY_SIZE);*/

	/*puts("\nRadix sort:");
	start_t = clock();
	RadixSort(arr4, ARRAY_SIZE, sizeof(int), GetKey, NULL, 4);
	end_t = clock();
	printf("Total time in SEC: %ld\n", end_t - start_t);*/
	/*PrintArray(arr4, ARRAY_SIZE);*/
	
	/*SortTest(&qsort, arr2, ARRAY_SIZE, sizeof(int), &IsBefore);	
	
	puts("\nBubbleSort:");
	SortTest(&BubbleSort, arr, ARRAY_SIZE, sizeof(int), &IsBefore);
		
	puts("\nSelectionSort:");
	SortTest(&SelectionSort, arr3, ARRAY_SIZE, sizeof(int), &IsBefore);
	
	puts("\nInsertionSort:");
	SortTest(&InsertionSort, arr4, ARRAY_SIZE, sizeof(int), &IsBefore);
	
	CompareArrays(arr, arr2, ARRAY_SIZE);
	CompareArrays(arr3, arr2, ARRAY_SIZE);
	CompareArrays(arr4, arr2, ARRAY_SIZE);*/

	/*CompareArrays(arr, arr4, ARRAY_SIZE);*/

	/*puts("\n----------Merge sort-------------");
	SortTest(&MergeSort, arr5, ARRAY_SIZE, sizeof(int), &IsBefore);
	CompareArrays(arr, arr5, ARRAY_SIZE);*/
	/*MergeSort(merge_arr, 7, sizeof(int), &IsBefore);
	PrintArray(merge_arr, 7);*/

	/*PrintArray(heap_data, 8);
	puts("Heapsort:");
	start_t = clock();
	HeapSort(arr5, ARRAY_SIZE, sizeof(int), &IsBefore);
	end_t = clock();
	printf("Total time in SEC: %ld\n", end_t - start_t);

	CompareArrays(arr, arr5, ARRAY_SIZE);*/
	/*HeapSort(heap_data, 8, sizeof(int), &IsBefore);
	puts("\n---------------------------------");
	PrintArray(heap_data, 8);*/
	/*QuickSort(data, 8, sizeof(int), &IsBefore);
	PrintArray(data, 8);
	*/
	
	puts("\nQuick:");
	start_t = clock();	
	QuickSort(arr5, ARRAY_SIZE, sizeof(int), &IsBefore);	
	end_t = clock();	
	printf("Total time in SEC: %ld\n", end_t - start_t);
	CompareArrays(arr, arr5, ARRAY_SIZE);

	
	/*printf("Data found is: %d \n", *(int *)BinarySearch(sorted, 8, sizeof(int), &val, CmpFunc));
*/
	/*free(arr);
	free(arr4);*/

	free(arr5);
	return EXIT_SUCCESS;
}

void SortTest(sort_func_t sort_func, int *arr, size_t size, size_t element_size, cmp_func_t cmp_func)
{	
	clock_t start_t, end_t, total_t;
	
	start_t = clock();
	
	sort_func(arr, size, element_size, cmp_func);
	
	end_t = clock();
  	
  	total_t = (end_t - start_t);
    
    printf("Total time in SEC: %ld\n", total_t);
}

static int IsBefore(const void *num1, const void *num2)
{	
	return (*(int *)num1 > *(int *)num2);
} 

static int CmpFunc(const void *num1, const void *num2)
{	
	return (*(int *)num1 - *(int *)num2);
}

static void CompareArrays(int arr1[], int arr2[], size_t size)
{
	size_t i = 0;
	for (i= 0; i< size; i++)
	{
		if (arr1[i]!= arr2[i])
		{
			printf("\n\nElement %lu is not equal\n", i);
		}
		assert(arr1[i] == arr2[i]);
	}
	puts("\nSUCCESS Compare arrays");
}

/* Init arrays - random from 1 - 100,000 */
static void ArrayInit(int arr[], size_t elements)
{
	size_t i = 0;
	srand(time(0));

	for (i = 0; i < elements; i++)
	{
		arr[i] = rand() % 100000;
	}
}

static void PrintArray(int arr[], size_t elements)
{
	size_t i = 0;

	for (i = 0; i < elements; i++)
	{
		printf("%d ", arr[i]);
	}
	puts("");
}

static size_t GetKey(const void *element, const void *args) 
{	
	assert(element);
	
	UNUSED(args);
	return (*(int *)element);
}

static size_t GetElementKey(const void *element, const void *args) /* Returns relevant byte */ 
{			
	unsigned int num = *(unsigned int *)element;
	int i = *(int *)args;

	assert(element);
	
	return ((num >> (i * 8)) & 0xff);
}
