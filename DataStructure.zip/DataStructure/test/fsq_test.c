#include <stdio.h>
#include <stdlib.h> 		/* EXIT_SUCCESS */
#include <assert.h> 		/* assert       */
#include <string.h> 		/* strlen       */
#include "../include/fsq.h"

#define FSQ_SIZE 10

void FSQTest(void);

int main()
{
	FSQTest();
	
	return EXIT_SUCCESS;
}

void FSQTest()
{
	int i = 0;

	fsq_t *fsq = FSQCreate(FSQ_SIZE);
	if (NULL == fsq)
	{
		fputs("Error: malloc failure.", stderr);
	}

	for (i = 0; i < 10; ++i)
	{
		FSQEnqueue(fsq, i);
	}

	for (i = 0; i < 10; ++i)
	{
		int val = FSQDequeue(fsq);
		printf("%d \n", val);
		assert(i == val);
	}

	FSQDestroy(fsq);
	
	puts("SUCCESS - FSQTest :)");
}
