#include "../include/avl_tree.h"

#include <stdio.h>
#include <stdlib.h> /* EXIT_SUCCESS */
#include <assert.h> /* assert */
#include <time.h>   /* rand */

#define UNUSED(X)(void)(X)
#define TREE_SIZE 5000

static int IsBefore(const void *data1, const void *data2, const void *param);
int PrintTreeForEach(avl_t *tree);
static int IsEven(const void *data, const void *param);
static int IsUneven(const void *data, const void *param);
void PrintList(dlist_t *dlist);
int PrintNum(void *val, void *param);
void AVLTest2(void);

void AVLTreeTest(void);
void AVLRandomTest(void);


int match_arr[100];

int main()
{
	AVLTreeTest();
	AVLRandomTest();
	AVLTest2();

	return EXIT_SUCCESS;
}

void AVLTreeTest(void)
{
	int data[] = {41, 32, 56, 43, 16, 2, 42, 90, 29, 67};
	
	size_t tree_height = 0;
	dlist_t *found_list = DListCreate();
	avl_t *tree = AVLTreeCreate(&IsBefore, NULL);
	size_t size = AVLTreeCount(tree);

	int val1 = 67;
	int val2 = 10;
	int val3 = 163;
	int val4 = 56;

	puts("\n----------------------------------");	
	printf("\nSize of tree is: %lu\n", size);
	printf("Is tree empty? %s \n", (1 == AVLTreeIsEmpty(tree) ? "YES" : "NO"));
	assert(1 == AVLTreeIsEmpty(tree));
	
	AVLTreeInsert(tree, &data[0]);

	tree_height = AVLTreeHeight(tree);
	printf("\nAVL tree height is: %lu\n", tree_height);
	assert(1 == tree_height);

	AVLTreeInsert(tree, &data[1]);
	AVLTreeInsert(tree, &data[2]);

	tree_height = AVLTreeHeight(tree);
	printf("AVL tree height is: %lu\n", tree_height);
	assert(2 == tree_height);

	AVLTreeInsert(tree, &data[3]);
	AVLTreeInsert(tree, &data[4]);
	AVLTreeInsert(tree, &data[5]);
	AVLTreeInsert(tree, &data[6]);
	AVLTreeInsert(tree, &data[7]);
	AVLTreeInsert(tree, &data[8]);
	AVLTreeInsert(tree, &data[9]);
	
	tree_height = AVLTreeHeight(tree);
	printf("AVL tree height is: %lu\n", tree_height);
	assert(4 == tree_height);

	size = AVLTreeCount(tree);
	printf("\nSize of tree is: %lu\n", size);
	assert(10 == size);

	printf("Is tree empty? %s \n", (1 == AVLTreeIsEmpty(tree) ? "YES" : "NO"));
	assert(0 == AVLTreeIsEmpty(tree));
	puts("");
	
	AVLTreeForEach(tree, &PrintNum, NULL);

	printf("\n\nFind value - found %d\n", *(int *)AVLTreeFind(tree, &val1));
	printf("Find value - not found %d\n\n", (NULL == AVLTreeFind(tree, &val2) ? 0 : *(int *)AVLTreeFind(tree, &val2)));

	assert(0 == (NULL == AVLTreeFind(tree, &val2) ? 0 : *(int *)AVLTreeFind(tree, &val2)));
	assert(67 == *(int *)AVLTreeFind(tree, &val1));

	AVLTreeInsert(tree, &val3);
	AVLTreeForEach(tree, &PrintNum, NULL);

	puts("\n\nMultifind - Even numbers:");
	AVLTreeMultiFind(tree, found_list, &IsEven, NULL);
	PrintList(found_list);
	
	/*assert(2 == match_arr[0]);
	assert(16 == match_arr[1]);
	assert(32 == match_arr[2]);
	assert(42 == match_arr[3]);
	assert(90 == match_arr[4]);
	assert(56 == match_arr[5]);*/

	AVLTreeRemove(tree, &val4);
	puts("\nAfter remove (56):");
	AVLTreeForEach(tree, &PrintNum, NULL);

	puts("\n\vMultiremove - Uneven numbers");
	AVLTreeMultiRemove(tree, &IsUneven, NULL);
	AVLTreeForEach(tree, &PrintNum, NULL);
	
	size = AVLTreeCount(tree);
	printf("\nSize of tree is: %lu\n", size);
	assert(5 == size);
	tree_height = AVLTreeHeight(tree);
	printf("\nAVL tree height is: %lu\n", tree_height);

	
	AVLTreeDestroy(tree);
	
	DListDestroy(found_list);	
	tree = NULL;

	puts("\n\nSUCCESS - AVLTree Test");
}

/***********************************************************************/
void AVLRandomTest(void)
{
	size_t i = 0;
	avl_t *tree = NULL;
	/*int data = 0;*/
	size_t tree_height = 0;
	int array[TREE_SIZE] ={0};

	srand(time(0));

	puts("\n----------------------------------");
	tree = AVLTreeCreate(&IsBefore, NULL);

	for (i = 0; i < TREE_SIZE; i++)
	{
		/*data = rand() % 10000;

		while (NULL != AVLTreeFind(tree, &data))
		{
			data = rand() % 10000;
		}*/

		/*array[i] = data;*/

		array[i] = i + 1;
		AVLTreeInsert(tree, &array[i]);
	}

	puts("");
	
	tree_height = AVLTreeHeight(tree);
	printf("AVL tree height is: %lu\n", tree_height);
	assert(13 == tree_height);
	AVLTreeDestroy(tree);
	tree = NULL;

	puts("\n\nSUCCESS - AVLRandomTest Test");
}

void AVLTest2(void)
{
	size_t i = 0;
	size_t tree_height = 0;

	avl_t *tree1 = NULL;
	avl_t *tree2 = NULL;
	avl_t *tree3 = NULL;

	int arr1[] = {1, 2, 3, 4, 5, 6, 7};
	int arr2[] = {1, 2, 3, 4, 5, 6, 7};
	int arr3[] = {1, 2, 7, 6, 3, 4, 5};

	puts("\n----------------------------------");

	tree1 = AVLTreeCreate(&IsBefore, NULL);
	tree2 = AVLTreeCreate(&IsBefore, NULL);
	tree3 = AVLTreeCreate(&IsBefore, NULL);

	for (i = 0; i < 7; i++)
	{
		AVLTreeInsert(tree1, &arr1[i]);
		AVLTreeInsert(tree2, &arr2[i]);
		AVLTreeInsert(tree3, &arr3[i]);
	}
	puts("");
	
	tree_height = AVLTreeHeight(tree1);
	printf("AVL tree height is: %lu\n", tree_height);
	assert(3 == tree_height);

	tree_height = AVLTreeHeight(tree2);
	printf("\nAVL tree height is: %lu\n", tree_height);	
	assert(3 == tree_height);
	
	tree_height = AVLTreeHeight(tree3);
	printf("\nAVL tree height is: %lu\n", tree_height);	
	assert(4 == tree_height);
	
	AVLTreeDestroy(tree1);
	AVLTreeDestroy(tree2);
	AVLTreeDestroy(tree3);

	puts("\n\nSUCCESS - AVLTest2");
}


/***********************************************************************/
static int IsBefore(const void *data1, const void *data2, const void *param)
{
	UNUSED(param);
	
	if(*(int *)data1 < *(int *)data2)
	{
		return -1;
	}
	else if (*(int *)data1 > *(int *)data2)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

/***********************************************************************/
static int IsEven(const void *data, const void *param)
{
	UNUSED(param);
	
	return (0 == *(int *)data % 2);
}

/***********************************************************************/
static int IsUneven(const void *data, const void *param)
{
	UNUSED(param);
	
	return (0 != *(int *)data % 2);
}

/***********************************************************************/
int PrintNum(void *val, void *param)
{
	UNUSED(param);
	printf("%d ", *(int *)val);
	return 1;
}

/***********************************************************************/
void PrintList(dlist_t *dlist)
{
	dlist_iter_t iter = NULL;
	size_t i = 0;

	for(iter = DListBegin(dlist); !DListIsSameIter(iter, DListEnd(dlist)); iter = DListNext(iter))
	{
		printf("%d ", *(int *)DListGetData(iter));
		match_arr[i] = *(int *)DListGetData(iter);
		++i;
	}
	puts("");
}
