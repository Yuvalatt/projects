#include "/home/rd52/git/ds/include/barr.h"

#include <stdio.h>
#include <assert.h> /* assert */
#include <stdlib.h> /* EXIT_SUCCESS */

#define BARR_SIZE 64
#define LUT_SIZE 256 

void BarrAllOnTest(void);
void BarrAllOffTest(void);
void BarrSetOnTest(void);
void BarrSetOffTest(void);
void BarrSetBitTest(void);
void BarrToggleBitTest(void);
void BarrIsOnTest(void);
void BarrIsOffTest(void);
void BarrRotRTest(void);
void BarrRotLTest(void);
void BarrMirrorTest(void);
void BarrCountOnTest(void);
void BarrCountOffTest(void);
void BarrLUTMirrorTest(void);
void BarrLUTCountOnTest(void);
static void PrintBarr(barr_t barr);

void BarrAllOnTest(void)
{
	assert(-1UL == BarrAllOn());
	puts("SUCCESS - BarrAllOnTest");
}

void BarrAllOffTest(void)
{
	assert( 0UL == BarrAllOff());
	puts("SUCCESS - BarrAllOffTest");
}

void BarrSetOnTest(void)
{
	assert(8 == BarrSetOn(0UL, 3));
	assert(4 == BarrSetOn(0UL, 2));
	assert(1 == BarrSetOn(0UL, 0));
	puts("SUCCESS - BarrSetOnTest");
}

void BarrSetOffTest(void)
{
	assert(0UL == BarrSetOff(0UL,8));
	assert(0xC8 == BarrSetOff(0xCC,2));
	assert(0xF7 == BarrSetOff(0xFF,3));
	puts("SUCCESS - BarrSetOffTest");
}

void BarrSetBitTest(void)
{
	assert(-1UL == BarrSetBit(-1UL, 8, 1));
	assert(0UL == BarrSetBit(0UL, 0, 0));
	assert(0x101 == BarrSetBit(1UL, 8, 1));
	assert(1UL == BarrSetBit(1UL, 8, 0));
	puts("SUCCESS - BarrSetBitTest");

}

void BarrToggleBitTest(void)
{
	 assert(8 == BarrToggleBit(0UL, 3));
	 assert(0xFFFFFFFFFFFFFFFB == BarrToggleBit(-1UL, 2));
	 assert(0xFFFF0000CCCCCCCD == BarrToggleBit(0xFFFF0000CCCCCCCC, 0));
	 assert(0xFFFF0000CCCCCCC4 == BarrToggleBit(0xFFFF0000CCCCCCCC, 3));
	 puts("SUCCESS - BarrToggleBitTest");
}

void BarrIsOnTest(void)
{
	assert(1 == BarrIsOn(-1UL ,4));
	assert(0 == BarrIsOn(142UL ,4));
	assert(1 == BarrIsOn(142UL ,3));
	puts("SUCCESS - BarrIsOnTest");
}

void BarrIsOffTest(void)
{
	assert(0 == BarrIsOff(-1UL ,4));
	assert(1 == BarrIsOff(142UL ,4));
	assert(1 == BarrIsOff(142UL ,4));
	assert(0 == BarrIsOff(142UL ,3));
	puts("SUCCESS - BarrIsOffTest");
}
	
		
void BarrRotRTest(void)
{
	assert(1UL == BarrRotR(8UL, 3));
	assert(-1UL == BarrRotR(-1UL, 5));
	assert(0UL == BarrRotR(0UL, 64));
	assert(0xF00000000000000F == BarrRotR(0xFF, 4));
	puts("SUCCESS - BarrRotRTest");
}

void BarrRotLTest(void)
{
	assert(8UL == BarrRotL(1UL, 3));
	assert(-1UL == BarrRotL(-1UL, 5));
	assert(0UL == BarrRotL(0UL, 64));
	assert(0xFF00 == BarrRotL(0xFF, 8));
	puts("SUCCESS - BarrRotLTest");
}

void BarrCountOnTest(void)
{
	assert(64 == BarrCountOn(-1UL));
	assert(0 == BarrCountOn(0UL));
	assert(1 == BarrCountOn(8UL));
	assert(2 == BarrCountOn(12UL));
	assert(37 == BarrCountOn(0xFFFF00D0CCCDCCDC));
	puts("SUCCESS - BarrCountOnTest");
}

void BarrLUTCountOnTest(void)
{
	assert(64 == BarrCountOn(-1UL));
	assert(0 == BarrCountOn(0UL));
	assert(1 == BarrCountOn(8UL));
	assert(2 == BarrCountOn(12UL));
	assert(37 == BarrCountOn(0xFFFF00D0CCCDCCDC));
	puts("SUCCESS - BarrLUTCountOnTest");
}

void BarrCountOffTest(void)
{
	assert(0 == BarrCountOff(-1UL));
	assert(64 == BarrCountOff(0UL));
	assert(63 == BarrCountOff(8UL));
	assert(62 == BarrCountOff(12UL));
	assert(27 == BarrCountOff(0xFFFF00D0CCCDCCDC));
	puts("SUCCESS - BarrCountOffTest");
}

void BarrMirrorTest(void)
{
	assert(0UL == BarrMirror(0UL));
	assert(-1UL == BarrMirror(-1UL));
	assert(0x333333330000FFFF == BarrMirror(0xFFFF0000CCCCCCCC));
	puts("SUCCESS - BarrMirrorTest");
}

void BarrLUTMirrorTest(void)
{
	assert(0UL == BarrMirror(0UL));
	assert(-1UL == BarrMirror(-1UL));
	assert(0x333333330000FFFF == BarrLUTMirror(0xFFFF0000CCCCCCCC));
	puts("SUCCESS - BarrLUTMirrorTest");
}

static void PrintBarr(barr_t barr)
{
	size_t i = 0;
	for (i = 0; i < BARR_SIZE; i++) 
	{	    
		printf("%d ", ((barr & (1UL << (BARR_SIZE - i - 1))) ? 1 : 0));   	
	}
	puts("");
}

int main()
{
	BarrAllOnTest();
	BarrAllOffTest();
	BarrSetOnTest();
	BarrSetOffTest();
	BarrSetBitTest();
	BarrToggleBitTest();
	BarrIsOnTest();
	BarrIsOffTest();
	BarrCountOnTest();
	BarrLUTCountOnTest();
	BarrCountOffTest();
	BarrRotRTest();
	BarrRotLTest();
	BarrMirrorTest();
	BarrLUTMirrorTest();
	
	return EXIT_SUCCESS;
}
