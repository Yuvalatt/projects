#include <stdio.h>
#include <stdlib.h>       		/*  EXIT_SUCCESS */
#include <assert.h>       	        /*    assert     */
#include "../include/heap.h"

#define UNUSED(x)(void)(x)
#define BOLDBLUE "\033[1m\033[34m"

void PrintHeap(heap_t *heap);

static int IsBefore(const void *data1, const void *data2, const void *param);
static int IsMatch(const void *data, const void *data_to_find);
static void HeapTest(void);

int main(void)
{
	HeapTest();	
	return EXIT_SUCCESS;
}

static void HeapTest(void)
{
	heap_t *heap = NULL;
	void *removed = NULL;
	
	int data[] = {14, 2, 7, 5, 19, 12, 13, 15};
	
	heap = HeapCreate(&IsBefore, NULL);
	assert(heap);
	assert(0 == HeapSize(heap));
	assert(1 == HeapIsEmpty(heap));
	assert(0 == HeapPush(heap, &data[0]));
	assert(14 == *(int *)HeapPeek(heap));
	assert(1 == HeapSize(heap));
	assert(0 ==  HeapIsEmpty(heap));
	assert(0 == HeapPush(heap, &data[1]));
	assert(2 == HeapSize(heap));
	assert(2 ==  *(int *)HeapPeek(heap));
	assert(0 == HeapPush(heap, &data[2]));
	assert(2 ==  *(int *)HeapPeek(heap));
	assert(3 == HeapSize(heap));
	assert(0 == HeapPush(heap, &data[3]));
	assert(0 == HeapPush(heap, &data[4]));
	assert(0 == HeapPush(heap, &data[5]));
	assert(0 == HeapPush(heap, &data[6]));
	assert(0 == HeapPush(heap, &data[7]));
	assert(2 ==  *(int *)HeapPeek(heap));
	assert(8 == HeapSize(heap));

	puts("\n------Print Heap-------");
	/*PrintHeap(heap);		
	*/
	assert(2 == *(int *)HeapPop(heap));	
	
	puts("\n------Print Heap-------");
	/*PrintHeap(heap);
	*/
	removed = HeapRemove(heap, &IsMatch, &data[4], NULL);
	assert(19 == *(int *)removed);
	
	puts("\n------Print Heap-------");
	/*PrintHeap(heap);
	*/
	/* Add test - PUSH data that is allready found */
	/*assert(0 != HeapPush(heap, &val_ptr[7]));
	*/
	
	removed = HeapRemove(heap, &IsMatch, &data[3], NULL);
	assert(5 == *(int *)removed);
	removed = HeapRemove(heap, &IsMatch, &data[5], NULL);
	assert(12 == *(int *)removed);
	assert(7 == *(int *)HeapPop(heap));
	assert(13 ==  *(int *)HeapPeek(heap));
	assert(13 == *(int *)HeapPop(heap));
	assert(14 == *(int *)HeapPop(heap));
	assert(15 == *(int *)HeapPop(heap));	
	assert(0 == HeapSize(heap));
	assert(1 == HeapIsEmpty(heap));
	
	HeapDestroy(heap);

	printf("\n\n%sSUCCESS - Heap Test\n", BOLDBLUE);		
}

/* Minimum heap cmp_func */
static int IsBefore(const void *data1, const void *data2, const void *param)
{
	UNUSED(param);
	
	if (*(int *)data1 < *(int *)data2)
	{
		return 1;
	}
	return 0;
}

static int IsMatch(const void *data, const void *data_to_find)
{
	return (*(int *)data == *(int *)data_to_find);
}
