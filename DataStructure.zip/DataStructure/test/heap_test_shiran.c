#include <assert.h>
#include <stdio.h>
#include "../include/heap.h"

static void TestBuildMaxHeap(void);
static void TestBuildMinHeap(void);
int CmpFuncMax(const void *data1, const void *data2, const void *param);
int CmpFuncMin(const void *data1, const void *data2, const void *param);
int Find(const void *data, const void *data_to_find);

int main(void)
{
	TestBuildMaxHeap();
	TestBuildMinHeap();
	
	return EXIT_SUCCESS;
}

static void TestBuildMaxHeap(void)
{
	static int arr[] = {9, 10 , 8, 15, 11 , 20, 12, 1, 2 ,4 , 25};
	/*					25
	 *				  /    \
	 *				20      15
	 *			   / \      / \
	 *			 9    11    8   12
	 *			/ \   / \
	 *		   1  2  4   10
	 */
	int  i = 0;
	heap_t * heap = HeapCreate(CmpFuncMax, NULL);

	assert(0 == HeapSize(heap));
	assert(1 == HeapIsEmpty(heap));

	for (i = 0; i < 11 ; ++i)
	{
		HeapPush(heap, &arr[i]);
		assert(i+1 == HeapSize(heap));
		assert(0 == HeapIsEmpty(heap));

	}
	printf("%p \n",HeapPeek(heap));
	printf("%d \n", *(int *)HeapPeek(heap));
	assert(25 == *(int *)HeapPeek(heap));
	HeapPop(heap);
	/*					20
	 *				  /    \
	 *				11      15
	 *			   / \      / \
	 *			 9    10   8   12
	 *			/ \   /
	 *		   1  2  4
	 */


	assert(20 == *(int *)HeapPeek(heap));
	assert(10 == HeapSize(heap));

	HeapPop(heap);
	/*					15
	 *				  /    \
	 *				11      12
	 *			   / \      / \
	 *		 	 9    10   8   4
	 *			/ \
	 *		   1  2
	 */
	printf("HEAP PEEK: %d \n", *(int *)HeapPeek(heap));
	assert(15 == *(int *)HeapPeek(heap));
	assert(9 == HeapSize(heap));


	HeapRemove(heap, Find, &arr[1], NULL);
	/*					15
	 *				  /    \
	 *				11      12
	 *			   / \      / \
	 *		 	 2    10   8   4
	 *			/
	 *		   1
	 */
	assert(15 == *(int *)HeapPeek(heap));
	assert(8 == HeapSize(heap));

	HeapDestroy(heap);
}

static void TestBuildMinHeap(void)
{
	static int arr[] = {17, 15 , 14, 16, 10 , 13, 9, 6, 11 ,12 , 3, 2, 4, 1, 5};
	/*					1
	 *				 /     \
	 *			   6         2
	 *			  / \       /  \
	 *			11   9     4     3
	 *		   /\   /\     /\    /\
	 *		 17 14 12 16  15 10 13 5
	 */
	int  i = 0;
	int removed_data = 0;
	heap_t * heap = HeapCreate(CmpFuncMin, NULL);

	assert(0 == HeapSize(heap));
	assert(1 == HeapIsEmpty(heap));

	for (i = 0; i < 15 ; ++i)
	{
		HeapPush(heap, &arr[i]);
		assert(i+1 == HeapSize(heap));
		assert(0 == HeapIsEmpty(heap));
	}
	assert(1 == *(int *)HeapPeek(heap));


	HeapPop(heap);
	/*					2
	 *				 /     \
	 *			   6         3
	 *			  / \       /  \
	 *			11   9     4     5
	 *		   /\   /\     /\    /
	 *		 17 14 12 16  15 10 13
	 */


	assert(2 == *(int *)HeapPeek(heap));
	assert(14 == HeapSize(heap));

	HeapPop(heap);
	/*					3
	 *				 /     \
	 *			   6         5
	 *			  / \       /  \
	 *			11   9     4    13
	 *		   /\   /\     /\
	 *		 17 14 12 16  15 10
	 */

	assert(3 == *(int *)HeapPeek(heap));
	assert(13 == HeapSize(heap));

	HeapPop(heap);
	/*					4
	 *				 /     \
	 *			   6         5
	 *			  / \       /  \
	 *			11   9     10   13
	 *		   /\   /\     /
	 *		 17 14 12 16  15
	 */

	assert(4 == *(int *)HeapPeek(heap));
	assert(12 == HeapSize(heap));

	removed_data = *(int *)HeapRemove(heap, Find, &arr[6], NULL);
	/*					4
	 *				 /     \
	 *			   6         5
	 *			  / \       /  \
	 *			11   15     10   13
	 *		   /\    /\
	 *		 17 14  12 16
	 */
	assert(9 == removed_data);
	assert(4 == *(int *)HeapPeek(heap));
	assert(11 == HeapSize(heap));

	removed_data = *(int *)HeapRemove(heap, Find, &arr[7], NULL);
	/*					4
	 *				 /     \
	 *			   11         5
	 *			  / \       /  \
	 *			14   15     10   13
	 *		   /\    /
	 *		 17 16  12
	 */
	assert(6 == removed_data);
	assert(4 == *(int *)HeapPeek(heap));
	assert(10 == HeapSize(heap));

	assert(NULL == HeapRemove(heap, Find, &arr[13], NULL));
	HeapDestroy(heap);
}
/* return value: positive, 0, or negative when data1 is upper than, equal to or lower than data2 accordingly */
int CmpFuncMax(const void *data1, const void *data2, const void *param)
{
	return (*(int *)data1 - *(int *)data2);
}
int CmpFuncMin(const void *data1, const void *data2, const void *param)
{
	return -(*(int *)data1 - *(int *)data2);
}
/*  True - 1, False - 0 */
int Find(const void *data, const void *data_to_find)
{
	return (*(int *)data == *(int *)data_to_find);
}
