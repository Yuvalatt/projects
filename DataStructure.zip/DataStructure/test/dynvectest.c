#include "../include/dynvec.h"
#include <stdio.h>
#include <stdlib.h> /* EXIT_SUCCESS */
#include <assert.h> /* assert */

void Test1(void);
void Test2(void);

int main()
{
	Test1();
	Test2();
	
	return EXIT_SUCCESS;
}

void Test1()       /* Case 1 - Num of elements in vector = 0 */
{
	size_t size = 0;
	size_t cap = 0;
	int x = 26;
	int *ptr = 0;
	int check = 0;
	
	dv_t *dynvec = DVCreate(0, 4);
	size = DVSize(dynvec);
	assert(0 == size);
	cap = DVCapacity(dynvec);
	assert(50 == cap);
	check = DVPushBack(dynvec, &x);
	assert(0 == check);
	size = DVSize(dynvec);
	assert(1 == size);
	ptr = DVGetItemAddress(dynvec, 0);
	assert(26 == *ptr);
	cap = DVCapacity(dynvec);
	assert(50 == cap);
	DVDestroy(dynvec);
	
	puts("SUCCESS - Test 1");		
}

void Test2(void)        /* Case 2 - Num of elements in vector > 0 */
{	
	size_t size = 0;
	size_t cap = 0;
	int *ptr = 0;
	int x = 26;
	int y = 8;
	int z = 4;
	int check = 0;
	
	dv_t *dynvec = DVCreate(10, 4);
	size = DVSize(dynvec);
	assert(10 == size);
	cap = DVCapacity(dynvec);
	assert(10 == cap);
	check = DVPushBack(dynvec, &x);
	assert(0 == check);
	check = DVPushBack(dynvec, &y);
	assert(0 == check);
	size = DVSize(dynvec);
	assert(12 == size);
	cap = DVCapacity(dynvec);
	assert(20 == cap);
	DVPopBack(dynvec);
	size = DVSize(dynvec);
	assert(11 == size);
	cap = DVCapacity(dynvec);
	assert(20 == cap);
	check = DVPushBack(dynvec, &z);
	assert(0 == check);
	ptr = DVGetItemAddress(dynvec, 10);
	assert(26 == *ptr);
	ptr = DVGetItemAddress(dynvec, 11);
	assert(4 == *ptr);
	DVDestroy(dynvec);	
	
	puts("SUCCESS - Test 2");	
}








