#include "../include/calculator.h"

#include <stdio.h>
#include <stdlib.h> /* EXIT_SUCCESS */
#include <assert.h> /* assert */

void CalcTest(void);

int main()
{
	CalcTest();	
	return EXIT_SUCCESS;
}

/***********************************************************************/

void CalcTest()
{	
	status_t stat = SUCCESS;
	
	assert(8 == Calculator("3+5", &stat));
   	assert(stat == SUCCESS);

	assert(16 == Calculator("2+3*5-1", &stat));
   	assert(stat == SUCCESS);

	assert(-2 == Calculator("8-10*1", &stat));
   	assert(stat == SUCCESS);

	assert(51 == Calculator("3+5*(2+8)-2", &stat));
   	assert(stat == SUCCESS);

	assert(51 == Calculator("3+5*(2+8)-2", &stat));
   	assert(stat == SUCCESS); 
	
	assert(51 == Calculator("3	+ 5    *(\r2+\t8) - \n2", &stat));
   	assert(stat == SUCCESS);

	assert(0 == Calculator("3+a5*t(2+8)-2", &stat));
   	assert(stat == INVALID_NUM);	
	
	assert(0 == Calculator("3+5*t(2+8)-2", &stat));
   	assert(stat == INVALID_NUM);

	assert(0 == Calculator("3+5*(2y+8)-2", &stat));
   	assert(stat == INVALID_OPERATOR);

	assert(81 == Calculator("3^2^2", &stat));
   	assert(stat == SUCCESS);

	assert(3 == Calculator("3^(2-1)^2", &stat));
   	assert(stat == SUCCESS);

	assert(8 == Calculator("   5+2*(10+6) / 4-5", &stat));
   	assert(stat == SUCCESS);

	assert(43 == Calculator("3*(5+(2+8))-2", &stat));
   	assert(stat == SUCCESS);

	assert(43 == Calculator("3*(5+(2+8))-2", &stat));
   	assert(stat == SUCCESS);

	assert(5 == Calculator("3*5 + -20/2", &stat));
   	assert(stat == SUCCESS);

	assert(0 == Calculator("3*5 + -*20/2", &stat));
   	assert(stat == INVALID_NUM);

	assert(20 == Calculator("-2*-5 + 20/2", &stat));
   	assert(stat == SUCCESS);

	assert(8 == Calculator("(8)", &stat));
   	assert(stat == SUCCESS);
	
	assert(0 == Calculator("()", &stat));
   	assert(stat == INVALID_NUM);

	assert(0 == Calculator("3*(5+((2+8))-2", &stat));
   	assert(stat == INVALID_OPERATOR);

	assert(0 == Calculator("3*(5+(2+8))))-2", &stat));
   	assert(stat == INVALID_OPERATOR);

	assert(0 == Calculator("3*(5+((2+(8)))-2", &stat));
   	assert(stat == INVALID_OPERATOR);
	

	puts("\nSUCCESS - Calculator Test");
}

