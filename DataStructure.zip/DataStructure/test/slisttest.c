#include "../include/slist.h"
#include <stdio.h>
#include <stdlib.h> /* EXIT_SUCCESS */
#include <assert.h> /* assert */
#include <string.h> /* strlen */

#define UNUSED(x)(void)(x)




void PrintList(slist_node_t *head);
void Test1(void);
void HasLoopTest(void);
void FindIntersectionTest(void);

int AreEqual(const void *node_val, const void *param);   /* Compare func */
int PrintNode(void *node_val, void *param); /* Action func */

int main()
{
	Test1();
	HasLoopTest();
	FindIntersectionTest();

	return EXIT_SUCCESS;
}

/***********************************************************************/

void PrintList(slist_node_t *head)
{
	slist_node_t *current = head;
	slist_node_t *next = NULL;
	assert(head);

	while(NULL != current)
	{
		next = current->next;
		printf("%d -> ", *(int *)current->val);
		current = next;
	}
	printf("NULL\n");
}
/***********************************************************************/

 int AreEqual(const void *node_val, const void *param)
 {
	assert(node_val && param);
	return (*((int *)node_val) == *((int *)param));
 }

/***********************************************************************/
int PrintNode(void *node_val, void *param)
{
	UNUSED(param);
	printf("%d ", *(int *)node_val);
	return 1;
}

/***********************************************************************/
void Test1()
{
	int val1 = 8;
	int val2 = 6;
	int val3 = 14;
	int val4 = 3;
	int val5 = 22;
	int foreach = -1;
	size_t count = 0;
	
	slist_node_t *head = NULL;
	slist_node_t *node1 = NULL;
	slist_node_t *node2 = NULL;
	slist_node_t *node3 = NULL;
	slist_node_t *node4 = NULL;
	slist_node_t *node5 = NULL;

	slist_node_t *removed1 = NULL;
	slist_node_t *removed2 = NULL;
	slist_node_t *searched = NULL;
	slist_node_t *new_head = NULL;
	
	
	node1 = SListCreateNode(&val1, NULL);     /* Create nodes */
	node2 = SListCreateNode(&val2, node1);    
	node3 = SListCreateNode(&val3, node2);
	head = node3;
	count = SListCount(head);
	assert(3 == count);
	PrintList(head);

	puts("\nInsert after head:");
	node4 = SListCreateNode(&val4, NULL);
	node4 = SListInsertAfter(head, node4);      /* Insert after */
	count = SListCount(head);
	PrintList(head);
	assert(4 == count);
	
	puts("\nInsert Before:");
	node5 = SListCreateNode(&val5, NULL);       /* Insert before */
	node5 = SListInsert(node2, node5);        
	count = SListCount(head);
	PrintList(head);
	assert(5 == count);

	puts("\nRemove after:");
	removed1 = SListRemoveAfter(node4);         /* Remove after */
	PrintList(head);
	count = SListCount(head);
	assert(4 == count);
	assert(22 == *(int *)removed1->val);
	free(removed1);
	
	puts("Remove current:");
	removed2 = SListRemove(node4);             /* Remove current */
	PrintList(head);
	count = SListCount(head);
	assert(3 == count);
	assert(3 == *(int *)removed2->val);
	free(removed2);
	
	searched = SListFind(head, &AreEqual, &val1);                 
	assert(8 == *(int *)searched->val);

	puts("\nFor each - Print node value");
	foreach = SListForEach(head, &PrintNode, NULL);
	assert(1 == foreach);

	puts("\nFlipped list:");
	new_head = SListFlip(head);
	assert(8 == *(int *)new_head->val);
	assert(14 == *(int *)new_head->next->next->val);	
	PrintList(new_head);
	SListFreeAll(new_head);	

	puts("\nSUCCESS - Test 1");
}

/***********************************************************************/
void HasLoopTest(void) 
{
	int val1 = 8;
	int val2 = 6;
	int val3 = 14;
	int val4 = 3;
	int check = 5;

	slist_node_t *node1 = NULL;
	slist_node_t *node2 = NULL;
	slist_node_t *node3 = NULL;
	slist_node_t *node4 = NULL;
	
	node1 = SListCreateNode(&val1, NULL);  
	node2 = SListCreateNode(&val2, node1);    
	node3 = SListCreateNode(&val3, node2);
	node4 = SListCreateNode(&val4, node3);
	node1->next = node3;    /* Setting a Loop */                 
	
	check = SListHasLoop(node4);	
	assert(1 == check);
	node1->next = NULL;      /* No Loop */
	check = SListHasLoop(node4);
	assert(0 == check);

	free(node1);
	free(node2);
	free(node3);
	free(node4);

	puts("SUCCESS - Test2");
}

/***********************************************************************/
void FindIntersectionTest(void)
{
	int val1 = 8;
	int val2 = 6;
	int val3 = 14;
	int val4 = 3;
	int val5 = 22;

	slist_node_t *node1 = NULL;
	slist_node_t *node2 = NULL;
	slist_node_t *node3 = NULL;
	slist_node_t *node4 = NULL;
	slist_node_t *node5 = NULL;
	const slist_node_t *inter = NULL;

	node1 = SListCreateNode(&val1, NULL);    /* Has intersection */ 
	node2 = SListCreateNode(&val2, node1);  
	node3 = SListCreateNode(&val3, node2);
	node4 = SListCreateNode(&val4, node1);
	node5 = SListCreateNode(&val5, node4);

	inter = SListFindIntersection(node4, node3);
	assert(inter);
	assert(8 == *(int *)inter->val);
	node3->next = NULL;
	node4->next = node3;                   /* No intersection */ 
	inter = SListFindIntersection(node4, node2);
	assert(NULL == inter);

	free(node1);
	free(node2);
	free(node3);
	free(node4);
	free(node5);
	
	puts("SUCCESS - Test 3");
}

