#include "../include/fsm.h"

#include <stdio.h> 
#include <assert.h>  /* assert */ 
#include <stdlib.h>  /* EXIT_SUCCESS */

void TestFSMSuggestSize(void);
void TestFSMInit(void);
void TestFSMInit2(void);
void TestFSMAlloc(void);
void TestFSMFree(void);

int main()
{	
	TestFSMSuggestSize();
	TestFSMInit();
	TestFSMInit2();
	TestFSMAlloc();
	TestFSMFree();

	return EXIT_SUCCESS;
}

void TestFSMSuggestSize(void)
{
	/* Case 1 - aligned address */
	printf("Suggested size: %lu \n", FSMSuggestSize(10, 8));	
	assert(184 == FSMSuggestSize(10, 8));

	/* Case 2 - Unaligned address */
	printf("Suggested size: %lu \n", FSMSuggestSize(10, 12));
	assert(264 == FSMSuggestSize(10, 12));

	printf("Suggested size: %lu \n", FSMSuggestSize(5, 3));
	assert(104 == FSMSuggestSize(5, 3));

	puts("\nSUCCESS - TestFSMSuggestSize \n\n");
}

void TestFSMInit(void)
{
	void *start = NULL;	
	fsm_t *fsm = NULL;
	
	start = malloc(200 * sizeof(char));
	if (NULL != start)
	{
		fsm = FSMInit(start, 200, sizeof(char));
	}
	printf("Free blocks: %lu \n", FSMCountFree(fsm));
	assert(11 == FSMCountFree(fsm));	
	free(fsm);	
	
	puts("SUCCESS - TestFSMInit\n\n");
}

void TestFSMInit2(void)
{
	void *start2 = NULL;	
	fsm_t *fsm2  = NULL;

	start2 = malloc(100 * sizeof(char));
	if (NULL != start2)
	{
		fsm2 = FSMInit(start2, 100, sizeof(char));
	}
	printf("Free blocks: %lu \n", FSMCountFree(fsm2));
	assert(4 == FSMCountFree(fsm2));
	free(fsm2);
}

void TestFSMAlloc(void)
{
	void *start = malloc(200 * sizeof(char));
	fsm_t *fsm  = FSMInit(start, 200, sizeof(int));
	char *ptr1 = NULL;
	char *ptr2 = NULL;

	printf("Before allocation - Free blocks: %lu \n", FSMCountFree(fsm));
	printf("Start Address: %lu \n", (size_t)start);
	assert(11 == FSMCountFree(fsm));

	puts("\n---------------- FSMAlloc ------------------");
	ptr1 = FSMAlloc(fsm);
	printf("Address allocated: %lu \n", (size_t)ptr1);
	printf("After allocation - Free blocks: %lu \n", FSMCountFree(fsm));
	assert(10 == FSMCountFree(fsm));

	puts("\n---------------- FSMAlloc ------------------");
	ptr2 = FSMAlloc(fsm);
	printf("Address allocated: %lu \n", (size_t)ptr2);
	printf("After allocation - Free blocks: %lu \n\n", FSMCountFree(fsm));
	assert(9 == FSMCountFree(fsm));

	free(fsm);

	puts("SUCCESS - TestFSMAlloc\n\n");
}

void TestFSMFree(void)
{
	void *start = malloc(200 * sizeof(char));
	fsm_t *fsm  = FSMInit(start, 100, sizeof(int));
	char *ptr1 = NULL;
	char *ptr2 = NULL;
	char *ptr3 = NULL;

	printf("Before allocation - Free blocks: %lu \n", FSMCountFree(fsm));
	printf("Start Address: %lu \n", (size_t)start);
	assert(4 == FSMCountFree(fsm));

	puts("\n---------------- FSMAlloc ------------------");
	ptr1 = FSMAlloc(fsm);
	printf("Address allocated: %lu \n", (size_t)ptr1);
	printf("After allocation - Free blocks: %lu \n", FSMCountFree(fsm));
	assert(3 == FSMCountFree(fsm));

	puts("\n---------------- FSMAlloc ------------------");
	ptr2 = FSMAlloc(fsm);
	printf("Address allocated: %lu \n", (size_t)ptr2);
	printf("After allocation - Free blocks: %lu \n", FSMCountFree(fsm));
	assert(2 == FSMCountFree(fsm));

	puts("\n---------------- FSMAlloc ------------------");
	ptr3 = FSMAlloc(fsm);
	printf("Address allocated: %lu \n", (size_t)ptr3);
	printf("After allocation - Free blocks: %lu \n", FSMCountFree(fsm));
	assert(1 == FSMCountFree(fsm));

	puts("\n---------------- FSMFree ------------------");
	FSMFree(ptr1);
	printf("Address allocated: %lu \n", (size_t)ptr1);
	printf("After allocation - Free blocks: %lu \n", FSMCountFree(fsm));
	assert(2 == FSMCountFree(fsm));

	puts("\n---------------- FSMFree ------------------");
	FSMFree(ptr2);
	printf("Address allocated: %lu \n", (size_t)ptr2);
	printf("After allocation - Free blocks: %lu \n", FSMCountFree(fsm));
	assert(3 == FSMCountFree(fsm));

	free(fsm);

	puts("SUCCESS - TestFSMFree");
}
