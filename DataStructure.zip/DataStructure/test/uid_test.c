#include "../include/uid.h"
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/time.h>
#include <time.h>

/* For testing */
#include <assert.h>
#include <stdio.h>

ssize_t format_timeval(struct timeval *tv, char *buf, size_t sz);

/*TESTING*/
ssize_t format_timeval(struct timeval *tv, char *buf, size_t sz)
{
  ssize_t written = -1;
  struct tm *gm = gmtime(&tv->tv_sec);

  if (gm)
  {
    written = (ssize_t)strftime(buf, sz, "%Y-%m-%d - %M:%S", gm);
    if ((written > 0) && ((size_t)written < sz))
    {
      int w = snprintf(buf+written, sz-(size_t)written, ".%06d", tv->tv_usec);
      written = (w > 0) ? written + w : -1;
    }
  }
  return written;
}


int main()
{
	uniqid_t u1 = UIDCreate();
	uniqid_t u2 = {0};
	uniqid_t bad = {0};
	char buf[28];

	printf("pid: %d\n", u1.pid);
	printf("counter: %lu\n", u1.counter);
	format_timeval(&u1.time, buf, sizeof(buf));
	printf("Is bad UID? %s\n", (1 == UIDIsBad(&u1)) ? "YES" : "NO");
	printf("%s\n", buf);

	puts("-------------------------------------");
	u2 = UIDCreate();
	printf("pid: %d\n", u2.pid);
	printf("counter: %lu\n", u2.counter);
	format_timeval(&u2.time, buf, sizeof(buf));
	printf("%s\n", buf);
	printf("Is bad UID? %s\n\n", (1 == UIDIsBad(&u2)) ? "YES" : "NO");


	printf("Are UIDs same? %s\n", (1 == UIDIsSame(&u1, &u2)) ? "YES" : "NO");
	puts("-------------------------------------");
	bad = UIDGetBad();
	printf("pid: %d\n", bad.pid);
	printf("counter: %lu\n", bad.counter);
	format_timeval(&bad.time, buf, sizeof(buf));
	printf("%s\n", buf);

	printf("Is bad UID? %s\n", (1 == UIDIsBad(&bad)) ? "YES" : "NO");

	return EXIT_SUCCESS;
}

