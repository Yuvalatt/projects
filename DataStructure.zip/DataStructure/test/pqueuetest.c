#include "../include/pqueue.h"
#include "../include/sortedlist.h"

#include <stdio.h> 
#include <stdlib.h> /* EXIT_SUCCESS */
#include <assert.h> /* assert */

#define UNUSED(x)(void)(x)

static int IsBefore(const void *data1, const void *data2, void *param);
static int AreEqual(const void *val, void *param);
void PQueueTest(void);


/***********************************************************************/
int main()
{
	PQueueTest();

	return EXIT_SUCCESS;
}

/***********************************************************************/
void PQueueTest(void)
{
	int val1 = 1;
	int val2 = 2;
	int val3 = 3;
	int val4 = 4;
	int val5 = 5;
	int val6 = 6;
	int val7 = -10;

	void *erased = 0;	

	/* pqueue create */
	pq_t *pqueue1 = PQCreate(&IsBefore, "*");
	
	/* pqueue isempty */
	puts("-----------------PQIsEmpty----------------------");	
	assert(1 == PQIsEmpty(pqueue1));
	printf("Is pqueue empty?: %s \n\n", (1 == PQIsEmpty(pqueue1)) ? "YES" : "NO");
	
	/* pqueue size */
	puts("-----------------PQSize----------------------");	
	assert(0 == PQSize(pqueue1));
	printf("Size of pqueue is: %lu \n\n", PQSize(pqueue1));

	/* pqueue Enqueue */	
	puts("-----------------PQEnqueue----------------------");	
	PQEnqueue(pqueue1, &val1);	
	PQEnqueue(pqueue1, &val2);
	
	/* pqueue isempty */
	assert(0 == PQIsEmpty(pqueue1));
	printf("Is pqueue empty?: %s \n\n", (1 == PQIsEmpty(pqueue1)) ? "YES" : "NO");	

	/* pqueue size */
	assert(2 == PQSize(pqueue1));
	printf("\nSize of pqueue is: %lu \n\n", PQSize(pqueue1));

	PQEnqueue(pqueue1, &val6);
	PQEnqueue(pqueue1, &val4);	
	PQEnqueue(pqueue1, &val3);

	/* pqueue Dequeue */	
	puts("-----------------PQDequeue----------------------");	
	PQDequeue(pqueue1);
	PQDequeue(pqueue1);
	
	assert(3 == PQSize(pqueue1));
	printf("Size of pqueue is: %lu \n", PQSize(pqueue1));
	printf("\nFirst element in pqueue is: %d \n\n", *(int *)(PQPeek(pqueue1)));
	assert(3 == *(int *)(PQPeek(pqueue1)));

	/* pqueue Dequeue */
	PQEnqueue(pqueue1, &val5);
	PQEnqueue(pqueue1, &val7);

	printf("\nFirst element in pqueue is: %d \n\n", *(int *)(PQPeek(pqueue1)));
	assert(-10 == *(int *)(PQPeek(pqueue1)));
	assert(5 == PQSize(pqueue1));
	
	/* pqueue Erase */	
	puts("-----------------PQErase----------------------");	
	erased = PQErase(pqueue1, &AreEqual, &val4);
	printf("\nErased element value is: %d \n", *(int *)erased);
	assert(4 == *(int *)erased);
	erased = PQErase(pqueue1, &AreEqual, &val7);
	printf("\nErased element value is: %d \n", *(int *)erased);
	assert(-10 == *(int *)erased);
	erased = PQErase(pqueue1, &AreEqual, &val3);
	printf("\nErased element value is: %d \n\n", *(int *)erased);
	assert(3 == *(int *)erased);

	/* pqueue Dequeue */
	puts("-----------------PQDequeue----------------------");
	PQDequeue(pqueue1);
	PQDequeue(pqueue1);
	printf("\nSize of pqueue is: %lu \n\n", PQSize(pqueue1));
	assert(0 == PQSize(pqueue1));

	/* pqueue Enqueue */
	puts("-----------------PQEnqueue----------------------");
	PQEnqueue(pqueue1, &val5);
	PQEnqueue(pqueue1, &val7);	
	PQEnqueue(pqueue1, &val1);	
	PQEnqueue(pqueue1, &val2);
	printf("\nSize of pqueue is: %lu \n\n", PQSize(pqueue1));

	/*PQClearAll(pqueue1);*/	
	puts("-----------------PQClearAll----------------------");	
	PQClearAll(pqueue1);
	printf("\nSize of pqueue is: %lu \n", PQSize(pqueue1));
	assert(0 == PQSize(pqueue1));

	PQDestroy(pqueue1);
	
	puts("\nSUCCESS - PQueue Test");
}

/***********************************************************************/
static int AreEqual(const void *val, void *param)
{	
	assert(val && param);
	return (*((int *)val) == *((int *)param));
}

/***********************************************************************/
static int IsBefore(const void *data1, const void *data2, void *param)
{
	UNUSED(param);
	
	return(*(int *)data1 < *(int *)data2);	
}



