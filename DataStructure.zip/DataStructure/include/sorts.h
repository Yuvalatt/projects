#ifndef SORTS_H
#define SORTS_H

#include <stdlib.h>

typedef size_t (el_to_key_idx_t)(const void *element, const void *args);	/* Bytes func */
typedef size_t (el_to_key_t)(const void *element, const void *args); 		/* Users func */

typedef int (*cmp_func_t)(const void *, const void *); 
/* The  comparison  function must return an integer less than, equal to, or greater than zero 
 * if the first argument is considered to be respectively less than, equal to, or greater than the second.*/

/*  base: array, nmemb: num of elements, size: of each element */
void BubbleSort(void *base, size_t nmemb, size_t size, cmp_func_t cmp_func);
void InsertionSort(void *base, size_t nmemb, size_t size, cmp_func_t cmp_func);
void SelectionSort(void *base, size_t nmemb, size_t size, cmp_func_t cmp_func);

void CountingSort(void *base, size_t members_num, size_t element_size, el_to_key_idx_t key_func, const void *args, size_t range);
void CountingSortEx(const void *src, void *dest, size_t members_num, size_t element_size, el_to_key_idx_t key_func, const void *args, size_t range, size_t histogram[]);

void TestRadixSort(void *base, size_t num_of_elements, size_t el_size, el_to_key_t key_func, const void *args, size_t num_of_bytes);
void RadixSort(void *base, size_t num_of_elements, size_t el_size, el_to_key_t key_func, const void *args, size_t num_of_bytes);
void MergeSort(void *base, size_t nmemb, size_t size, cmp_func_t cmp_func);
void HeapSort(void *base, size_t nmemb, size_t size, cmp_func_t cmp_func);
void QuickSort(void *base, size_t nmemb, size_t size, cmp_func_t cmp_func);
void *BinarySearch(const void *base, size_t nmemb, size_t size, const void *data_to_find, cmp_func_t cmp_func);

#endif	/* SORTS_H */
