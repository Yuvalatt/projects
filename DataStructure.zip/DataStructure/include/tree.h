#ifndef TREE_H
#define TREE_H

#include <stdlib.h>

typedef struct tree tree_t;
typedef void *tree_iter_t;

/* The  comparison  function returns  -1 , 0, 1 
 * if the first argument is considered to be respectively less than, equal to, or greater than the second.*/
typedef int (*tree_cmp_func_t)(const void *data1, const void *data2, const void *param); 	
typedef int (*tree_act_func_t)(void *value, void *param);	/* Return value: Aborted - 0, Continue - 1	*/

tree_t *TreeCreate(tree_cmp_func_t cmp_func , const void *param);
void TreeDestroy(tree_t *tree);
size_t TreeCount(const tree_t *tree);
int TreeIsEmpty(const tree_t *tree);

/* Return value: iterator to the value inserted, END iterator on failure*/ 
tree_iter_t TreeInsert(tree_t *tree, void *data);

/* Return value: iterator to the value removed */ 
void *TreeRemove(tree_iter_t remove_node);

/* Return value: iterator to the minimum value */ 
tree_iter_t TreeBegin(const tree_t *tree);

/* Return value: iterator to the stub */ 
tree_iter_t TreeEnd(const tree_t *tree);
tree_iter_t TreeNext(const tree_iter_t iter);
tree_iter_t TreePrev(const tree_iter_t iter);

void *TreeGetData(const tree_iter_t iter);

/* Return value: True - 1, False - 0*/
int TreeIsSameIter(const tree_iter_t iter1, const tree_iter_t iter2);

/* Return value: iterator to the value found, END iterator on failure*/  
tree_iter_t TreeFind(const tree_t *tree, void *data);

int TreeForEach(tree_t *tree ,tree_iter_t from, tree_iter_t to, tree_act_func_t act_func, void *param);

#endif	/* TREE_H */
