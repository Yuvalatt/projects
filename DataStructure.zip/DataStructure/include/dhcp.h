#ifndef DHCP_H
#define DHCP_H

#include <stdlib.h>

typedef struct dhcp dhcp_t;
typedef enum status {SUCCESS, ALLOCATION_FAILURE, INVALID_IP} status_t;

dhcp_t *DHCPCreate(unsigned char net_addr[4], unsigned int cidr);
void DHCPDestroy(dhcp_t *dhcp);
size_t DHCPCountFree(const dhcp_t *dhcp);

/* PARAMS: req_ip is allocated by user, must be size of 4 bytes */
/* Return value: SUCCESS - on success req_ip holds the ip address, otherwise returns ALLOCATION_FAILURE */
/* base_addr_optional is optional*/
status_t DHCPAllocIP(dhcp_t *dhcp, unsigned char base_addr_optional[4], unsigned char req_ip[4]);

/* Return value: SUCCESS or INVALID_IP */
status_t DHCPFreeIP(dhcp_t *dhcp, unsigned char ip_addr[4]);

#endif	/* DHCP_H */

