#ifndef VSM_H
#define VSM_H

#include <stdlib.h>

typedef struct vsm vsm_t;
	/*returns pointer to base of cmd structure */
vsm_t *VSMInit(void *mem_ptr, size_t mem_size);
	/* Returned pointer is Word aligned / NULL if failed*/
void *VSMAlloc(vsm_t *vsm, size_t block_size);
	/* implementation in complexity O(1) */
void VSMFree(void *ptr);
	/* Returns sum of free bytes */
size_t VSMCountFree(vsm_t *vsm);
	/* Returns biggest Block Size Possible ***Optional */
size_t GetLargest(vsm_t *vsm);
	
#endif	/* VSM_H */
