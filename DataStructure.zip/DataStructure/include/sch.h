#ifndef SCH_H
#define SCH_H

#include <stdlib.h>
#include "../include/uid.h"
#include "../include/task.h"
#include "../include/pqueue.h"

typedef struct sch sch_t;

sch_t *SCHCreate(void);

void SCHDestroy(sch_t *sch);

size_t SCHSize(const sch_t *sch);

/* Return value: True - 1, False - 0*/
int SCHIsEmpty(const sch_t *sch);

/* Return value:  SUCCESS -return the uid of the task, FAILURE - returns bad uid */
uniqid_t SCHAddTask(sch_t *sch, task_func_t task_func, void *param, size_t period_is_secs);

/* Return value: SUCCESS - 1, FAILURE - 0*/
int SCHRemoveTask(sch_t *sch, uniqid_t uid);

int SCHRun(sch_t *sch);

void SCHStop(sch_t *sch);

#endif	/* SCH_H */
