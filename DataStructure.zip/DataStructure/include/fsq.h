#ifndef FSQ_H
#define FSQ_H

#include <stdlib.h>

typedef struct fsq fsq_t;

fsq_t *FSQCreate(size_t n_elements);

void FSQDestroy(fsq_t *fsq);

void FSQEnqueue(fsq_t *fsq, const int data); 

int FSQDequeue(fsq_t *fsq);
 
#endif /* FSQ_H */
