#ifndef UID_H
#define UID_H

#include <stdlib.h>

#include <sys/types.h>
#include <sys/time.h>

#include <time.h>
#include <unistd.h>

typedef struct		/* Internal struct ! - Do not access directly members of this struct */
{
	size_t counter;
	pid_t pid;
	struct timeval time;
} uniqid_t;

uniqid_t UIDCreate(void);

int UIDIsSame(const uniqid_t *uid1, const uniqid_t *uid2);

int UIDIsBad(const uniqid_t *uid);

uniqid_t UIDGetBad(void);

#endif	/* UID_H */
