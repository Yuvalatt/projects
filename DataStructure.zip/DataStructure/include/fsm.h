#ifndef FSM_H
#define FSM_H

#include <stdlib.h>

typedef struct fsm fsm_t;

/*return the suggested size of memory to allocate*/
size_t FSMSuggestSize(size_t num_of_elements, size_t block_size);

/*returns the innitialized control unit*/ 
fsm_t *FSMInit(void *mem_ptr, size_t mem_size, size_t block_size);

/*return value:  ptr to the beginning of the allocated memorry (always word alligned), NULL if full*/ 
void *FSMAlloc(fsm_t *fsm);

/* frees the memory pointed to by ptr*/
void FSMFree(void *ptr);

/*returns the amount of free blocks*/ 
size_t FSMCountFree(const fsm_t *fsm);

#endif	/* FSM_H */
