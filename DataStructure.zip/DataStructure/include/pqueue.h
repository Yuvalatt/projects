#ifndef PQUEUE_H
#define PQUEUE_H

#include <stdlib.h>

typedef struct pqueue pq_t;

typedef int (*pq_cmp_func_t)(const void *data, void *param);				/* 		  True - 1, False - 0 		 */

typedef int (*pq_is_before_t)(const void *data1, const void *data2, void *param);	/* True - 1 if data1 is before data2 */										

pq_t *PQCreate(pq_is_before_t is_before, void *param);

void PQDestroy(pq_t *pqueue);

size_t PQSize(const pq_t *pqueue);

int PQIsEmpty(const pq_t *pqueue);		 	/* return value empty - 1, not empty - 0 */

int PQEnqueue(pq_t *pqueue, void *data); 	/*   SUCCESS - 0, FAILURE (malloc) - 1 	 */

void *PQDequeue(pq_t *pqueue);			 	/*   Do not perform on an empty queue 	 */

void *PQPeek(const pq_t *pqueue); 			/*   Do not perform on an empty queue 	 */

void *PQErase(pq_t *pqueue, pq_cmp_func_t CmpFunc, void *param);

void PQClearAll(pq_t *pqueue);


#endif	/* PQUEUE_H */
