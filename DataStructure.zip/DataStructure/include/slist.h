#ifndef SLIST_H
#define SLIST_H

#include <stdlib.h>

typedef struct slist_node
{
	void *val;
	struct slist_node *next;
} slist_node_t;

typedef int (*cmp_func_t)(const void *node_val, const void *param);				/* Return value: True - 1, False - 0        */
typedef int (*act_func_t)(void *node_val, void *param);							/* Return value: Aborted - 0, Continue - 1	*/

slist_node_t *SListCreateNode(void *val, slist_node_t *next);
void SListFreeAll(slist_node_t *head);
size_t SListCount(const slist_node_t *head);

/* 	 Inserts the new_node after the given node.
	* Return value: The node that was inserted */																										
slist_node_t *SListInsertAfter(slist_node_t *node, slist_node_t *new_node);  

/* 	 Inserts the new_node before the given node.
	* Return value: The node that was inserted */		                          
slist_node_t *SListInsert(slist_node_t *node, slist_node_t *new_node);

/* 	 Removes the node after the given node.
	* Return value: The node that was removed */	
slist_node_t *SListRemoveAfter(slist_node_t *node);

/* 	 Removes the given node.
	* Return value: The node that was removed 
	* Note : can not remove the last node - check by assert */
slist_node_t *SListRemove(slist_node_t *node);															

slist_node_t *SListFind(slist_node_t *head, cmp_func_t CmpFunc, const void *param);

int SListForEach(slist_node_t *head, act_func_t ActFunc, void *param);		  /* Return value: Aborted - 0, Continue - 1	*/

slist_node_t *SListFlip(slist_node_t *head);

int SListHasLoop(const slist_node_t *node);

const slist_node_t *SListFindIntersection(const slist_node_t *head1, const slist_node_t *head2);

#endif	/* SLIST_H */
