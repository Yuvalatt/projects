#ifndef AVLTREE_H
#define AVLTREE_H

#include <stdlib.h>

#include "../include/dlist.h"

/* The  comparison  function returns  -1 , 0, 1 
 * if the first argument is considered to be respectively less than, equal to, or greater than the second.*/
typedef int (*avl_cmp_func_t)(const void *data1, const void *data2, const void *param); 	
typedef int (*avl_act_func_t)(void *value, void *param);	/* Return value: Aborted - 0, Continue - 1	*/
typedef int (*avl_match_func_t)(const void *data, const void * param); /* The  comparison  function returns  -1 , 0, 1 */

typedef struct avl avl_t;

avl_t *AVLTreeCreate(avl_cmp_func_t cmp_func , const void *param);
void AVLTreeDestroy(avl_t *tree);

size_t AVLTreeCount(const avl_t *tree);
int AVLTreeIsEmpty(const avl_t *tree);

/* Return value: 0 - success, 1 - failure */
int AVLTreeInsert(avl_t *tree, void *data);
/* Return value: value removed */ 
void AVLTreeRemove(avl_t *tree, const void *data_to_match);

size_t AVLTreeHeight(const avl_t *tree);
/* Return value: pointer to the data or NULL if not found */  
void *AVLTreeFind(const avl_t *tree, const void *data_to_match);
/* Return value: 0 - success, 1 - failure */
int AVLTreeForEach(avl_t *tree, avl_act_func_t act_func, void *param);

void AVLTreeMultiRemove(avl_t *tree, avl_match_func_t match_func, const void *param);
void AVLTreeMultiFind(const avl_t *tree, dlist_t *found_list, avl_match_func_t match_func, const void *param);

#endif	/* AVLTREE_H */
