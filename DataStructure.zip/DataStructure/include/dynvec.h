#ifndef DYNVEC_H
#define DYNVEC_H

#include <stdlib.h>

typedef struct dyn_vec dv_t;

dv_t *DVCreate(size_t number_of_elements, size_t element_size);

void DVDestroy(dv_t *dyn_vec);

size_t DVSize(const dv_t *dyn_vec);

size_t DVCapacity(const dv_t *dyn_vec);

int DVPushBack(dv_t *dyn_vec, const void *data);   /* Returns 0- Succsess, 1 - Failure */

void DVPopBack(dv_t *dyn_vec);

int DVReserve(dv_t *dyn_vec, size_t min_capacity); /* Returns 0- Succsess, 1 - Failure */

void *DVGetItemAddress(const dv_t *dyn_vec, size_t index);

#endif	/* DYNVEC_H */
