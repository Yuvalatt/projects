#ifndef BARR_H

#define BARR_H
#include <stdlib.h>

typedef unsigned long barr_t;

barr_t BarrAllOn(void);
barr_t BarrAllOff(void);

barr_t BarrSetOn(barr_t barr, size_t index);
barr_t BarrSetOff(barr_t barr, size_t index);
barr_t BarrSetBit(barr_t barr, size_t index, int value);

barr_t BarrToggleBit(barr_t barr, size_t index);

int BarrIsOn(barr_t barr, size_t index);
int BarrIsOff(barr_t barr, size_t index);

barr_t BarrRotR(barr_t barr, size_t n);
barr_t BarrRotL(barr_t barr, size_t n);

barr_t BarrMirror(barr_t barr);

size_t BarrCountOn(barr_t barr);
size_t BarrCountOff(barr_t barr);

barr_t BarrLUTMirror(barr_t barr);
size_t BarrLUTCountOn(barr_t barr);

#endif
