#ifndef DLIST_H
#define DLIST_H

#include <stdlib.h>

typedef void *dlist_iter_t;
typedef struct dlist dlist_t;

/* Return value: True - 1, False - 0*/
typedef int (*cmp_func_t)(const void *val, const void *param, const void *data);

/* Return value: Aborted - 0, Continue - 1*/										
typedef int (*act_func_t)(void *val, void *param);											


dlist_t *DListCreate(void);
void DListDestroy(dlist_t *dlist);

size_t DListSize(const dlist_t *dlist);

/* Return value: True - 1, False - 0*/
int DListIsEmpty(const dlist_t *dlist);
dlist_iter_t DListBegin(const dlist_t *dlist);
dlist_iter_t DListEnd(const dlist_t *dlist);
dlist_iter_t DListNext(const dlist_iter_t iter);
dlist_iter_t DListPrev(const dlist_iter_t iter);

void *DListGetData(const dlist_iter_t iter);

/* Return value: True - 1, False - 0*/
int DListIsSameIter(const dlist_iter_t iter1, const dlist_iter_t iter2);

/* Inserts the value after the given iterator.
 * Return value: iterator to the value inserted ,END iterator on failure */	
dlist_iter_t DListInsert(dlist_t *dlist, dlist_iter_t iter, void *val);

/* Inserts the value after the given iterator.
*  Return value: iterator to the value inserted ,END iterator on failure */	
dlist_iter_t DListInsertAfter(dlist_t *dlist, dlist_iter_t iter, void *val);

/* 	 Removes the given iterator
 *  Return value: iterator of the next item (after the removed item) */
dlist_iter_t DListErase(dlist_iter_t iter);

/* Removes the given iterator
 * Return value: iterator to the value inserted ,END iterator on failure */	
dlist_iter_t DListPushFront(dlist_t *dlist, void *val);

/* Return value: iterator to the value inserted ,END iterator on failure */	
dlist_iter_t DListPushBack(dlist_t *dlist, void *val);

void DListPopFront(dlist_t *dlist);
void DListPopBack(dlist_t *dlist);

/* use IsSame when testing */
dlist_iter_t DListFind(const dlist_t *dlist, const dlist_iter_t from_it, const dlist_iter_t to_it, cmp_func_t CmpFunc, const void *param, const void *data);

/* Return value: Aborted - 0, Continue - 1	*/
int DListForEach(dlist_iter_t from_it, dlist_iter_t to_it, act_func_t ActFunc, void *param);

void DListSpliceBefore(dlist_iter_t where, dlist_iter_t from, dlist_iter_t to);


#endif	/* DLIST_H */
