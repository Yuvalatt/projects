#ifndef SORTEDLIST_H
#define SORTEDLIST_H

#include <stdlib.h>

typedef void *sorted_list_iter_t;

typedef struct sorted_list sorted_list_t;

/* Return value: True - 1, False - 0 */
typedef int (*sl_cmp_func_t)(const void *data, void *param);

/* Return value: Aborted - 0, Continue - 1*/										
typedef int (*sl_act_func_t)(void *data, void *param);	

/* Return value: True - 1 if data1 is before data2. */										
typedef int (*is_before_t)(const void *data1, const void *data2, void *param);

sorted_list_t *SortedListCreate(is_before_t is_before, void *param);

void SortedListDestroy(sorted_list_t *list);

size_t SortedListSize(const sorted_list_t *list);

/* Return value: True - 1, False - 0*/
int SortedListIsEmpty(const sorted_list_t *list);

sorted_list_iter_t SortedListBegin(const sorted_list_t *list);

sorted_list_iter_t SortedListEnd(const sorted_list_t *list);

sorted_list_iter_t SortedListNext(const sorted_list_iter_t iter);

sorted_list_iter_t SortedListPrev(const sorted_list_iter_t iter);

void *SortedListGetData(const sorted_list_iter_t iter);

/* Return value: True - 1, False - 0*/
int SortedListIsSameIter(const sorted_list_iter_t iter1, const sorted_list_iter_t iter2);

/* Inserts the value to the sorted list.
 * Return value: iterator to the value inserted, END iterator on failure */	
sorted_list_iter_t SortedListInsert(sorted_list_t *list,  void *data);

/* 	 Removes the given iterator
 *  Return value: iterator of the next item (after the removed item) */
sorted_list_iter_t SortedListErase(sorted_list_iter_t iter);

void *SortedListPopFront(sorted_list_t *list);

void *SortedListPopBack(sorted_list_t *list);

/* use IsSame when testing */
sorted_list_iter_t SortedListFind(const sorted_list_t *list, const sorted_list_iter_t from, const sorted_list_iter_t to, sl_cmp_func_t CmpFunc, void *param);

/* Return value: Aborted - 0, Continue - 1	*/
int SortedListForEach(sorted_list_iter_t from, sorted_list_iter_t to, sl_act_func_t ActFunc, void *param);

/* Merges 2 sorted lists	*/
void SortedListMerge(sorted_list_t *to, sorted_list_t *from);

#endif	/* SORTEDLIST_H */
