#ifndef QUEUE_H
#define QUEUE_H

#include <stdlib.h>

typedef struct queue queue_t;

queue_t *QueueCreate(void);
void QueueDestroy(queue_t *queue);

size_t QueueSize(const queue_t *queue);
int QueueIsEmpty(const queue_t *queue);	/* return value empty - 1, not empty - 0 */

/* return value SUCCESS - 0, FAILURE (malloc) - 1 */
int QueueEnqueue(queue_t *queue, void *val); 

/* Do not perform on an empty queue */
void QueueDequeue(queue_t *queue);

/* Do not perform on an empty queue */
void *QueuePeek(const queue_t *queue); 

queue_t *QueueAppend(queue_t *to, queue_t *from);

#endif	/* QUEUE_H */
