#ifndef CALCULATOR_H
#define CALCULATOR_H

#include <stdlib.h>

typedef enum {SUCCESS, MALLOC_FAILURE, INVALID_OPERATOR, INVALID_NUM} status_t;

/* Return 0 on failure and set status accordingly */
double Calculator(const char *expression, status_t *status);

#endif	/* CALCULATOR_H */
