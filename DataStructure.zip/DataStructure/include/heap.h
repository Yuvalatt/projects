#ifndef HEAP_H
#define HEAP_H

#include <stdlib.h>

typedef struct heap heap_t;

/* return value: -1, 0 or 1 when data1 is bigger than, equal to or smaller than data2 accordingly */
typedef int (*heap_cmp_func_t)(const void *data1, const void *data2, const void *param);

typedef int (*heap_find_t)(const void *data, const void *data_to_find);	  /*True - 1, False - 0 */

/*typedef int (*heap_find_t)(const void *data, const void *data_to_find);
*/
typedef enum {HEAP_SUCCESS, HEAP_MALLOC_FAILURE} heap_stat_t;

heap_t *HeapCreate(heap_cmp_func_t cmp_func, const void *param);

void HeapDestroy(heap_t *heap);

heap_stat_t HeapPush(heap_t *heap, void *data);

void *HeapPop(heap_t *heap);

void *HeapPeek(const heap_t *heap); 	/*   Do not perform on an empty heap  */

size_t HeapSize(const heap_t *heap);

int HeapIsEmpty(const heap_t *heap);		/* return value empty - 1, not empty - 0 */

void *HeapRemove(heap_t *heap, heap_find_t find_func, void *data_to_remove, void *param);

#endif	/* HEAP_H */
