#ifndef TASK_H
#define TASK_H

#include <stdlib.h>
#include "../include/uid.h"

/* CHECK IF NEEDED */
#include <unistd.h>
#include <sys/types.h>
#include <sys/time.h>
#include <time.h>

/* Both STOP & PERIODIC indicates that function has succeeded. FAIL returns in case of an error */
/*enum status {FAIL = -1, STOP = 0, PERIODIC = 1}; */ 

typedef struct task task_t;

typedef int (*task_func_t) (void *param);	

task_t *TaskCreate(task_func_t task_func, void *param, time_t period_is_secs);

void TaskDestroy(task_t *task);   

void TaskTimeUpdate(task_t *task);

int TaskRun(task_t *task);

time_t TaskGetActTime(task_t *task);

uniqid_t TaskGetId(task_t *task);

time_t TaskGetPeriodInSec(task_t *task);

int TaskIsSame(task_t *task1, task_t *task2);

#endif	/* TASK_H */
