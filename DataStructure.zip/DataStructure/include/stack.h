#ifndef STACK_H
#define STACK_H

#include <stdlib.h>

typedef struct stack stack_t;

stack_t *StackCreate(size_t number_of_elements, size_t element_size);
void StackDestroy(stack_t *stack);
void StackPush(stack_t *stack, const void *data);
void StackPop(stack_t *stack);
void *StackPeek(const stack_t *stack);
size_t StackSize(const stack_t *stack);

#endif	/* STACK_H */
