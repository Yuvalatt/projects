#ifndef CBUF_H
#define CBUF_H

#include <stdlib.h>

typedef struct cbuf c_buf_t;

typedef enum {SUCCESS, ENODATA, EOVERFLOW} status_t;
extern status_t g_cbuf_errno;

c_buf_t *CBufCreate(size_t n_of_bytes);
void CBufDestroy(c_buf_t *cbuf);
size_t CBufCapacity(const c_buf_t *cbuf);
size_t CBufFreeSpace(const c_buf_t *cbuf);
int CBufIsEmpty(const c_buf_t *cbuf);

/* RETURN VALUE :  On  success,  the number of bytes read is returned and if failes change the flag (g_cbuf_errno) to ENODATA */
size_t CBufRead(c_buf_t *cbuf, char *data, size_t n_bytes); 

/* RETURN VALUE :  On success, the number of bytes written is returned and if failes change the flag (g_cbuf_errno) to EOVERFLOW */
size_t CBufWrite(c_buf_t *cbuf, const char *data_to_write, size_t n_bytes);
 

#endif /* CBUF_H */
