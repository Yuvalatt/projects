#ifndef HASH_H
#define HASH_H

#include <stdlib.h>

typedef struct hash hash_t;

typedef enum {SUCCESS, MALLOC_FAILURE} status_t;

typedef struct 
{
    size_t max_collision;
    double average_collision;
    double STD_collision;    
}hash_statistic_t;

/* Return value: True - 1, False - 0*/
typedef int (*hash_cmp_func_t)(const void *val, const void *param, const void *data);
/* Return value: Aborted - 0, Continue - 1*/										
typedef int (*hash_act_func_t)(void *data, void *param);	
typedef size_t (*hash_func_t)(const void *data);											

hash_t *HashCreate(size_t hash_size, hash_func_t hash_func, hash_cmp_func_t cmp_func, const void *param);

void HashDestroy(hash_t *hash);

size_t HashSize(const hash_t *hash);

/* return value empty - 1, not empty - 0 */
int HashIsEmpty(const hash_t *hash);	

/* Return value: returns the requested data. in case of failure returns NULL	*/
void *HashFind(const hash_t *hash, const void *data);

/* Return value: succeed - SUCCESS, failed - MALLOC_FAILURE*/										
status_t HashInsert(hash_t *hash, void *data);

/* Return value: returns the removed data. in case of failure returns NULL	*/
void *HashRemove(hash_t *hash, void *data);

/* Return value: Aborted - 0, Continue - 1	*/
int HashForEach(hash_t *hash, hash_act_func_t act_func, void *param);

hash_statistic_t GetStatistic(const hash_t *hash);

#endif	/* HASH_H */
