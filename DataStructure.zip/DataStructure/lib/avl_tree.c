#include "../include/avl_tree.h"

#include <assert.h> 	/* assert */

#define MAX(a, b)(((a) > (b)) ? (a) : (b))
#define UNUSED(X)(void)(X)

typedef struct node node_t;

enum status {SUCCESS, FAILURE};

struct avl
{
	node_t *root;
	avl_cmp_func_t cmp_func;
	const void *param;
};

struct node
{
	void *data;
	node_t *right;
	node_t *left;
	size_t height;
};

static void CalcHeight(node_t *root);
static node_t *CreateTreeNode(node_t *left, node_t *right, void *data);
static size_t CountRec(node_t *root);
static void RecDestroy(node_t *node);

static node_t *RotRight(node_t *root);
static node_t *RotLeft(node_t *root);
static int HeightDiff(node_t *node);

static node_t *AVLTreeBalance(node_t *root);
static node_t *InsertRec(node_t *root, node_t *new_node, avl_cmp_func_t cmp_func, const void *param);
static node_t *FindRec(node_t *node, const void *data_to_match, avl_cmp_func_t cmp_func, const void *param);
static int RecForEach(node_t *node, act_func_t act_func, void *param);

/***********************************************************************/
avl_t *AVLTreeCreate(avl_cmp_func_t cmp_func, const void *param)
{
	avl_t *tree = NULL;
	assert(cmp_func);

	tree = malloc(1 * sizeof(avl_t));
	if (NULL == tree)
	{
		return NULL;
	}

	tree->root = NULL;
 	tree->cmp_func = cmp_func;
	tree->param = param;

	return tree;
}

/***********************************************************************/
static node_t *CreateTreeNode(node_t *left, node_t *right, void *data) 
{
	node_t *tree_node = NULL;
	
	tree_node = malloc(1 * sizeof(node_t));

	if (NULL == tree_node)
	{
		return NULL;
	}
	
	tree_node->left = left;
	tree_node->right = right;
	tree_node->data = data;
	tree_node->height = 1;
	
	return tree_node;
}
/***********************************************************************/
static void RecDestroy(node_t *node)
{
	if (NULL == node)
	{
		return;
	}
	
	RecDestroy(node->left);
	RecDestroy(node->right);
	
	free(node);
}

/***********************************************************************/
void AVLTreeDestroy(avl_t *tree)
{
	assert(tree);
	RecDestroy(tree->root);
	free(tree);
}

/***********************************************************************/
static size_t CountRec(node_t *root)
{
	if (NULL == root)
	{
		return 0;
	}

	return 1 + CountRec(root->right) + CountRec(root->left);
}

/***********************************************************************/
size_t AVLTreeCount(const avl_t *tree)
{
	assert(tree);

	return CountRec(tree->root);
}

/***********************************************************************/
int AVLTreeIsEmpty(const avl_t *tree)
{
	assert(tree);

	return (NULL == tree->root);
}

/***********************************************************************/
static int RecForEach(node_t *node, act_func_t act_func, void *param)
{ 
	if (NULL == node)
	{
		return 1;
	}
	
	if (0 == RecForEach(node->left, act_func, param))
	{
		return 0;
	}
	
	if (0 == act_func(node->data, param))
	{
		return 0;
	}
	
	if (0 == RecForEach(node->right, act_func, param))
	{
		return 0;
	}
		
	return 1;			
}

/***********************************************************************/
int AVLTreeForEach(avl_t *tree, avl_act_func_t act_func, void *param)
{ 
	assert(tree && act_func);

	return RecForEach(tree->root, act_func, param);
}

/***********************************************************************/
static void CalcHeight(node_t *node)
{	
	assert(node);

	node->height = MAX(((!node->right) ? 0 : node->right->height), ((!node->left) ? 0 : node->left->height)) + 1;
}

/***********************************************************************/
size_t AVLTreeHeight(const avl_t *tree)
{
	assert(tree);

	return (NULL == tree->root) ? 0 : tree->root->height;
}

/***********************************************************************/
static int HeightDiff(node_t *node)
{
	int right = 0;
	int left = 0;

	assert(node);

	if (NULL != node->right)
	{
		right = node->right->height;
	}
	if (NULL != node->left)
	{
		left = node->left->height;

	}
	return (right - left);
}

/***********************************************************************/
static node_t *AVLTreeBalance(node_t *root)
{	
	int height_diff = 0;

	assert(root);

	height_diff = HeightDiff(root);

	CalcHeight(root);
	
	assert(height_diff >= -2 && height_diff <= 2);	
	
	if (2 == height_diff)
	{
		if (0 > HeightDiff(root->right))     /* LR rotation */
		{
			root->right = RotRight(root->right);
		}
		return RotLeft(root);   	
	}

	if (-2 == height_diff)
	{
		if (0 < HeightDiff(root->left))     /* RL rotation */
		{
			root->left = RotLeft(root->left);
		}
		return RotRight(root);	
	}
	
	return root;
}

/***********************************************************************/
static node_t *RotRight(node_t *root)
{
	node_t *pivot = NULL;

	assert(root && root->left);

	pivot = root->left;
	
	root->left = pivot->right;
	pivot->right = root;
	
	CalcHeight(root);
	CalcHeight(pivot);
	
	return pivot;
} 

/***********************************************************************/
static node_t *RotLeft(node_t *root)
{
	node_t *pivot = NULL;

	assert(root && root->right);

	pivot = root->right;	

	root->right =  pivot->left;
	pivot->left = root;
	
	CalcHeight(root);
	CalcHeight(pivot);
	
	return pivot;
} 

/***********************************************************************/
/* The function returns the new root */
static node_t *InsertRec(node_t *root, node_t *new_node, avl_cmp_func_t cmp_func, const void *param)   
{
	if (NULL == root)
	{
		return new_node;
	}

	if (0 < cmp_func(new_node->data, root->data, param))
	{
		root->right = InsertRec(root->right, new_node, cmp_func, param);
	}
	else
	{
		root->left = InsertRec(root->left, new_node, cmp_func, param);
	}

	return AVLTreeBalance(root);
}

/***********************************************************************/
int AVLTreeInsert(avl_t *tree, void *data)
{
	node_t *new_node = NULL;
	
	assert(tree && data && !AVLTreeFind(tree, data));

	new_node = CreateTreeNode(NULL, NULL, data);

	if (NULL == new_node)
	{
		return FAILURE;
	}

	tree->root = InsertRec(tree->root, new_node, tree->cmp_func, tree->param); /* RETURNS NEW ROOT */

	return SUCCESS;
}

/***********************************************************************/
static node_t *FindRec(node_t *node, const void *data_to_match, avl_cmp_func_t cmp_func, const void *param)
{
	int cmp_val = 0;

	if (NULL == node)
	{
		return node;
	}
	
	cmp_val = cmp_func(data_to_match, node->data, param);
	
	if (0 < cmp_val) 
	{
		node = FindRec(node->right, data_to_match, cmp_func, param);
	}
	else if (0 > cmp_val)
	{
		node = FindRec(node->left, data_to_match, cmp_func, param);
	}
	
	return node;
}

/***********************************************************************/
void *AVLTreeFind(const avl_t *tree, const void *data_to_match)
{
	node_t *found = NULL;
	
	assert(tree && data_to_match);
	
	found = FindRec(tree->root, data_to_match, tree->cmp_func, tree->param);
	
	return (!found) ? NULL : found->data;
}

/***********************************************************************/
static node_t *FindMin(node_t *root)
{
	return (NULL != root->left) ? FindMin(root->left) : root;
}

/***********************************************************************/
static node_t *DeleteMin(node_t *root)
{
	if (NULL == root->left)
	{
		return root->right;
	}

	root->left = DeleteMin(root->left);

	return AVLTreeBalance(root);
}

/***********************************************************************/
static node_t *RemoveRec(node_t *root, const void *data_to_match, avl_cmp_func_t cmp_func, const void *param)
{
	node_t *child_left = NULL;
	node_t *child_right = NULL;
	node_t *next = NULL;

	assert(root);
	
	if (0 > cmp_func(data_to_match, root->data, param))
	{
		root->left = RemoveRec(root->left, data_to_match, cmp_func, param);

		return AVLTreeBalance(root);
	}

	if (0 < cmp_func(data_to_match, root->data, param))
	{
		root->right = RemoveRec(root->right, data_to_match, cmp_func, param);

		return AVLTreeBalance(root);
	}

	/* Data found */
	child_left = root->left;
	child_right = root->right;
	free(root);

	if (NULL == child_right) 		/* In case of 1 child */
	{
		return child_left;
	}
	if (NULL == child_left)
	{
		return child_right;
	}

	next = FindMin(child_right);		/* In case of 2 child */
	next->right = DeleteMin(child_right);
	next->left = child_left;

	return AVLTreeBalance(next);
}

/* Return value: value removed */ 
/***********************************************************************/
void AVLTreeRemove(avl_t *tree, const void *data_to_match)
{
	assert(tree && data_to_match);

	tree->root = RemoveRec(tree->root, data_to_match, tree->cmp_func, tree->param);
} 

/***********************************************************************/
static void MultiRemoveImp(avl_t *tree, node_t *node, avl_match_func_t match_func, const void *param)
{
	if (NULL == node)
	{
		return;
	}
	
	MultiRemoveImp(tree, node->left, match_func, param);
	MultiRemoveImp(tree, node->right, match_func, param);

	if (1 == match_func(node->data, param))
	{
		AVLTreeRemove(tree, node->data);
	}
}

/***********************************************************************/
void AVLTreeMultiRemove(avl_t *tree, avl_match_func_t match_func, const void *param)
{
	assert(tree && match_func);

	MultiRemoveImp(tree, tree->root, match_func, param);	
}

/***********************************************************************/
static void MultiFindImp(node_t *node, dlist_t *found_list, avl_match_func_t match_func, const void *param)
{
	if (NULL == node)
	{
		return;
	}
	
	MultiFindImp(node->left, found_list, match_func, param);
	MultiFindImp(node->right, found_list, match_func, param);

	if (1 == match_func(node->data, param))
	{
		DListPushBack(found_list, node->data);
	}
}

/***********************************************************************/
void AVLTreeMultiFind(const avl_t *tree, dlist_t *found_list, avl_match_func_t match_func, const void *param)
{
	assert(tree && match_func && found_list);

	MultiFindImp(tree->root, found_list, match_func, param);
}

