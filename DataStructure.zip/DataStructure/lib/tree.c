#include  "../include/tree.h"
#include <assert.h> 			/* assert */
#include <stdio.h>

#define DUMMY 0xBEEFDEAD
#define UNUSED(x)(void)(x)

typedef enum {LEFT, RIGHT} child_t;

typedef struct tree_node tree_node_t;

struct tree_node
{
	tree_node_t *parent;
	tree_node_t *children[2];
	void *data;
};

struct tree
{
	tree_node_t stub;	
	tree_cmp_func_t cmp_func;
	const void *param;
};

typedef struct find
{
	tree_node_t *node;
	tree_node_t *parent;
	child_t child;
} find_t;


static tree_node_t *CreateTreeNode(tree_node_t *parent, tree_node_t *left, tree_node_t *right, void *data);

static tree_node_t *FindLeafImp(tree_node_t *node, child_t child);
static tree_node_t *FindParentImp(tree_node_t *node, child_t child);
static find_t FindImp(const tree_t *tree, void *data);

static int NumOfChildren(tree_node_t *node);
static void *RemoveLeaf(tree_node_t *node, void *val);
static void *RemoveSecondChild(tree_node_t *node);
static void *RemoveOneChild(tree_node_t *node, void *val);

static size_t PostOrderTraversal(tree_t *tree, tree_act_func_t act_func);



/* REMOVE */
size_t AVLTreeCount(const tree_t *tree);
static size_t CountRec(tree_node_t *root);

/***********************************************************************/
tree_t *TreeCreate(tree_cmp_func_t cmp_func, const void *param)
{
	tree_t *tree = NULL;
	tree_node_t stub = {0};

	assert(cmp_func);

	tree = malloc(1 * sizeof(tree_t));
	if (NULL == tree)
	{
		return NULL;
	}

	stub.parent = NULL;
	stub.children[LEFT] = NULL;
	stub.children[RIGHT] = NULL;
	stub.data = (void *)DUMMY;

	tree->stub = stub;
 	tree->cmp_func = cmp_func;
	tree->param = param;

	return tree;
}

/***********************************************************************/
static tree_node_t *CreateTreeNode(tree_node_t *parent, tree_node_t *left, tree_node_t *right, void *data)
{
	tree_node_t *tree_node = NULL;
	
	tree_node = malloc(1 * sizeof(tree_node_t));

	if (NULL == tree_node)
	{
		return NULL;
	}
	tree_node->parent = parent; 
	tree_node->children[LEFT] = left;
	tree_node->children[RIGHT] = right;
	tree_node->data = data;

	return tree_node;
}
	
/**************************************************
size_t TreeCount(const tree_t *tree)  
{
	assert(tree);

	return (PostOrderTraversal((tree_t *)tree, NULL));
}
*********************/

/***********************************************************************/
size_t AVLTreeCount(const tree_t *tree)
{
	return CountRec(tree->stub.children[LEFT]);
}

/***********************************************************************/
static size_t CountRec(tree_node_t *root)
{
	if (NULL == root)
	{
		return 0;
	}

	return 1 + CountRec(root->children[0]) + CountRec(root->children[1]);
}

/***********************************************************************/
int TreeIsEmpty(const tree_t *tree)
{
	assert(tree);
	
	return (NULL == tree->stub.children[LEFT]);
}

/***********************************************************************/
/* Return value: iterator to the value inserted, END iterator on failure*/
tree_iter_t TreeInsert(tree_t *tree, void *data)
{
	tree_node_t *node = NULL;
	find_t find = {0};

	assert(tree && data);
	
	find = FindImp(tree, data);
	if (NULL != find.node)
	{
		if (0 == tree->cmp_func(data, find.node->data, tree->param))  /* Checks duplicate value */
		{
			return TreeEnd(tree);
		}
	}

	node = CreateTreeNode(NULL, NULL, NULL, data);
	if (NULL != node)
	{
		node->parent = find.parent;
		node->parent->children[find.child] = node;
	}
	else   /* Malloc failed */
	{
		return TreeEnd(tree);
	}
	
	return node; 
}

/***********************************************************************/
/* Return value: iterator to the value removed */ 
void *TreeRemove(tree_iter_t remove_node)
{
	tree_node_t *node = NULL;
	
	assert(remove_node);
	
	node = (tree_node_t *)remove_node;
	
	switch (NumOfChildren(node))
	{
		case 0:
		{
			return RemoveLeaf(node, NULL);
		}
		case 1:
		{
			return RemoveOneChild(node, NULL);
		}
		case 2:
		{
			return RemoveSecondChild(node);	
		}
	}	
	return NULL;
}

/***********************************************************************/
static int NumOfChildren(tree_node_t *node)
{
	 return ((NULL != node->children[LEFT]) + (NULL != node->children[RIGHT]));
}

/***********************************************************************/
/* Case 1 - no children: remove leaf (free) */
static void *RemoveLeaf(tree_node_t *node, void *val)
{	
	void *data = NULL;
	int child = 0;

	if (NULL != node->parent)
	{
		child = (node == node->parent->children[RIGHT]);
		data = node->data;	
		node->parent->children[child] = NULL;
		free(node);
	}			
	return (NULL != val) ? val : data;
}

/***********************************************************************/	
/* Case 2 - 1 children:  update parent and childs pointers */
static void *RemoveOneChild(tree_node_t *node, void *val)
{
	void *data = NULL;
	child_t child = 0;
	child_t childs_child = 0;
	
	if (NULL != node->parent)
	{
		child = (node == node->parent->children[RIGHT]); 	/* check son direction */
		childs_child = (NULL != node->children[RIGHT]);		/* check grandson direction */

		data = node->data;
		node->parent->children[child] = node->children[childs_child];
		node->children[childs_child]->parent = node->parent;
		
		free(node);	
	}			
	return (NULL != val) ? val : data;
}

/***********************************************************************/
/* Case 3 - 2 children: swap values with NEXT and remove 1child */
static void *RemoveSecondChild(tree_node_t *node)
{
	tree_node_t *next = NULL;

	next = (tree_node_t *)TreeNext(node);

	return (0 == NumOfChildren(next)) ? RemoveLeaf(next, node->data) : RemoveOneChild(next, node->data);
}
	
/***********************************************************************/
tree_iter_t TreePrev(const tree_iter_t iter)
{
	tree_node_t *node = NULL;

	assert(iter);

	node = (tree_node_t *)iter;

	return ((NULL != node->children[LEFT]) ? FindLeafImp(node->children[LEFT], RIGHT) :  FindParentImp(node, RIGHT));
}

/***********************************************************************/
tree_iter_t TreeNext(const tree_iter_t iter)
{
	tree_node_t *node = NULL;	
	
	assert(iter);

	node = (tree_node_t *)iter;

	return ((NULL != node->children[RIGHT]) ? FindLeafImp(node->children[RIGHT], LEFT) : FindParentImp(node, LEFT));
}

/***********************************************************************/
static tree_node_t *FindLeafImp(tree_node_t *node, child_t child)
{
	assert(node);

	while (NULL != node->children[child])
	{
		node = node->children[child];
	}
		 
	return node;
}

/***********************************************************************/
static tree_node_t *FindParentImp(tree_node_t *node, child_t child)    
{
    tree_node_t *parent = NULL;
    assert(node);
	
    parent = node->parent;

    while (NULL != node->parent)
    {
        if ((parent->children[child]) == node)
        {
            break;
        }
        node = parent;
        parent = parent->parent;
    }

    return parent;
}
/***********************************************************************/
/* Return value: iterator to the value found, END iterator on failure*/  
tree_iter_t TreeFind(const tree_t *tree, void *data)
{
	find_t find = {0};

	assert(tree && data);	
	
	find = FindImp(tree, data);

	return ((NULL != find.node) ? find.node : TreeEnd(tree));
}

/***********************************************************************/
static find_t FindImp(const tree_t *tree, void *data)
{
	tree_node_t *node = NULL;
	tree_node_t *parent = NULL;

	find_t find = {0};
	int cmp_result = 0;
	child_t child = 0;

	assert(tree);

	/* Initialize root node */
	node = tree->stub.children[LEFT];
	parent = (void *)&tree->stub;
	child = LEFT;

	while (NULL != node) 
	{
		/* Compare given data with nodes data */
		cmp_result = tree->cmp_func(data, node->data, tree->param);
		
		/* Nodes are equal */
		if (0 == cmp_result)
		{
			break;
		}		
		/* If result is 1 - next child is RIGHT,  If result is -1 - next child is LEFT */
		child = (1 == cmp_result);
		parent = node;
		node = node->children[child];
	}

	/* Update find data struct */
	find.child = child;
	find.node = node;
	find.parent = parent;	
	
	return find;
}

/***********************************************************************/
/* Return value: iterator to the minimum value */ 
tree_iter_t TreeBegin(const tree_t *tree)
{
	tree_node_t *begin = NULL;
	
	assert(tree);
	
	begin = FindLeafImp((tree_node_t *)(&tree->stub), LEFT);
	
	return (begin ? begin : TreeEnd(tree));
}

/***********************************************************************/
/* Return value: iterator to the stub */ 
tree_iter_t TreeEnd(const tree_t *tree)
{
	assert(tree);	

	return (void *)&tree->stub;
}

/***********************************************************************/
void *TreeGetData(const tree_iter_t iter)
{
	assert(iter);

	return ((tree_node_t *)iter)->data;
}

/***********************************************************************/
/* Return value: True - 1, False - 0*/
int TreeIsSameIter(const tree_iter_t iter1, const tree_iter_t iter2)
{
	assert(iter1 && iter2);
	return (iter1 == iter2);
}

/***********************************************************************/
int TreeForEach(tree_t *tree ,tree_iter_t from, tree_iter_t to, tree_act_func_t act_func, void *param)
{
	tree_iter_t iter = from;
	assert(from && to && act_func);
	UNUSED(tree);
	
	while (!TreeIsSameIter(iter, to))
	{
		if(0 == act_func(TreeGetData(iter), param))
		{
			return 0;	
		}
		iter = TreeNext(iter);
	}
	return 1;
}

/***********************************************************************/
static size_t PostOrderTraversal(tree_t *tree, tree_act_func_t act_func)
{
    tree_node_t *node = tree->stub.children[LEFT];
    tree_node_t *prev = &tree->stub;
    size_t count = 0;

    while (&tree->stub != node) 
	{
  		if (NULL == node)
		{
			node = prev;
			prev = NULL;
		}		
		else if (prev == node->children[RIGHT])
		{	
			prev = node;		
			++count;
			node = prev->parent;		

			if (act_func)
			{
				act_func(prev, NULL);
			}
		}
		else if (prev == node->children[LEFT])
		{
			prev = node;
			node = node->children[RIGHT];
		}
		else
		{	
			prev = node;
			node = node->children[LEFT];
		}
		
	}  	
	return count;
}

/***********************************************************************/
static int FreeNode(void *val, void *param)
{
	tree_node_t *node = (tree_node_t *)val;

	UNUSED(param);

	free(node);
	
	return 1;
}

/***********************************************************************/
void TreeDestroy(tree_t *tree)
{
	assert(tree);

	PostOrderTraversal(tree, FreeNode);
	
	free(tree);
}

/***********************************************************************/
static int PrintNode(void *val, void *param)
{
	UNUSED(param);
	printf("%d ", *(int *)((tree_node_t *)val)->data);
	return 1;
}

/***********************************************************************/
void *PrintTraversal(tree_t *tree)
{
	PostOrderTraversal(tree, PrintNode);
}

