#include  "../include/hash.h"
#include  "../include/dlist.h"

#include <assert.h>     /* assert */
#include <math.h>       /* statistics - COMPILE with -lm */

#define MAX_SIZE(a, b)(a > b ? a : b)

struct hash
{
	size_t hash_size;
	hash_func_t hash_func;
	cmp_func_t cmp_func;
	const void *param;
	dlist_t **table;
};

/*-----------  Complexity - O(k) -----------*/
hash_t *HashCreate(size_t hash_size, hash_func_t hash_func, hash_cmp_func_t cmp_func, const void *param)
{
	hash_t *hash = NULL;
	dlist_t **table = NULL;

	assert(hash_size && hash_func && cmp_func);

	hash = (hash_t *)malloc(1 * sizeof(hash_t));

	if (NULL == hash)
	{
		return NULL;
	}

	hash->hash_size = hash_size;
	hash->hash_func = hash_func;
	hash->cmp_func = cmp_func;
	hash->param = param;

	table = (dlist_t **)calloc(hash_size, sizeof(dlist_t *));

	if (NULL == table)
	{
		free(hash);
		return NULL;
	}

	hash->table = table;
	return hash;
}

/*-----------  Complexity - O(k*n) -----------*/
void HashDestroy(hash_t *hash)
{
	size_t i = 0;
	assert(hash);

	for (i = 0; i < hash->hash_size; i++)
	{
		if (hash->table[i])
		{
			DListDestroy(hash->table[i]);
			hash->table[i] = NULL;
		}
	}
	
	free(hash->table);
	hash->table = NULL;
 	free(hash);
}

/*-----------  Complexity - O(k*n) -----------*/
size_t HashSize(const hash_t *hash)
{
	size_t size = 0;
	size_t i = 0;

	assert(hash);

	for (i = 0; i < hash->hash_size; i++)
	{
		if (hash->table[i])
		{
			size += DListSize(hash->table[i]);
		}	
	}
	return size;
}

/*-----------  Complexity - O(k) -----------*/
int HashIsEmpty(const hash_t *hash)
{	
	size_t i = 0;

	assert(hash);

	for (i = 0; i < hash->hash_size; i++)
	{
		if (hash->table[i])
		{
			if (!DListIsEmpty(hash->table[i]))
			{
				return 0;
			}
		}
	}
	return 1;
}

/*-----------  Complexity - O(n) -----------*/
void *HashFind(const hash_t *hash, const void *data)
{
	size_t data_index = 0;

	dlist_t *dlist = NULL;
	dlist_iter_t found = NULL;
	/*void *data_found = NULL;*/

	assert(hash && data);

	data_index = hash->hash_func(data);
	
	assert(data_index <= hash->hash_size);

	dlist = hash->table[data_index];

	if (!dlist)
	{
		return NULL;
	}

	found = DListFind(dlist, DListBegin(dlist), DListEnd(dlist), hash->cmp_func, hash->param, data);

	if (DListEnd(dlist) == found)
	{
		return NULL;
	}

	/*data_found = DListGetData(found);*/
	
	/*DListErase(found); */								/* placing last searched element at the start of relevant dlist*/   				
	/*DListPushFront(dlist, data_found);*/

	return DListGetData(found);
}

/*-----------  Complexity - O(1) -----------*/										
status_t HashInsert(hash_t *hash, void *data)
{
	size_t data_index = 0;

	assert(hash && data);

	data_index = hash->hash_func(data);

	assert(data_index <= hash->hash_size);

	if (!hash->table[data_index])  					  /* Create a new dlist if doesnt exist */
	{
		dlist_t *dlist = DListCreate();

		if (!dlist)
		{
			return MALLOC_FAILURE;	
		}

		hash->table[data_index] = dlist;
	}
 
	if (DListEnd(hash->table[data_index]) == DListPushBack(hash->table[data_index], data))
	{
		return MALLOC_FAILURE;
	}

	return SUCCESS;
}

/*-----------  Complexity - O(n) -----------*/
void *HashRemove(hash_t *hash, void *data)
{
	size_t data_index = 0;
	dlist_t *dlist = NULL;
	dlist_iter_t iter = NULL;
	void *data_removed = NULL;

	assert(hash && data);

	data_index = hash->hash_func(data);
	dlist = hash->table[data_index];

	if (!dlist)
	{
		return NULL;
	}

	assert(data_index <= hash->hash_size && dlist);
	iter = DListFind(dlist, DListBegin(dlist), DListEnd(dlist), hash->cmp_func, hash->param, data);
	
	if (DListEnd(dlist) == iter)
	{
		return NULL;		
	}
	
	data_removed = DListGetData(iter);
	DListErase(iter);

	return data_removed; 
}

/*-----------  Complexity - O(k*n) -----------*/
int HashForEach(hash_t *hash, act_func_t act_func, void *param)
{
	size_t i = 0;

	assert(hash && act_func);

	for (i = 0; i < hash->hash_size; i++)
	{
		if (hash->table[i])
		{
			dlist_t *dlist = hash->table[i];

			if (!DListForEach(DListBegin(dlist), DListEnd(dlist), act_func, param))
			{
				return 0;
			}
		}
	}
	return 1;
}

/*-----------  Complexity - O(k*n) -----------*/
hash_statistic_t GetStatistic(const hash_t *hash)
{
	hash_statistic_t hash_stat = {0};
	
	size_t i = 0;	
	size_t max_col = 0;
	double sigma = 0;
	double std_sigma = 0;

	assert(hash && hash->hash_size > 0); /* (hash->hash_size > 0) - handles division by 0 */

	for (i = 0; i < hash->hash_size; i++)
	{
		if (NULL != hash->table[i])
		{
			size_t size = DListSize(hash->table[i]);
			max_col = MAX_SIZE(size, max_col);
			sigma += size;
		}
	}

	hash_stat.max_collision = max_col;
	hash_stat.average_collision = (sigma / hash->hash_size);

	for (i = 0; i < hash->hash_size; i++)
	{
		if (NULL != hash->table[i])
		{
			std_sigma += pow((DListSize(hash->table[i]) - hash_stat.average_collision), 2);
		}
	}

	hash_stat.STD_collision = sqrt((std_sigma / hash->hash_size));

	return hash_stat;
}

