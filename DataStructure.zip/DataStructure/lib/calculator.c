#include "../include/calculator.h"
#include "../include/stack.h"

#include <assert.h>	  /* assert */
#include <math.h>	  /* pow func */

#define EVENT_NUM 256
#define LUT_SIZE 256
#define STACK_SIZE 50 

#define UNUSED(x)(void)(x)
#define ARRAY_SIZE(arr)((int)(sizeof(arr)/ sizeof(arr[0])))

typedef enum {GET_NUM, GET_OP, STATE_NUM, FINISH} state_t;
typedef enum {LTR = 0, RTL = 1} asso_t;

typedef enum {STUB = -1, OPEN_PAR = 0, ADD = 2, SUB = ADD, MULT = 4, DIV = MULT, POW = 6, CLOSE_PAR = 8} prec_t; 

typedef struct event_handler event_handler_t;
typedef struct op_data op_data_t;

/* represents the data returned from each act_func */
typedef struct data
{
	char *start;
	char *end;
	stack_t *num_stack;
	stack_t *op_stack;
} data_t;

typedef status_t (*act_func_t)(data_t *data);
typedef double (*calculate_t)(double num1, double num2);

struct event_handler 
{
    char event;
    act_func_t act_func;
    state_t next_state;
};

struct op_data
{
    char op;
    prec_t precedence;
    asso_t associativity;
    calculate_t calculate_func;
};

/* calculate_t funcs */
static double Add(double num1, double num2);
static double Mult(double num1, double num2);
static double Div(double num1, double num2);
static double Sub(double num1, double num2);
static double Power(double num1, double num2);
static double None(double num1, double num2);
	
/* act_func_t funcs */
static status_t Nope(data_t *data);
static status_t HandleNum(data_t *data);
static status_t HandleOp(data_t *data);
static status_t NumError(data_t *data);
static status_t OpError(data_t *data);

static status_t Calculate(data_t *data);
static status_t FinalCalc(data_t *data);
static status_t BracetsCalc(data_t *data);
static status_t HandlePar(data_t *data);

static data_t InitData(const char *expression, status_t *status);
static void InitOpLUT(void);
static void InitMachineLUT(void);

static op_data_t *op_lut[LUT_SIZE] = {0};

static op_data_t op_data[] = {{'1', STUB, LTR, None},
							  {'+', ADD, LTR, Add},
			     			  {'-', SUB, LTR, Sub},
			    			  {'*', MULT, LTR, Mult},
 			      			  {'/', DIV, LTR, Div},
							  {'(', OPEN_PAR, LTR, None},
							  {')', CLOSE_PAR, LTR, None},
							  {'^', POW, RTL, Power}};

static event_handler_t get_num_state[] = {{'x', NumError, FINISH},
										  {'0', HandleNum, GET_OP},
										  {'1', HandleNum, GET_OP},
										  {'2', HandleNum, GET_OP},
										  {'3', HandleNum, GET_OP},
										  {'4', HandleNum, GET_OP},
										  {'5', HandleNum, GET_OP},
										  {'6', HandleNum, GET_OP},
										  {'7', HandleNum, GET_OP},
										  {'8', HandleNum, GET_OP},
										  {'9', HandleNum, GET_OP},
										  {'(', HandlePar, GET_NUM},									  
										  {'+', HandleNum, GET_OP},
										  {'-', HandleNum, GET_OP},
										  {'.', HandleNum, GET_OP},
										  {' ', Nope, GET_NUM},
										  {'\n', Nope, GET_NUM},
										  {'\t', Nope, GET_NUM},
										  {'\f', Nope, GET_NUM},
										  {'\r', Nope, GET_NUM},
										  {'\v', Nope, GET_NUM}};

static event_handler_t get_op_state[] = {{'x', OpError, FINISH},
										 {'+', HandleOp, GET_NUM},
										 {'-', HandleOp, GET_NUM},
									     {'/', HandleOp, GET_NUM},
										 {'*', HandleOp, GET_NUM},
										 {'^', HandleOp, GET_NUM},
										 {'\n', Nope, GET_OP},
										 {' ', Nope, GET_OP},
										 {'\t', Nope, GET_OP},
										 {'\f', Nope, GET_OP},
										 {'\r', Nope, GET_OP},
										 {'\v', Nope, GET_OP},
										 {')', BracetsCalc, GET_OP},
										 {'\0', FinalCalc, FINISH}};

static event_handler_t *machine_lut[STATE_NUM][EVENT_NUM] = {0};

/***********************************************************************/
double Calculator(const char *expression, status_t *status)
{
	double result = 0;
	data_t data = {0};

	event_handler_t *event = NULL;	
	state_t curr_state = GET_NUM;
	*status = SUCCESS;
	
	data = InitData(expression, status);	
	
	/* Check if LUTs need to be initialized */
	if (NULL == op_data['+'].calculate_func)
	{
		InitOpLUT();
		InitMachineLUT();
	}

	while (FINISH != curr_state)
	{
		event = machine_lut[curr_state][(int)*(data.start)];
		*status = event->act_func(&data);

		if (SUCCESS != *status)
		{
			StackDestroy(data.num_stack);
			StackDestroy(data.op_stack);			
			
			return 0;		
		}

		curr_state = event->next_state;
	}
	
	result = *(double *)StackPeek(data.num_stack);

	StackDestroy(data.num_stack);
	StackDestroy(data.op_stack);
	
	return result; 
}

/***********************************************************************/
static data_t InitData(const char *expression, status_t *status)
{
	data_t data = {0};
	char stub_val = '1';
	
	data.start = (char *)expression;
	data.end = NULL;

	data.num_stack = StackCreate(STACK_SIZE, sizeof(double));
	if (!data.num_stack)
	{
		*status = MALLOC_FAILURE;
		return data;
	}

	data.op_stack = StackCreate(STACK_SIZE, sizeof(char));
	if (!data.op_stack)
	{
		*status = MALLOC_FAILURE;
		StackDestroy(data.num_stack);
		return data;
	}

	StackPush(data.op_stack, &stub_val);	 /* insert a STUB as first element in operators stack */
	
	return data;
}

/***********************************************************************/
static void InitOpLUT(void)
{
	int i = 0;

	for (i = 0; i < LUT_SIZE; i++)
	{
		op_lut[i] = NULL;
	}

	for (i = 0; i < ARRAY_SIZE(op_data); i++)
	{ 
		op_lut[(int)op_data[i].op] = &op_data[i];
	}
}

/***********************************************************************/
static void InitMachineLUT(void)
{
	int i = 0;
																
	for (i = 0; i < EVENT_NUM; i++)
	{
		machine_lut[GET_NUM][i] = &get_num_state[0];
		machine_lut[GET_OP][i] = &get_op_state[0];
	}
	
	for (i = 0; i < ARRAY_SIZE(get_num_state); i++)
	{ 
		machine_lut[GET_NUM][(int)get_num_state[i].event] = &get_num_state[i];
	}

	for (i = 0; i < ARRAY_SIZE(get_op_state); i++)
	{
		machine_lut[GET_OP][(int)get_op_state[i].event] = &get_op_state[i]; 
	}
}

/***********************************************************************/
static status_t Calculate(data_t *data)
{	
	double num1 = 0;
	double num2 = 0;
	char op = 0;

	num1 = *(double *)StackPeek(data->num_stack);
	StackPop(data->num_stack);

	num2 = *(double *)StackPeek(data->num_stack);
	StackPop(data->num_stack);

	op = *(char *)StackPeek(data->op_stack);
	StackPop(data->op_stack);

	num1 = op_lut[(int)op]->calculate_func(num2, num1);
	
	StackPush(data->num_stack, &num1);
	
	return SUCCESS;
}

/***********************************************************************/
static status_t CalcImp(data_t *data, char op, char error_op)
{
	char top_op = *(char *)StackPeek(data->op_stack); 	/* top_op: operator found in top of stack */	
	
	while (op != top_op)					/* op: matching operator of "folding" operator */ 
	{	
		if (error_op == top_op) 			/* error_op: invalid operator in current stack "folding" */
		{
			return INVALID_OPERATOR;
		}

		Calculate(data);
		
		top_op = *(char *)StackPeek(data->op_stack);
	}
	
	return SUCCESS;
}

/***********************************************************************/
/* called when a valid '\0' event is found */
static status_t FinalCalc(data_t *data) 		
{
	return CalcImp(data, '1', '(');
}

/***********************************************************************/
/* called when a valid ')' event is found */
static status_t BracetsCalc(data_t *data)
{
	status_t stat = CalcImp(data, '(', '1'); 
	if (SUCCESS == stat)
	{
		StackPop(data->op_stack); 		
	}
	++data->start;
	return stat;
}

/***********************************************************************/
static status_t HandleOp(data_t *data)
{
	char op = *(data->start);
	char top_op = *(char *)StackPeek(data->op_stack);
	
	prec_t top_op_prec = op_lut[(int)top_op]->precedence;
	prec_t op_prec = op_lut[(int)op]->precedence;	
	int op_assoc = op_lut[(int)op]->associativity;
	
	/* Comparing stacks top operator precedance with current operator values*/
	while ((op_prec + op_assoc) <= top_op_prec)
	{			
		Calculate(data);
		top_op = *(char *)StackPeek(data->op_stack);
		top_op_prec = op_lut[(int)top_op]->precedence;
	}
	
	StackPush(data->op_stack, &op);
	++data->start;

	return SUCCESS;
}

/***********************************************************************/
static status_t HandleNum(data_t *data)
{
	double num = strtod(data->start, &data->end);	

	if (!num && data->end == data->start)
	{
		return INVALID_NUM;
	}

	StackPush(data->num_stack, &num);	
	
	data->start = data->end;

	return SUCCESS;
}

/***********************************************************************/
/* called when a valid '(' event is found */
static status_t HandlePar(data_t *data)
{
	char op = *(data->start);
	StackPush(data->op_stack, &op);

	++data->start;

	return SUCCESS;
}

/***********************************************************************/
/* called when a valid space is found in expression*/
static status_t Nope(data_t *data)
{
	++data->start;

	return SUCCESS;
}

/***********************************************************************/
static status_t NumError(data_t *data)
{
	UNUSED(data);

	return INVALID_NUM;
}

/***********************************************************************/
static status_t OpError(data_t *data)
{
	UNUSED(data);

	return INVALID_OPERATOR;
}

/***********************************************************************/

static double Add(double num1, double num2)
{	
	return num1 + num2;
}

static double Mult(double num1, double num2)
{
	return num1 * num2;
}

static double Div(double num1, double num2)
{
	assert(num2);

	return num1 / num2;
}

static double Sub(double num1, double num2)
{
	return num1 - num2;
}

static double Power(double num1, double num2)
{
	return pow(num1, num2);
}

static double None(double num1, double num2)
{
	UNUSED(num1);
	UNUSED(num2);

	return -1;
}
