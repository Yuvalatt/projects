#include "../include/pqueue.h"   		 /* CR: change libraries order */
#include "../include/heap.h"
#include <assert.h>

#define UNUSED(x) (void)(x)				 /* CR: extra space */

 struct pqueue
 {
 	heap_t *heap;
 };

 struct find_arg
 {
    pq_cmp_func_t cmp_func;
 	void *param;
 };

struct cmp_arg
 {
    pq_is_before_t is_before;
 	void *param;
 };

pq_t *PQCreate(pq_is_before_t is_before, void *param)
{
    pq_t *queue = (pq_t *)malloc(1 * sizeof(pq_t));
	
	if (NULL == queue)
	{
		return NULL;
	}

    queue->heap = HeapCreate((heap_cmp_func_t)is_before, param);
	
	if (NULL == queue->heap)
	{
		free(queue);
        queue = NULL;
		return NULL;
	}
	
	return queue;
}

void PQDestroy(pq_t *pqueue)
{
    assert(pqueue && pqueue->heap);
	
	HeapDestroy(pqueue->heap);
    pqueue->heap = NULL;
	free(pqueue);
	pqueue = NULL;
}

size_t PQSize(const pq_t *pqueue)
{
    assert(pqueue && pqueue->heap);
	
	return HeapSize(pqueue->heap);
}

int PQIsEmpty(const pq_t *pqueue)		 	/* return value empty - 1, not empty - 0 */
{
    assert(pqueue && pqueue->heap);
	
	return HeapIsEmpty(pqueue->heap);
}

int PQEnqueue(pq_t *pqueue, void *data) 	/*   SUCCESS - 0, FAILURE (malloc) - 1 	 */
{
    assert(pqueue && pqueue->heap);

    return HeapPush(pqueue->heap, data);   
}

void *PQDequeue(pq_t *pqueue)			 	/*   Do not perform on an empty queue 	 */
{
     assert(pqueue && pqueue->heap);
    
     return HeapPop(pqueue->heap);
}

void *PQPeek(const pq_t *pqueue) 			/*   Do not perform on an empty queue 	 */
{
    assert(pqueue && pqueue->heap);

    return HeapPeek(pqueue->heap);
}

static int Find(const void *data, const void *data_to_find, const void *param)	/*  True - 1, False - 0 */
{
    const struct find_arg *argv = param;

    UNUSED(data_to_find);

    return argv->cmp_func(data, argv->param); 
}

void *PQErase(pq_t *pqueue, pq_cmp_func_t CmpFunc, void *param)
{
     struct find_arg temp = {0};

     assert(pqueue && pqueue->heap && CmpFunc);

     temp.cmp_func = CmpFunc;
     temp.param = param; 

     return HeapRemove(pqueue->heap, Find, NULL ,&temp);
}

void PQClearAll(pq_t *pqueue)
{
    assert(pqueue);
	
	while (!PQIsEmpty(pqueue))
	{
		HeapPop(pqueue->heap);
	}    
}
