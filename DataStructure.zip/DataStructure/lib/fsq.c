#include <stdio.h>  
#include <assert.h>  		/* assert        */
#include <stdlib.h>  		/* EXIT_SUCCESS  */
#include <string.h> 		/* memcpy        */
#include "../include/fsq.h"

struct fsq
{
	int *reader;
	int *writer;
	int *end;
	int *start;
}; 

fsq_t *FSQCreate(size_t n_elements)
{
	fsq_t *fsq = (fsq_t *)malloc(sizeof(fsq_t) + (n_elements * sizeof(int)));
	assert(n_elements > 0);
	
	if (NULL == fsq)
	{
		return NULL;
	}
	
	fsq->start = (int *)((char *)fsq + sizeof(fsq_t));
	fsq->reader = fsq->start;
	fsq->writer = fsq->start;
	fsq->end = (int *)((char *)fsq->start + (n_elements * sizeof(int)));

	return fsq; 
}

void FSQDestroy(fsq_t *fsq)
{
	assert(fsq);
		
	free(fsq);
	fsq = NULL;
}

void FSQEnqueue(fsq_t *fsq, const int data)
{
	assert(fsq);

	if (fsq->writer == fsq->end)
	{
		fsq->writer = fsq->start;
	}
	
	*fsq->writer = data;

	++fsq->writer;
}

int FSQDequeue(fsq_t *fsq)
{
	int value = 0;
	
	assert(fsq);

	if (fsq->reader == fsq->end)
	{
		fsq->reader = fsq->start;
	}

	value = *fsq->reader;

	++fsq->reader;

	return value;
}
