#include "../include/barr.h" 
#include <stdio.h>
#include <stdlib.h>  /* EXIT_SUCCESS */
#include <assert.h> /* index validation */

#define BARR_SIZE 64
#define LUT_SIZE 256 

static size_t lut_mirror[LUT_SIZE] = {0}; 
static size_t lut_count[LUT_SIZE] = {0};

static void InitLUTCount(void);
static void InitLUTMirror(void);
static unsigned int ByteMirror(unsigned int num);

/**************************************************************************************************/

barr_t BarrAllOn(void)
{
	return -1UL; /* better to use 0xFFFFFFFFFFFFFFFF ? */
}

barr_t BarrAllOff(void)
{
	return 0UL;
}

barr_t BarrSetOn(barr_t barr, size_t index)
{
	assert(BARR_SIZE > index);
	return (barr | (1UL << index));
}

barr_t BarrSetOff(barr_t barr, size_t index)
{
	assert(BARR_SIZE > index);
	return (barr & ~(1UL << index));
}

barr_t BarrSetBit(barr_t barr, size_t index, int value)
{
	assert(BARR_SIZE > index);
    return (((value << index)) | (barr & (~(1UL << index))));
}

barr_t BarrToggleBit(barr_t barr, size_t index)
{
	assert(BARR_SIZE > index);
	return (barr ^ (1UL << index));
}

int BarrIsOn(barr_t barr, size_t index)
{
	assert(BARR_SIZE > index);
	return ((barr >> index) & 0x1);
}

int BarrIsOff(barr_t barr, size_t index)
{
	assert(BARR_SIZE > index);
	return (!BarrIsOn(barr, index));
	
}

size_t BarrCountOn(barr_t barr)
{
	size_t count = 0;
	
	while(barr > 0)
	{
		barr &= (barr - 1);
		++count;
	}	
	return count;
}

size_t BarrCountOff(barr_t barr)
{
	return (BARR_SIZE - BarrCountOn(barr));
}


barr_t BarrRotR(barr_t barr, size_t n)
{	
	barr_t tmp_barr = barr;
	return (tmp_barr << (BARR_SIZE - n) | barr >> n);
}

barr_t BarrRotL(barr_t barr, size_t n)
{
	barr_t tmp_barr = barr;
	return (tmp_barr >> (BARR_SIZE- n) | barr << n);
}

barr_t BarrMirror(barr_t barr)
{
	barr = ((barr >> 32) | (barr << 32));
	barr = (((barr >> 16) & 0x0000FFFF0000FFFF) | ((barr << 16) & 0xFFFF0000FFFF0000)); 
	barr = (((barr >> 8) & 0x00FF00FF00FF00FF) | ((barr << 8) & 0xFF00FF00FF00FF00)); 
	barr = (((barr >> 4) & 0x0F0F0F0F0F0F0F0F) | ((barr << 4) & 0xF0F0F0F0F0F0F0F0)); 
	barr = (((barr >> 2) & 0x3333333333333333) | ((barr << 2) & 0xCCCCCCCCCCCCCCCC));
	barr = (((barr >> 1) & 0x5555555555555555) | ((barr << 1) & 0xAAAAAAAAAAAAAAAA)); 	
	
	return barr;
}

barr_t BarrLUTMirror(barr_t barr)
{
	size_t i = 0;
	barr_t mirror = 0;
	if(0 == lut_mirror[1])
	{
		InitLUTMirror();
	}
	for (i = 0; i < 8; i++)
	{
		mirror <<= 8;
		mirror |= lut_mirror[barr & 0xFF]; /*Retrieves mirror of rightmost 8 bits*/ 
		barr >>= 8; 
	}	
	return mirror;
}

size_t BarrLUTCountOn(barr_t barr)
{
	size_t count = 0;
	if(0 == lut_count[1])
	{
		InitLUTCount();
	}
	while (barr > 0)
	{
		count += lut_count[barr & 0xFF]; /*Retrieves num of on bits of rightmost 8 bits*/ 
		barr >>= 8;
	}
	return count;
}

/**************************************************************************************************/

static void InitLUTMirror(void)
{
	size_t i = 0;
	for (i = 0; i < LUT_SIZE; i++)
	{
		lut_mirror[i] = ByteMirror(i);
	}
}
 
static void InitLUTCount(void)
{
	size_t i = 0;
	for (i = 0; i < LUT_SIZE; i++)
	{
		lut_count[i] = BarrCountOn(i);
	}
}
 /* Mirror function for a single Byte */
static unsigned int ByteMirror(unsigned int num) 
{
	num = (((num >> 4) & 0x0F) | ((num << 4) & 0xF0)); 
	num = (((num >> 2) & 0x33) | ((num << 2) & 0xCC)); 
	num = (((num >> 1) & 0x55) | ((num << 1) & 0xAA)); 	
	return num;
}
