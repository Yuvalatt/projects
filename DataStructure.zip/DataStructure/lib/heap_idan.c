#include <assert.h> /* assert */
#include <stdlib.h> /* malloc */
#include <stdio.h>  /* puts */

#include "../include/heap.h"
#include "../include/dynvec.h"

#define DUMMY (void *) 0XDEADBEEF
#define INDX_ADDRESS(index) ((DVGetItemAddress(heap->vec, index)))
#define PARENT_ADDRESS(index) (DVGetItemAddress(heap->vec, index / 2))
#define LEFT_CHILD_ADDRESS(index) (DVGetItemAddress(heap->vec, index * 2))
#define RIGHT_CHILD_ADDRESS(index) (DVGetItemAddress(heap->vec, index * 2 + 1))

struct heap
{
    dv_t *vec;
    heap_cmp_func_t cmp_func;
    const void *param;
};
void PrintHeap(heap_t *heap);

static size_t MaxChildIndex(heap_t *heap, size_t index)
{   /* if left child is before */
    if (1 == heap->cmp_func(*(void **) LEFT_CHILD_ADDRESS(index), *(void **) RIGHT_CHILD_ADDRESS(index), heap->param))
    {
        return index * 2;
    }
    return index * 2 + 1;
}

static void SwapPtrs(void **ptr1, void **ptr2)
{
    void *hold = NULL;

    assert(ptr1 && ptr2);

    hold = *ptr1;
    *ptr1 = *ptr2;
    *ptr2 = hold;
}

static void HeapifyUp(heap_t *heap, size_t index)
{
    if (index > 1 && 1 == heap->cmp_func(*(void **)(DVGetItemAddress(heap->vec, index)), *(void **)(DVGetItemAddress(heap->vec, index / 2)), heap->param))
    {
        SwapPtrs(INDX_ADDRESS(index), PARENT_ADDRESS(index));
        HeapifyUp(heap, index / 2);
    }
}

static void HeapifyDown(heap_t *heap, size_t index)
{   /* if he is not a father yet */
    if (index * 2 > HeapSize(heap))
    {
        return;
    }
    /* if has only one (left) child */
    if (index * 2 == HeapSize(heap))
    {
        if (-1 == heap->cmp_func(*(void **)(INDX_ADDRESS(index)), *(void **)(LEFT_CHILD_ADDRESS(index)), heap->param))
        {
            SwapPtrs(INDX_ADDRESS(index), LEFT_CHILD_ADDRESS(index));
            HeapifyDown(heap, index * 2);
            return;
        }
    }
    /* if he has 2 children - compare with the max of them */
    if (-1 == heap->cmp_func(*(void **) INDX_ADDRESS(index), *(void **) INDX_ADDRESS(MaxChildIndex(heap ,index)), heap->param))
    {
        size_t where = MaxChildIndex(heap ,index); /* index for pointers swap and for the next recursive step */
        SwapPtrs(INDX_ADDRESS(index), INDX_ADDRESS(where));
        HeapifyDown(heap, where);
    }
}

/* complexity O(1) */
heap_t *HeapCreate(heap_cmp_func_t cmp_func, const void *param)
{
    heap_t *heap = NULL; 
    void *stub = DUMMY;
    
    assert(cmp_func);

    heap = (heap_t *) malloc(1 * sizeof(heap_t));
    if (!heap)
    {
        return NULL;
    }

    heap->vec = (dv_t *) DVCreate(0, sizeof(void *));
    if (!heap->vec)
    {
        free(heap);
        return NULL;
    }

    heap->param = param;
    heap->cmp_func = cmp_func;
    /* push dummy so index starts from 1 instead of 0 */
    if (1 == DVPushBack(heap->vec, &stub)) 
    {
        DVDestroy(heap->vec);
        free(heap);
        return NULL;
    }

    return heap;
}

/* complexity O(1) */
void HeapDestroy(heap_t *heap)
{
    assert(heap);
    
    DVDestroy(heap->vec);
    free(heap);
    heap = NULL;
}

size_t HeapSize(const heap_t *heap)
{
    assert(heap);

    return DVSize(heap->vec) - 1;
}

int HeapIsEmpty(const heap_t *heap)
{
    assert(heap);

    return DVSize(heap->vec) == 1;
}

void *HeapPeek(const heap_t *heap)
{
    assert(heap && !HeapIsEmpty(heap));

    return *(void **) INDX_ADDRESS(1);
}

heap_stat_t HeapPush(heap_t *heap, void *data)
{
    assert(heap);

    if (1 == DVPushBack(heap->vec, &data))
    {
        return HEAP_MALLOC_FAILURE;
    }
    HeapifyUp(heap, HeapSize(heap));
    /*PrintHeap(heap);*/
    return HEAP_SUCCESS;
}

void *HeapPop(heap_t *heap)
{
    void *to_remove = NULL;
    assert(heap);

    SwapPtrs(INDX_ADDRESS(1), INDX_ADDRESS(HeapSize(heap)));
    
    to_remove = INDX_ADDRESS(DVSize(heap->vec) - 1);

    DVPopBack(heap->vec);
    HeapifyDown(heap, 1);
    /*PrintHeap(heap);*/
    return *(void **)to_remove;
}

void *HeapRemove(heap_t *heap, heap_find_t find_func, void *data_to_remove, void *param)
{
    size_t index = 1;
    void *to_remove = NULL;
    
    assert(heap && find_func && data_to_remove && !HeapIsEmpty(heap));

    while (index <= HeapSize(heap))
    {
        if (find_func(data_to_remove, *(void **)INDX_ADDRESS(index)))
        {
            break;
        }
        ++index;
    }
    if (index <= HeapSize(heap))
    {
        SwapPtrs(INDX_ADDRESS(index), INDX_ADDRESS(HeapSize(heap)));
        to_remove = INDX_ADDRESS(HeapSize(heap));
        DVPopBack(heap->vec);
        HeapifyDown(heap, index); 
        HeapifyUp(heap, index); 
        /*PrintHeap(heap);*/
        return *(void **)to_remove;
    }
    return to_remove;
}

/********************* heap sort ***************************/
/* O(n) */
heap_t *BuildHeap(heap_cmp_func_t cmp_func, int *arr, const size_t arr_size, const void *param)
{
    size_t i = 0;
    heap_t *heap = NULL;

    assert(arr);

    heap = HeapCreate(cmp_func, param);
    for (i = 0; i < arr_size; ++i)
    {
        if (!HeapPush(heap, arr + i))
        {
            return NULL;
        }
    }

    return heap;
}

/* O(n log n) 
void HeapSort(void *base, size_t nmemb, size_t size, cmp_func_t cmp_func)
{
    size_t i = 0;
    heap_t *heap = NULL;

    assert(base);

    heap = BuildHeap(cmp_func, base, nmemb);
    for (i = 0; i < nmemb; ++i)
    {
        SwapPtrs(INDX_ADDRESS(1), INDX_ADDRESS(HeapSize(heap)));
        HeapPop(heap);
        HeapifyDown(heap, 1);
    }
}*/

/***********************************************************/
void PrintHeap(heap_t *heap)
{
    size_t i = 0;

    for (i = 1; i <= HeapSize(heap); ++i)
    {
        printf("%d -> ", **(int **) INDX_ADDRESS(i));
    }
    puts("");
}