#include <stdio.h>		
#include <stdlib.h>				/* For EXIT_SUCCESS			 */
#include <assert.h>				/*  For assert 				*/	
#include <time.h>

#include "../include/barr.h"	/* For functions definitions*/

#define NUM_OF_ROWS 8
#define NUM_OF_COLS 8
#define BOARD_SIZE (NUM_OF_ROWS * NUM_OF_COLS)

#define GET_COL(x) ((x) % NUM_OF_COLS)
#define GET_ROW(x) ((x) / NUM_OF_COLS)
#define GET_INDEX(row, col) (((row) * NUM_OF_COLS) + (col))

#define TIME_MAX 300

typedef enum {TRUE, FALSE} bool_t;

static void InitLut(void);
static void InitArr (int arr[NUM_OF_ROWS][NUM_OF_COLS]);
static void printLUT(void);
static void printSolution(int sol[NUM_OF_ROWS][NUM_OF_COLS]);
static int IsInBoard(int x, int y);
static bool_t SolveKnight(int index, int arr[NUM_OF_ROWS][NUM_OF_COLS], barr_t bar, time_t start);
static bool_t KnightRec(int index, int move_num, int arr[NUM_OF_ROWS][NUM_OF_COLS], barr_t bar, time_t start);
static int SimpleNextIndex (int index, barr_t wrong_moves);
static int WolfNextIndex (int index, barr_t wrong_moves);

static int moves_LUT[BOARD_SIZE][8] = {0};

int main ()
{	
	int arr[NUM_OF_ROWS][NUM_OF_COLS] = {0};
	int x = rand() % (NUM_OF_ROWS);
	int y = rand() % (NUM_OF_COLS);
	barr_t barr = 0;
	time_t start_time = time(NULL);
	SolveKnight(GET_INDEX(6,4), arr, barr, start_time);			/* CR: change to random x & y */

	return EXIT_SUCCESS;
}

static bool_t SolveKnight(int index, int arr[NUM_OF_ROWS][NUM_OF_COLS], barr_t bar, time_t start)  		/* CR: can find a better name for bar.. if you like*/
{
	InitLut();    											/* CR: add a check if LUT & arr are not already initialized */
	InitArr(arr);

	if (FALSE == KnightRec(index, 1, arr, bar, start))
	{
		puts("no solution!!!");
		return FALSE;
	}

	else
	{
		printSolution(arr);
		return TRUE;
	}
}

static bool_t KnightRec(int index, int move_num, int arr[NUM_OF_ROWS][NUM_OF_COLS], barr_t bar, time_t start)   /* CR: can find a better name for bar (moves visited) */
{
	int next_index = 0;
	barr_t wrong_moves = 0;

	if (time(NULL) - start >= TIME_MAX)
	{
		return FALSE;
	}

	if(BOARD_SIZE == move_num)
	{
		arr[GET_ROW(index)][GET_COL(index)] = move_num;
		return TRUE;
	}
	
	bar = BarrSetOn(bar, index);
	wrong_moves = bar;						 /* CR: add comments ...  */
	arr[GET_ROW(index)][GET_COL(index)] = move_num;

	while (-1 != (next_index = WolfNextIndex(index, wrong_moves)))
	{	
		if (TRUE == KnightRec(next_index, move_num + 1, arr, bar, start))
		{	
			return TRUE;
		}

		wrong_moves = BarrSetOn(wrong_moves, next_index);
	}	
	return FALSE;						    /* CR: not sure if needed - unmark bar & board if path fails / add a comment  */
}

static int SimpleNextIndex (int index, barr_t wrong_moves)
{
	int next_index = 0;
	int move_index = 0;

	while (-1 != (next_index = moves_LUT[index][move_index]) && move_index != 8)			/* CR: convention --> 8 != move_index */
	{						
		if (BarrIsOff(wrong_moves, next_index))
		{
			return moves_LUT[index][move_index];
		}
		move_index++;								/* CR: convention --> ++move_index */
	}

	return -1;
}

static int CountMoves (int index, barr_t wrong_moves)
{
	int next_index = 0;
	int move_index = 0;
	int counter = 0;

	while (-1 != (next_index = moves_LUT[index][move_index]) && counter != 8)			/* CR: convention --> 8 != counter */
	{
		if (BarrIsOff(wrong_moves, next_index))
		{
			counter++;							/* CR: convention --> ++counter */
		}

		move_index++;								/* CR: same... fix in other functions  */
	}

	return counter;
}

static int WolfNextIndex (int index, barr_t wrong_moves)
{
	int next_index = 0;
	int move_index = 0;
	int min_moves = 9;						/* CR: min_moves should be 8  */
	int min_index = -1;

	while (-1 != (next_index = moves_LUT[index][move_index]) && move_index != 8)		/* CR: convention --> 8 != move_index */
	{						
		if (BarrIsOff(wrong_moves, next_index))
		{
			int current_moves = CountMoves(next_index, wrong_moves);
			
			if (current_moves < min_moves)
			{
				min_index = next_index;
				min_moves = current_moves;
			}
		}
		move_index++;
	}
	return min_index;
}

static void InitLut()
{
	int i = 0;
	int j = 0;
	int counter = 0;
	int index = 0;
	int row = 0;
	int col = 0;
 
	int option_move_table[8][2] = {{1, -2}, {2, -1}, {2, 1}, {1, 2}, {-1, 2}, {-2, 1}, {-2, -1}, {-1, -2}};

	for (i = 0; i < BOARD_SIZE; i++)
	{
		for(j = 0, counter = 0; j < 8; j++)
		{	
			row = GET_ROW(i) + option_move_table[j][0];
			col = GET_COL(i) + option_move_table[j][1];

			if (IsInBoard(row, col))
			{
				index = GET_INDEX(row, col);
				moves_LUT[i][counter] = index;
				++counter;
			}
		}
		moves_LUT[i][8] = -1;

		while (counter < 8)
		{
			moves_LUT[i][counter] = -1;
			counter++;
		}
	}
}

static int IsInBoard(int x, int y)
{
	return (0 <= x && NUM_OF_ROWS > x && 0 <= y && NUM_OF_COLS > y);
}


static void InitArr(int arr[NUM_OF_ROWS][NUM_OF_COLS])
{
	int x, y = 0;

	for (x = 0; x < NUM_OF_ROWS; x++)
	{
		for (y = 0; y < NUM_OF_COLS; y++)
		{
			arr[x][y] = -1;
		}
	}
}

void printSolution(int arr[NUM_OF_ROWS][NUM_OF_COLS])		/* CR: define as static  */
{
	int x = 0;
	int y = 0;

    for (x = 0; x < NUM_OF_ROWS; x++)
    {
        for (y = 0; y < NUM_OF_COLS; y++)
	{
            printf(" %2d ", arr[x][y]);  
	}
        printf("\n");
    }
}

void printLUT()						/* CR: define as static  */
{
	int x = 0;
	int y = 0;

    for (x = 0; x < BOARD_SIZE; x++)
    {
        for (y = 0; y < 8; y++)
	{
            printf(" %4d ", moves_LUT[x][y]);
	}
        printf("\n");
    }
}
