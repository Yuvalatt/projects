#include "../include/stack.h"
#include <stdio.h>
#include <stdlib.h> /* EXIT_SUCCESS */
#include <assert.h> /* assert */
#include <string.h> /* memcpy */

struct stack
{
	size_t element_size;
	void *end;
	void *top;
	void *base;
};

/* Complexity - O(1) */
stack_t *StackCreate(size_t number_of_elements, size_t element_size)
{
	stack_t *stack = malloc(sizeof(stack_t));
	assert(number_of_elements && element_size);
	
	if (NULL == stack) 
	{
		return NULL;   
	}
	
	stack->base = malloc(number_of_elements * element_size);   /* Points to a data structure */
	if (NULL == stack->base)
	{
		free(stack);
		
		return NULL;
	}
		
	stack->top = stack->base;   /* Initialize stack */
	stack->end = (char *)stack->base + (number_of_elements * element_size); 
	stack->element_size = element_size;
	 
	return stack;
}

/* Complexity - O(1) */
void StackDestroy(stack_t *stack)
{
	assert(stack);	
	
	free(stack->base);
	free(stack);
	stack = NULL; 
}

/* Complexity - O(1) */
void StackPush(stack_t *stack, const void *data)
{
	assert(stack && data);
	assert(stack->top < stack->end);                       /* Check stack is not full */
	
	memcpy(stack->top, data, stack->element_size);          /* Inserts a copy of element to the top of stack */
	stack->top = (char *)stack->top + stack->element_size; 
}

/* Complexity - O(1) */
void StackPop(stack_t *stack)
{
	assert(stack && stack->top > stack->base);                 /* Check stack is not empty */
	
	stack->top = (char *)stack->top - stack->element_size;
}

/* Complexity - O(1) */
void *StackPeek(const stack_t *stack)
{
	assert(stack &&  stack->top > stack->base);              /* Check stack is not empty */
	
	return ((char *)stack->top - stack->element_size);   /* Returns a copy of element found on top */
}

/* Complexity - O(1) */
size_t StackSize(const stack_t *stack)
{
	assert(stack);
	
	return (((char *)stack->top - (char *)stack->base) / (stack->element_size));     /* Returns number of elements */
}
