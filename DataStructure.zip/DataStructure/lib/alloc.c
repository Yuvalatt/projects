/*************************************************************************************************************************/
static status_t AllocAddressRec(dhcp_node_t *node, barr_t barr, size_t height)  /* index - starts as Tree height */
{
	int child_side = 0;

	if (0 == height)
	{
		if (!node)
		{
			node = DHCPCreateNode(node, NULL, NULL, 0);
		}
		node->is_full = 1; /* needed ?*/ 
		/*printf("is full: %d\n", node->is_full);
		puts("success");*/
		return SUCCESS;
	}
	printf("node: %p bit:%u height: %lu \n", node, BarrIsOn(barr, height - 1), height);
	if (node->is_full)
	{
		puts("test");
		return ALLOCATION_FAILURE;
	}
	
	child_side = (1 == BarrIsOn(barr, height - 1));		
	printf("Child SIde: %d \n", child_side);
	printf("node: %p  \n\n", node->child[child_side]);

	if (!node->child[child_side])			/*  if child doesnt exist -create it   */
	{
		puts("A");
		if (!(node->child[child_side] = DHCPCreateNode(node, NULL, NULL, 0)))
		{
			puts("C");
			return ALLOCATION_FAILURE;
		}

		if (SUCCESS ==  AllocAddressRec(node->child[child_side], barr, height - 1))
		{
			node->is_full = (node->child[child_side] && node->child[!child_side]) ? 
					(node->child[child_side]->is_full && node->child[!child_side]->is_full) : 0;
			printf("is full: %d\n", node->is_full);
			return SUCCESS;
		}
		return ALLOCATION_FAILURE;
					
	}
	
	if (node->child[child_side]->is_full) 		/* if next child is full- change direction & toggle next bit */
	{
		puts("B");
		child_side = !child_side;
		barr = BarrToggleBit(barr, height - 1);
		if (SUCCESS == AllocAddressRec(node, barr, height))
		{
			node->is_full = (node->child[child_side] && node->child[!child_side]) ? 
					(node->child[child_side]->is_full && node->child[!child_side]->is_full) : 0;
			printf("is full: %d\n", node->is_full);
			return SUCCESS;
		}
		return ALLOCATION_FAILURE;
	}
	else
	{
		
	}

	return AllocAddressRec(node->child[child_side], barr, height - 1);
	
}
