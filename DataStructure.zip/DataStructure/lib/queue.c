#include "../include/queue.h"
#include "../include/slist.h"

#include <assert.h>  /* assert */

#define STUB 0xDEADBEEF

static void QueueSwap(queue_t *q1, queue_t *q2);

enum status {SUCCESS, FAIL};

struct queue
{
	slist_node_t *head;
	slist_node_t *tail;
};

/***********************  Complexity O(1)  ***********************************/
queue_t *QueueCreate(void)
{
	queue_t *queue = malloc(1 * sizeof(queue_t));
	
	if(NULL == queue)
	{
		return NULL;
	}
	
	queue->tail = SListCreateNode((void *)STUB, NULL);
	
	if (NULL == queue->tail)                      
	{
		free(queue);
		return NULL;
	}
	
	queue->head = queue->tail;

	return queue;
}

/***********************  Complexity O(N)  ***********************************/

void QueueDestroy(queue_t *queue)
{
	SListFreeAll(queue->head);
	
	queue->head = NULL;
	
	free(queue);
}
/***********************  Complexity O(N)  ***********************************/

size_t QueueSize(const queue_t *queue)
{
	assert(queue && queue->head); 

	return (SListCount(queue->head) - 1);
}

/***********************  Complexity O(1)  ***********************************/

int QueueIsEmpty(const queue_t *queue)	       /* return value empty - 1, not empty - 0 */
{
	assert(queue);

	return (queue->head == queue->tail);
}

/***********************  Complexity O(1)  ***********************************/
/* return value SUCCESS - 0, FAILURE (malloc) - 1 */

int QueueEnqueue(queue_t *queue, void *val)
{
	slist_node_t *node = SListCreateNode(val, NULL);
	
	assert(queue);

	if (NULL == node)
	{
		return FAIL;
	}	
		
	node = SListInsert(queue->tail, node);
	
	queue->tail = node->next;

	return SUCCESS;	
} 
/***********************  Complexity O(1)  ***********************************/
/* Do not perform on an empty queue */
void QueueDequeue(queue_t *queue)
{	
	slist_node_t *remove = NULL;
	
	assert(queue && (0 == QueueIsEmpty(queue)));
	
	remove = SListRemove(queue->head);	
	
	free(remove);
}

/***********************  Complexity O(1)  ***********************************/

/* Do not perform on an empty queue */
void *QueuePeek(const queue_t *queue)
{
	assert(queue && (0 == QueueIsEmpty(queue)));
	
	return (queue->head->val);
}

/***********************  Complexity O(1)  ***********************************/

queue_t *QueueAppend(queue_t *to, queue_t *from)
{
	slist_node_t *temp = NULL;
	
	if (QueueIsEmpty(to))                /* cases of empty queues */
	{
		QueueSwap(to, from);
	}
	else if (QueueIsEmpty(from))
	{
	}
	else
	{
		to->tail->next = from->head;
	
		temp = SListRemove(to->tail);			
		
		temp->next = NULL;
		
		to->tail = from->tail;
	
		from->head = temp;
		from->tail = temp;
	}
	
	return to;
}

static void QueueSwap(queue_t *q1, queue_t *q2)
{
	queue_t tmp = *q1;
	*q1 = *q2;
	*q2 = tmp;
}


