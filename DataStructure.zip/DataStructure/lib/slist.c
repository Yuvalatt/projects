#include "../include/slist.h"
#include <assert.h>  /* assert */

/***********************  Complexity O(1) - ignoring malloc() ***************************/

slist_node_t *SListCreateNode(void *val, slist_node_t *next)
{
	slist_node_t *node = (slist_node_t *)malloc(1 * sizeof(slist_node_t));
	
	assert(val); 

	if(NULL == node)
	{
		return NULL;
	}
	node->val = val; 
	node->next = next;
	
	return node;
}
/***********************  Complexity O(N)  ***********************************/

void SListFreeAll(slist_node_t *head)
{	
	slist_node_t *tmp = NULL;
	
	while (NULL != head)
	{
		tmp = head;
		head = head->next;
		free(tmp);
		tmp = NULL;
	} 
}
/***********************  Complexity O(N)  ***********************************/

size_t SListCount(const slist_node_t *head)
{
	size_t count = 0;
	
	while(NULL != head)
	{
		++count;
		head = head->next;
	}
	return count;
}
/***********************  Complexity O(1)  ***********************************/
	 																			
slist_node_t *SListInsertAfter(slist_node_t *node, slist_node_t *new_node)
{
	slist_node_t *temp = NULL;
	
	assert(node && new_node);
	
	temp = node->next;
	node->next = new_node;
	new_node->next = temp;
	
	return new_node;
}
/***********************  Complexity O(1)  ***********************************/

/* Inserts the new_node before the given node, return value: The node that was inserted */
/* switch nodes values, add new node after */
		                          
slist_node_t *SListInsert(slist_node_t *node, slist_node_t *new_node)
{
	void *tmp = NULL; 
	
	assert(node && new_node);
	
	tmp = node->val;
	node->val = new_node->val;
	new_node->val = tmp;
	
	SListInsertAfter(node, new_node);
	
	return node; 
}

/***********************  Complexity O(1)  ***********************************/

/* Removes the node after the given node, Return value: The node that was removed */
	
slist_node_t *SListRemoveAfter(slist_node_t *node)
{
	slist_node_t *next = NULL;
	
	assert(node);
								
	next = node->next;
	node->next = next->next;
	
	return next;
}

/***********************  Complexity O(1)  ***********************************/

/* Removes the given node, Return value: The node that was removed */
/* Note : can not remove the last node */

slist_node_t *SListRemove(slist_node_t *node)
{
	void *tmp = NULL;
	
	assert(node && node->next);	
	
	tmp = node->val;	
	node->val = node->next->val;
	node->next->val = tmp;
	
	return (SListRemoveAfter(node));
}															
/***********************  Complexity O(N)  ***********************************/

slist_node_t *SListFind(slist_node_t *head, cmp_func_t CmpFunc, const void *param)
{
	slist_node_t *current = head;
	
	assert(head && CmpFunc);
	
	while(NULL != current)
	{
		if (1 == CmpFunc(current->val, param))
		{
			return current;
		}
		current = current->next;
	}	
	return NULL;
}
/***********************  Complexity O(N)  ***********************************/

/*  Return value:   Aborted - 0, Continue - 1	*/

int SListForEach(slist_node_t *head, act_func_t ActFunc, void *param)
{
	slist_node_t *current = head;
	
	assert(head && ActFunc);
	
	while(NULL != current)
	{
		if( 0 ==  ActFunc(current->val, param))
		{
			return 0;	
		}
		current = current->next;
	}
	return 1;
}
/***********************  Complexity O(N)  ***********************************/

slist_node_t *SListFlip(slist_node_t *head)
{
	slist_node_t *prev = NULL;
	slist_node_t *current = head;
	slist_node_t *next = head;
	
	assert(head);
	
	while (NULL != next)
	{
		next = current->next;
		current->next = prev;
		prev = current;
		current = next;
	}

	return prev;
}
/***********************  Complexity O(N)  ***********************************/

int SListHasLoop(const slist_node_t *node)
{
	const slist_node_t *current1 = node;
	const slist_node_t *current2 = NULL;
	
	assert(node); 
	
	current2 = current1->next;

	while(NULL != current2 && NULL != current2->next)
	{
		if (current1 == current2)
		{
			return 1;
		}
		current1 = current1->next;		
		current2 = current2->next->next;
	}
	return 0;
}
/***********************  Complexity O(N)  ***********************************/

const slist_node_t *SListFindIntersection(const slist_node_t *head1, const slist_node_t *head2)
{
	size_t i = 0;	
	size_t count1 = SListCount(head1);
	size_t count2 = SListCount(head2);
	size_t count = 0;
	size_t count_remain = 0;
 	const slist_node_t *shorter = NULL;
	const slist_node_t *longer = NULL;

	assert(head1 && head2);
	
	if(count1 < count2)
	{	
		shorter = head1;
		longer = head2;
		count = count2 - count1;
		count_remain = count1; 
	}
	else
	{
		shorter = head2;
		longer = head1;
		count = count1 - count2;
		count_remain = count2;
	}
	
	for (i = 0; i < count; i++)
	{
		longer = longer->next;
	}
	
	for (i = 0; i < count_remain; i++)
	{
		if(shorter == longer)
		{
			return shorter;
		}

		longer = longer->next;
		shorter = shorter->next;
	}
	
	return NULL;
}
