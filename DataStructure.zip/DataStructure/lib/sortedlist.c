#include "../include/dlist.h"
#include "../include/sortedlist.h"

#include <assert.h>  /* assert */

struct sorted_list
{
	dlist_t *list;
	is_before_t is_before;
	void *param;
};

/***********************  Complexity O(1)  ***********************************/
sorted_list_t *SortedListCreate(is_before_t is_before, void *param)
{
	sorted_list_t *sortedlist = malloc(1 * sizeof(sorted_list_t));	
	dlist_t *list = NULL;
	
	assert(is_before);
	
	if (NULL == sortedlist)
	{
		return NULL;
	}
	
	list = DListCreate();
	
	if (NULL ==list)
	{
		free(sortedlist);
		return NULL;
	}
	sortedlist->list = list;
	sortedlist->is_before = is_before;
	sortedlist->param = param;	
	
	return sortedlist;
}

/***********************  Complexity O(N)  ***********************************/
void SortedListDestroy(sorted_list_t *list)
{
	assert(list);

	DListDestroy(list->list);
	list->list = NULL;	
	free(list);
	list = NULL;
}

/***********************  Complexity O(N)  ***********************************/
size_t SortedListSize(const sorted_list_t *list)
{
	assert(list);
	
	return (DListSize(list->list));
}

/***********************  Complexity O(1)  ***********************************/
/* Return value: True - 1, False - 0*/
int SortedListIsEmpty(const sorted_list_t *list)
{
	assert(list);
	
	return (DListIsEmpty(list->list));
}

/***********************  Complexity O(1)  ***********************************/
sorted_list_iter_t SortedListBegin(const sorted_list_t *list)
{
	assert(list);
	
	return (DListBegin(list->list));
}

/***********************  Complexity O(1)  ***********************************/
sorted_list_iter_t SortedListEnd(const sorted_list_t *list)
{
	assert(list);
	
	return (DListEnd(list->list));
}

/***********************  Complexity O(1)  ***********************************/
sorted_list_iter_t SortedListNext(const sorted_list_iter_t iter)
{
	assert(iter);

	return (DListNext(iter));
}

/***********************  Complexity O(1)  ***********************************/
sorted_list_iter_t SortedListPrev(const sorted_list_iter_t iter)
{
	assert(iter);

	return (DListPrev(iter));
}

/***********************  Complexity O(1)  ***********************************/
void *SortedListGetData(const sorted_list_iter_t iter)
{
	assert(iter);

	return (DListGetData(iter));
}

/***********************  Complexity O(1)  ***********************************/
/* Return value: True - 1, False - 0*/
int SortedListIsSameIter(const sorted_list_iter_t iter1, const sorted_list_iter_t iter2)
{
	assert(iter1 && iter2);
	
	return (DListIsSameIter(iter1, iter2));
}

/***********************  Complexity O(N)  ***********************************/
/* Inserts the value to the sorted list.
 * Return value: iterator to the value inserted, END iterator on failure */	
sorted_list_iter_t SortedListInsert(sorted_list_t *list,  void *data)
{
	
	dlist_iter_t iter = NULL;
	
	assert(list && list->is_before);

	iter = SortedListBegin(list);
	
	while (!SortedListIsSameIter(iter, SortedListEnd(list)))
	{
		if (0 == list->is_before(SortedListGetData(iter), data, list->param))
		{
			break;		
		}
		iter = SortedListNext(iter);
	}	
	return (DListInsert(list->list, iter, data));
	
}
/***********************  Complexity O(1)  ***********************************/
/* 	 Removes the given iterator
 *  Return value: iterator of the next item (after the removed item) */

sorted_list_iter_t SortedListErase(sorted_list_iter_t iter)
{
	assert(iter);

	return DListErase(iter);
}

/***********************  Complexity O(1)  ***********************************/
void *SortedListPopFront(sorted_list_t *list)
{
	void *data = NULL;
	assert(list);
	
	data = SortedListGetData(SortedListBegin(list));

	DListErase(SortedListBegin(list));

	return data;
}

/***********************  Complexity O(1)  ***********************************/
void *SortedListPopBack(sorted_list_t *list)
{
	void *data = NULL;
	assert(list);
	
	data = SortedListGetData(SortedListPrev(SortedListEnd(list)));
	DListErase(SortedListPrev(SortedListEnd(list)));

	return data;
}

/***********************  Complexity O(N)  ***********************************/
sorted_list_iter_t SortedListFind(const sorted_list_t *list, const sorted_list_iter_t from, const sorted_list_iter_t to, sl_cmp_func_t CmpFunc, void *param)
{
	dlist_iter_t iter = from;	
	
	assert(list->list && from && to && CmpFunc);

	while(!SortedListIsSameIter(iter, to))
	{
		if (1 == CmpFunc(DListGetData(iter), param))
		{
			return iter;
		}
		iter = DListNext(iter);
	}	
	return DListEnd(list->list);
}

/***********************  Complexity O(N)  ***********************************/
/* Return value: Aborted - 0, Continue - 1	*/
int SortedListForEach(sorted_list_iter_t from, sorted_list_iter_t to, sl_act_func_t ActFunc, void *param)
{
	dlist_iter_t iter = from;
	
	assert(from && to && ActFunc);
	
	while (!SortedListIsSameIter(iter, to))
	{
		if( 0 ==  ActFunc(DListGetData(iter), param))
		{
			return 0;	
		}
		iter = DListNext(iter);
	}
	return 1;
}

/***********************  Complexity O(N)  ***********************************/ 
void SortedListMerge(sorted_list_t *to, sorted_list_t *from)
{
	assert(to && from && (to->is_before == from->is_before));
	/* Case 1: If the entire to list is before from list - splice from after to*/
	if (to->is_before(SortedListGetData(SortedListPrev(SortedListEnd(to))), SortedListGetData(SortedListBegin(from)), NULL)) 
	{
		DListSpliceBefore(SortedListEnd(to), SortedListBegin(from), SortedListEnd(from));
	}
	/* Case 2: If the entire from list is before to list - splice from before to*/
	else if (to->is_before(SortedListGetData(SortedListPrev(SortedListEnd(from))), SortedListGetData(SortedListBegin(to)), NULL))
	{
		DListSpliceBefore(SortedListBegin(to), SortedListBegin(from), SortedListEnd(from));
	}
	/* Case 3: If lists are overlapping - splice single iterators from from list into to list */
	else
	{
		dlist_iter_t to_iter = SortedListBegin(to);		
		dlist_iter_t from_iter = SortedListBegin(from);
		
		while (!SortedListIsSameIter(to_iter, SortedListEnd(to)) && !SortedListIsSameIter(from_iter, SortedListEnd(from)))
		{
			if(to->is_before(SortedListGetData(to_iter), SortedListGetData(from_iter), NULL))
			{
				to_iter = SortedListNext(to_iter);     /* if to data is before from data - promote to_iter  */
			}
			else
			{
				DListSpliceBefore(to_iter, from_iter, SortedListNext(from_iter));   /* if from data is before to data - splice a single iterator from from  */
				from_iter = SortedListBegin(from);
			}
		}
		if (!SortedListIsSameIter(from_iter, SortedListEnd(from)))      /* If needed - Splice the rest of from list after to  */
		{	
			DListSpliceBefore(SortedListEnd(to), SortedListBegin(from), SortedListEnd(from));
		}
	}	
}

