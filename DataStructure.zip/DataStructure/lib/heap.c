#include <assert.h>    			 /*    assert        */
#include <stdio.h>     			 /*   Print Heap     */

#include "../include/heap.h"
#include "../include/dynvec.h"

#define UNUSED(x)(void)(x)
#define DUMMY 0xDEADBEEF

#define ROOT_INDEX 1
#define PARENT(i)(i / 2)
#define LEFT_CHILD(i)(2 * i)
#define RIGHT_CHILD(i)((2 * i) + 1)
#define VEC_DATA(i)(*(void **)(DVGetItemAddress(heap->dynvec, i)))

struct heap
{
	dv_t *dynvec;
	heap_cmp_func_t cmp_func;
	const void *param;
};

static void HeapifyUp(heap_t *heap, size_t i);
static void HeapifyDown(heap_t *heap, size_t i);
static void Swap(void **data1, void **data2);

/***************************** Complexity - O(1) ***********************************************/
heap_t *HeapCreate(heap_cmp_func_t cmp_func, const void *param)
{
	dv_t *dynvec = NULL;
	heap_t *heap = NULL;
	void *stub_val = (void *)DUMMY;
	
	assert(cmp_func);

	heap = (heap_t *)malloc(1 * sizeof(heap_t));
	if (!heap)
	{
		return NULL;
	}

	dynvec = DVCreate(0, sizeof(void *));
	if (!dynvec)
	{
		free(heap);
		return NULL;
	}
	
	heap->dynvec = dynvec;
	
	DVPushBack(heap->dynvec, &stub_val); 	/* Initialize first element with a DUMMY value*/
	heap->cmp_func = cmp_func;
	heap->param = param;

	return heap;
}

/***************************** Complexity - O(1) ***********************************************/
void HeapDestroy(heap_t *heap)
{
	assert(heap);

	DVDestroy(heap->dynvec);

	heap->dynvec = NULL;

	free(heap);
}

/***************************** Complexity - O(log n) ***********************************************/
heap_stat_t HeapPush(heap_t *heap, void *data)
{
	assert(heap && data);

	if (1 == DVPushBack(heap->dynvec, &data))
	{
		return HEAP_MALLOC_FAILURE;
	}

	HeapifyUp(heap, HeapSize(heap));

	return HEAP_SUCCESS;
}

/***************************** Complexity - O(log n) ***********************************************/
static void HeapifyUp(heap_t *heap, size_t i)
{
	if (i <= ROOT_INDEX)	
	{
		return;
	}

	if (0 < heap->cmp_func(VEC_DATA(i), VEC_DATA(PARENT(i)), NULL))
	{
		Swap(DVGetItemAddress(heap->dynvec, PARENT(i)), DVGetItemAddress(heap->dynvec, i));
				
		HeapifyUp(heap, PARENT(i));
	}
}

/***************************** Complexity - O(1) ***********************************************/
/*				 Remove & return data of root element - MAX / MIN  	       */
void *HeapPop(heap_t *heap) 			
{
	void *removed_data = NULL;

	assert(heap);
	
	Swap(DVGetItemAddress(heap->dynvec, ROOT_INDEX), DVGetItemAddress(heap->dynvec, HeapSize(heap)));
	
	removed_data = DVGetItemAddress(heap->dynvec, HeapSize(heap));
	
	DVPopBack(heap->dynvec);
	
	HeapifyDown(heap, ROOT_INDEX);
	
	return *(void **)removed_data;
}

/***************************** Complexity - O(log n) ***********************************************/
static void HeapifyDown(heap_t *heap, size_t i)
{
	size_t min_child = i;
	
	if (LEFT_CHILD(i) <= HeapSize(heap) && 0 < heap->cmp_func(VEC_DATA(LEFT_CHILD(i)), VEC_DATA(i), NULL))
	{
		min_child = LEFT_CHILD(i);
	}
	
	if (RIGHT_CHILD(i) <=  HeapSize(heap) && 0 < heap->cmp_func(VEC_DATA(RIGHT_CHILD(i)), VEC_DATA(min_child), NULL))
    	{
       		min_child = RIGHT_CHILD(i);
 	}
 	
 	if (min_child != i)
 	{
		Swap(DVGetItemAddress(heap->dynvec, min_child), DVGetItemAddress(heap->dynvec, i));		
		HeapifyDown(heap, min_child);
	}	
}

/***************************** Complexity - O(1) ***********************************************/
/*				   Returns data of root element - MAX / MIN  		       */
void *HeapPeek(const heap_t *heap)
{
	assert(heap);

	return VEC_DATA(ROOT_INDEX);
}

/***************************** Complexity - O(1) ***********************************************/
size_t HeapSize(const heap_t *heap)
{
	assert(heap);

	return (DVSize(heap->dynvec) - 1);
}

/***************************** Complexity - O(1) ***********************************************/
int HeapIsEmpty(const heap_t *heap)
{
	assert(heap);
	
	return (1 == DVSize(heap->dynvec));
}

/***************************** Complexity - O(n) ***********************************************/
void *HeapRemove(heap_t *heap, heap_find_t find_func, void *data_to_remove, void *param)
{
	void *data_removed = NULL;
	size_t i = 0;
	UNUSED(param);
	assert(heap && find_func && data_to_remove);

	for (i = ROOT_INDEX; i <= HeapSize(heap); i++)
	{
		if (find_func(VEC_DATA(i), data_to_remove))
		{
			data_removed = VEC_DATA(i);
			break;
		}
	}

	if (i > HeapSize(heap)) /* data not found*/
   	{
    		return NULL;
   	}   

  	Swap(DVGetItemAddress(heap->dynvec, i), DVGetItemAddress(heap->dynvec, HeapSize(heap)));
	DVPopBack(heap->dynvec);

	if (HeapSize(heap) > 1 && i <= HeapSize(heap)) 
	{	
		HeapifyDown(heap, i);
		HeapifyUp(heap, i);
	}

	return data_removed;
}

/***************************** Complexity - O(1) ***********************************************/
static void Swap(void **data1, void **data2)
{
	void *temp = *data1;
	*data1 = *data2;
	*data2 = temp;
}

/***************************** Complexity - O(n) ***********************************************/
void PrintHeap(heap_t *heap)
{
	size_t i = 0;
	
	for (i = ROOT_INDEX; i <= HeapSize(heap); ++i)
	{
		printf("%d ", *(int *)(VEC_DATA(i)));
	}
	puts("");
}

