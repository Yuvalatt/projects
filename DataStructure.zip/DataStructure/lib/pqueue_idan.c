#include "../include/pqueue.h"
#include "../include/heap.h"
#include "../include/dynvec.h"

#include <assert.h>

#define UNUSED(x) ((void) (x))

struct heap
{
    dv_t *vec;
    heap_cmp_func_t cmp_func;
    const void *param;
};

struct pqueue
{
	heap_t *heap;
};

/***********************************************************/
pq_t *PQCreate(pq_is_before_t is_before, void *param)
{
    heap_t *heap = NULL;
    pq_t *pqueue = NULL;
    
    assert(is_before);
    
    pqueue = malloc(sizeof(pq_t));
    if (!pqueue)
    {
        return NULL;
    }

    pqueue->heap = HeapCreate((heap_cmp_func_t)is_before, param);
    if (!pqueue->heap)
    {
        free(pqueue);
        return NULL;
    }

    return pqueue;
}

void PQDestroy(pq_t *pqueue)
{
    assert(pqueue);
    HeapDestroy(pqueue->heap);
    free(pqueue);
    pqueue =NULL;
}

size_t PQSize(const pq_t *pqueue)
{
    assert(pqueue);
    return HeapSize(pqueue->heap);
}

int PQIsEmpty(const pq_t *pqueue)		 	/* return value empty - 1, not empty - 0 */
{
    assert(pqueue);
    return HeapIsEmpty(pqueue->heap);
}

int PQEnqueue(pq_t *pqueue, void *data) 	/*   SUCCESS - 0, FAILURE (malloc) - 1 	 */
{
    assert(pqueue);
    return HeapPush(pqueue->heap, data);
}

void *PQDequeue(pq_t *pqueue)			 	
{
    assert(pqueue);
    return HeapPop(pqueue->heap);
}

void *PQPeek(const pq_t *pqueue) 			
{
    assert(pqueue);
    return HeapPeek(pqueue->heap);
}

void *PQErase(pq_t *pqueue, pq_cmp_func_t CmpFunc, void *param)
{
    assert(pqueue && CmpFunc && param);

    return HeapRemove(pqueue->heap, (heap_find_t)CmpFunc, param, NULL);
}
/********************************************************************************
struct erase_parameters
{
    pq_cmp_func_t CmpFunc;
    const void *param;
};

static int FindAndErase(const void *data1, const void *param, const void *params_to_use)
{
	struct erase_parameters *args = (struct erase_parameters *) params_to_use;
    assert(param);
	return args->CmpFunc(data1, (void *)args->param);
}

void *PQErase(pq_t *pqueue, pq_cmp_func_t CmpFunc, void *param)
{     
    struct erase_parameters params_to_use = {0};

    assert(pqueue);

    params_to_use.CmpFunc = CmpFunc;
    params_to_use.param = param;
    
    return HeapRemove(pqueue->heap, FindAndErase, &params_to_use, NULL);
}
/********************************************************************************/

void PQClearAll(pq_t *pqueue)
{
    assert(pqueue);
	
	while (!PQIsEmpty(pqueue))
	{
		PQDequeue(pqueue);
	}
}