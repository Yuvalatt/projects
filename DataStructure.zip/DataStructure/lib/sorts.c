#include  "../include/sorts.h"
#include <assert.h> /* assert */
#include <string.h> /* memcpy */
#include <sys/types.h> /* ssize_t */

#define LEFT_CHILD(i)((2 * i) + 1)
#define RIGHT_CHILD(i)((2 * i) + 2)

typedef struct element
{
	size_t key;
	void *el_ptr;
} element_t;

static void InitStructArray(element_t *base2, void *base, size_t num_of_elements, size_t el_size, el_to_key_t key_func, const void *args);
static size_t ByteByByte(const void *element, const void *args); /* Returns a byte of number as a key */
static void ElementToKey(element_t *dest2, void *dest, size_t num_of_elements, size_t el_size);

static void RecMergeSort(void *arr, void *base, int start, int end, size_t size, cmp_func_t cmp_func);
static void Merge(void *arr, void *base, int start, int mid, int end, size_t size, cmp_func_t cmp_func);
static void *BinarySearchRec(const void *base, size_t l, size_t r, size_t size, const void *data_to_find, cmp_func_t cmp_func);

void Swap(void *a, void *b, size_t width)
{
    void *temp = malloc(width);
	if (a != b)
	{
  	    memcpy(temp, b, width);
    	memcpy(b, a, width);
    	memcpy(a, temp, width);
	}    
	free(temp);
}

/* While not sorted: run for loops, check each pair of elements (using cmp func), swap elements if needed */
void BubbleSort(void *base, size_t nmemb, size_t size, cmp_func_t cmp_func)
{
    size_t i = 0;
    size_t j = 0;

    for (i = 0; i < nmemb; i++)
    {
        for (j = 0; j < nmemb - i - 1; j++)
        {
            if (0 == cmp_func(((char *)base + (j + 1) * size), ((char *)base + j * size)))
            {
                Swap(((char *)base + (j + 1) * size), ((char *)base + j * size), size);
            }
        }
    }
}

/* Find the first unsorted element (left side), insert in right place in sorted part (right side)  */
void InsertionSort(void *base, size_t nmemb, size_t size, cmp_func_t cmp_func)
{
	ssize_t j = 0;
    size_t i = 0;
   
    void *temp = 0;
	
	temp = malloc(1 * size);
	if (NULL == temp)
	{
		exit(EXIT_FAILURE);
	}
	
	for (i = 1; i < nmemb; i++)
    {	
    	memcpy(temp, (char *)base + i * size, size);
    	
    	j = i - 1; 
    	
    	while (j >= 0 && 1 == cmp_func((char *)base + j * size, temp))
    	{
    		j--;
    	}
    	
    	if (j != (ssize_t)(i - 1))
    	{
    		memmove((char *)base + (j + 2) * size, (char *)base + (j + 1) * size, (i - (j + 1)) * size);
		memcpy((char *)base + (j + 1) * size, temp, size);
    	}
	}	
	free(temp);
}

/* Find minimum element, insert in sorted part (right side) */
void SelectionSort(void *base, size_t nmemb, size_t size, cmp_func_t cmp_func)
{
    size_t j = 0;
    size_t i = 0;
    void *min_val = 0;

    for (i = 0; i < nmemb - 1; i++)
    {
    	min_val = ((char *)base + i * size);
    	
        for (j = i + 1; j < nmemb; j++)
        {
            if (0 == cmp_func((char *)base + j * size, min_val))
            {
               min_val = ((char *)base + j * size);
            }
        } 

       Swap(min_val, ((char *)base + i * size), size);
    }  
}

void CountingSort(void *base, size_t members_num, size_t element_size, el_to_key_idx_t key_func, const void *args, size_t range)
{
		void *dest = NULL;
		size_t *histogram = NULL;

		assert(base && members_num && element_size && key_func && range);

		dest = malloc(members_num * element_size);
		histogram = calloc(range, sizeof(size_t));
	
		CountingSortEx(base, dest, members_num, element_size, key_func, args, range, histogram);
	
		memcpy(base, dest, members_num * element_size);

		free(dest);
		free(histogram);
}

void CountingSortEx(const void *src, void *dest, size_t members_num, size_t element_size, el_to_key_idx_t key_func, const void *args, size_t range, size_t histogram[])
{
	ssize_t i = 0;
	size_t key = 0;
	size_t dest_index = 0;

	assert(src && dest && members_num && element_size && key_func && range && histogram);

	for (i = 0; i < members_num; i++)
	{
		 key = key_func(((char *)src + i * element_size), args);
		 ++histogram[key];
	} 
	
	for (i = 1; i < range; i++)
	{
		histogram[i] += histogram[i - 1];
	}

	for (i = members_num - 1; i >= 0; i--)
	{
		key = key_func(((char *)src + i * element_size), args);
		
		dest_index = histogram[key] - 1;		
		
		memcpy(((char *)dest +  dest_index * element_size), (char *)src + i * element_size, element_size);
		
		--histogram[key];
	}
}

void RadixSort(void *base, size_t num_of_elements, size_t el_size, el_to_key_t key_func, const void *args, size_t num_of_bytes)
{
	void *dest = NULL;
	size_t *histogram = NULL;
	size_t i = 0;

	element_t *base2 = NULL;
	void *dest2 = NULL;

	assert(base && num_of_elements && el_size && key_func && num_of_bytes);
	
	base2 = malloc(num_of_elements * sizeof(element_t));
	if (NULL == base2)
	{
		exit(EXIT_FAILURE);
	}
	
	dest2 = malloc(num_of_elements * sizeof(element_t));
	if (NULL == dest2)
	{
		free(base2);
		exit(EXIT_FAILURE);
	}

	dest = malloc(num_of_elements * el_size);
	if (NULL == dest)
	{
		free(base2);
		free(dest2);
		exit(EXIT_FAILURE);
	}

	InitStructArray(base2, base, num_of_elements, el_size, key_func, args); 
		
	histogram = calloc(256, sizeof(size_t));
	if (NULL == histogram)
	{
		free(base2);
		free(dest2);
		free(dest);
		exit(EXIT_FAILURE);
	}
	
	for (i = 0; i < num_of_bytes; i++)
	{	
		memset(histogram, 0, sizeof(size_t) * 256);	
		CountingSortEx(base2, dest2, num_of_elements, sizeof(element_t), ByteByByte, &i, 256, histogram);
		memcpy(base2, dest2, num_of_elements * sizeof(element_t));
	}

	ElementToKey(dest2, dest, num_of_elements, el_size);
	memcpy(base, dest, num_of_elements * el_size);

	free(base2);
	free(dest);
	free(histogram);
}

/* TEST FUNCTION */
void TestRadixSort(void *base, size_t num_of_elements, size_t el_size, el_to_key_t key_func, const void *args, size_t num_of_bytes)
{
	size_t i = 0;
	
	assert(base && num_of_elements && el_size && key_func && num_of_bytes);

	for (i = 0; i < num_of_bytes; i++)
	{	
		CountingSort(base, num_of_elements, el_size, key_func, &i, 256); 
	}
}

static void InitStructArray(element_t *base2, void *base, size_t num_of_elements, size_t el_size, el_to_key_t key_func, const void *args)
{
	size_t i = 0;

	for (i = 0; i < num_of_elements; i++)
	{
		base2[i].key = key_func(((char *)base + i * el_size), args);
		base2[i].el_ptr = ((char *)base + i * el_size);
	}
}

static size_t ByteByByte(const void *element, const void *args) /* Returns relevent byte */ 
{			
	element_t *el = (element_t *)element;
	
	size_t num = el->key;
	int i = *(int *)args;

	assert(element);
	
	return ((num >> (i * 8)) & 0xff);
}

static void ElementToKey(element_t *dest2, void *dest, size_t num_of_elements, size_t el_size)
{
	size_t i = 0;
	element_t *el = NULL;	

	for (i = 0; i < num_of_elements; i++)
	{	
		el = dest2 + i;
		memcpy((char *)dest +  i * el_size,  el->el_ptr , el_size);
	}

}

void MergeSort(void *base, size_t nmemb, size_t size, cmp_func_t cmp_func)
{
	void *arr = malloc(nmemb * size);

	if (NULL != arr)
	{
		RecMergeSort(arr, base, 0, nmemb - 1, size, cmp_func);
	
		free(arr);
	}
}

static void RecMergeSort(void *arr, void *base, int start, int end, size_t size, cmp_func_t cmp_func)
 {
 	int middle = 0;

 	if (start >= end)
 	{
		return;
	}

 	middle = start + (end - start) / 2; 

 	RecMergeSort(arr, base, start, middle, size, cmp_func);
 	RecMergeSort(arr, base, middle + 1, end, size, cmp_func);
 		
 	Merge(arr, base, start, middle, end, size, cmp_func);
 	
 }

static void Merge(void *arr, void *base, int start, int mid, int end, size_t size, cmp_func_t cmp_func)
{
    int i = 0;
    int j = 0;
    int k = start;
    
    int size1 = (mid - start) + 1;
    int size2 =  end - mid;
 	 
    memcpy((char *)arr, (char *)base + start * size, size1 * size);
    memcpy((char *)arr + size1 * size, (char *)base + (mid + 1) * size, size2 * size);
	
    while (i < size1 && j < size2)
    {
        if (0 < cmp_func((char *)arr + (j + size1) * size, (char *)arr + (i * size)))
        {	
            memcpy((char *)base + k * size, (char *)arr + i * size, size);
            ++i;
        }
        else
        {
            memcpy((char *)base + k * size, (char *)arr + (j + size1) * size, size);
            ++j;
        }
        ++k;
    }

    memcpy((char *)base + k * size, (char *)arr + i * size, (size1 - i) * size);
    memcpy((char *)base + (k + (size1 - i)) * size, (char *)arr + (j + size1) * size, (size2 - j) * size);
}

/***************************** Complexity - O(log n) ***********************************************/
static void HeapifyDown(void *base, int i, size_t size, cmp_func_t cmp_func, size_t nmemb)
{
	size_t min_child = i;
	
	if (LEFT_CHILD(i) < nmemb && 0 < cmp_func((char *)base + size * (LEFT_CHILD(i)), (char *)base + size * i))
	{
		min_child = LEFT_CHILD(i);
	}
	
	if (RIGHT_CHILD(i) <  nmemb && 0 < cmp_func((char *)base + size * (RIGHT_CHILD(i)), (char *)base + size * (min_child)))
   	 {
      		  min_child = RIGHT_CHILD(i);
 	}
 	
 	if (min_child != i)
 	{
		Swap((char *)base + size * (min_child), (char *)base + size * i, size);

		HeapifyDown(base, min_child, size, cmp_func, nmemb);
	}
}

/***************************** Complexity - O(n) ***********************************************/
static void BuildHeap(void *base, size_t nmemb, size_t size, cmp_func_t cmp_func)
{
	int i = 0;

	for (i = ((int)nmemb / 2) - 1; i >= 0; --i)
	{
		HeapifyDown(base, i, size, cmp_func, nmemb);
	}
}

/***************************** Complexity - O(nlog n) ***********************************************/
void HeapSort(void *base, size_t nmemb, size_t size, cmp_func_t cmp_func)
{
	int i = 0;
	BuildHeap((char *)base, nmemb, size, cmp_func);

	for (i = nmemb - 1; i >= 1 ; --i)
	{
		Swap((char *)base, (char *)base + i * size, size);
		--nmemb;
		HeapifyDown(base, 0, size, cmp_func, nmemb);
	}
}

static int Partition(void *base, int start, int end, size_t size, cmp_func_t cmp_func)
{
	void *pivot = NULL;
	int i = start - 1;	
	int j = start;

	pivot = (char *)base + end * size;

	for (j = start; j <= end - 1; j++)
	{
		if (0 < cmp_func(pivot, (char *)base + size * j))
		{
			i++;
			if (i != j)
			{
				Swap((char *)base + size * i, (char *)base + size * j, size);
			}		
		}
	}

	if (i != j)
	{
		Swap(pivot, (char *)base + size * (i + 1), size);
	}	
	return i + 1;
}

static void QuickSortRecursive(void *base, int p, int r, size_t size, cmp_func_t cmp_func)
{	
	if (p < r)
	{	
		int q = Partition(base, p, r, size, cmp_func);
		QuickSortRecursive(base, p, q - 1, size, cmp_func);
		QuickSortRecursive(base, q + 1, r, size, cmp_func);
	}
}

void QuickSort(void *base, size_t nmemb, size_t size, cmp_func_t cmp_func)
{	
	assert(base && nmemb && size && cmp_func);
	QuickSortRecursive(base, 0, nmemb - 1, size, cmp_func);
}

/***************************** Complexity - O(log n) ***********************************************/
void *BinarySearch(const void *base, size_t nmemb, size_t size, const void *data_to_find, cmp_func_t cmp_func)
{
	return BinarySearchRec(base, 0, nmemb - 1, size, data_to_find, cmp_func);
}

void *BinarySearchRec(const void *base, size_t l, size_t r, size_t size, const void *data_to_find, cmp_func_t cmp_func)
{	
	if (l <= r)
	{
		size_t mid = (l + r) / 2;
		int cmp_val = cmp_func((char *)base + mid * size, data_to_find);

		if (0 == cmp_val)
		{
			return ((char *)base + mid * size);
		}
		
		if (0 < cmp_val)
		{
			return BinarySearchRec(base, l, mid - 1, size, data_to_find, cmp_func);
		}
	
		return BinarySearchRec(base, mid + 1, r, size, data_to_find, cmp_func);	
	}
	return NULL;
}
