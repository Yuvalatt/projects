#include "../include/dynvec.h"
#include <stdio.h>
#include <stdlib.h> /* EXIT_SUCCESS */
#include <assert.h> /* assert */
#include <string.h> /* memcpy */

#define DEFAULT_VEC_SIZE 50

enum status {SUCCESS = 0, FAIL = 1};

struct dyn_vec
{
	size_t element_size;
	size_t capacity;
	size_t size;
	void *start;
};

/***************************** Complexity - O(1) ***********************************************/

dv_t *DVCreate(size_t number_of_elements, size_t element_size)
{
	dv_t *dynvec = (dv_t *)malloc(sizeof(dv_t) * 1);
	size_t def_size = ((0 == number_of_elements) ? DEFAULT_VEC_SIZE :  number_of_elements);  /* Default capacity */
	
	assert(element_size);
	
	if (NULL == dynvec)
	{
		return NULL;
	}

	dynvec->start = malloc(def_size * element_size); /* Points to structure of data */
	if (NULL == dynvec->start)
	{
		free(dynvec);
		return NULL;
	}	
	
	dynvec->element_size = element_size;
	dynvec->size = number_of_elements;
	dynvec->capacity = def_size; 
	
	return dynvec;
}
/***************************** Complexity - O(1) ***********************************************/

void DVDestroy(dv_t *dyn_vec)
{
	assert(dyn_vec);
	
	free(dyn_vec->start);
	free(dyn_vec);
	dyn_vec = NULL;
}
/***************************** Complexity - O(1) ***********************************************/

size_t DVSize(const dv_t *dyn_vec)
{
	assert(dyn_vec);
	
	return (dyn_vec->size); 
}
/***************************** Complexity - O(1) ***********************************************/

size_t DVCapacity(const dv_t *dyn_vec) 
{
	assert(dyn_vec);
	
	return (dyn_vec->capacity);
}
/***************************** Complexity - O(1) ***********************************************/

int DVPushBack(dv_t *dyn_vec, const void *data)
{
	int check = 0;
	void *current =NULL;
	
	assert(dyn_vec && data);
	
	if(dyn_vec->capacity == dyn_vec->size)
	{
		check = DVReserve(dyn_vec, 2 * dyn_vec->capacity);
		
		if (FAIL == check)
		{
			return FAIL;
		}
	}
	
	current = (char *)dyn_vec->start + (dyn_vec->size * dyn_vec-> element_size);
	memcpy(current, data, dyn_vec-> element_size);
	
	++dyn_vec->size;
	
	return SUCCESS; 
}
/***************************** Complexity - O(1) ***********************************************/

int DVReserve(dv_t *dyn_vec, size_t min_capacity)
{
	void *temp = NULL;
	assert(dyn_vec && min_capacity > 0);
	
	if (min_capacity > dyn_vec->capacity)
	{
		temp = realloc(dyn_vec->start, min_capacity * dyn_vec->element_size);
		
		if (NULL == temp)
		{
			return FAIL; 
		}
		else
		{
			dyn_vec->start = temp;
			dyn_vec->capacity = min_capacity;
		}
	}
	
	return SUCCESS; 
}
/***************************** Complexity - O(1) ***********************************************/

void DVPopBack(dv_t *dyn_vec)
{
	assert(dyn_vec && 0 < dyn_vec->size);
	
	--dyn_vec->size;	
}

/***************************** Complexity - O(1) ***********************************************/

void *DVGetItemAddress(const dv_t *dyn_vec, size_t index)
{
	/*assert(index < dyn_vec->size);*/
	
	return ((char *)dyn_vec->start + (index * dyn_vec-> element_size));
}
