#include "../include/slist.h"
#include "../include/stack.h"

#include <string.h>   /* strlen */

/* Iterative Fibonacci */
unsigned int IFibonacci(int n)
{
	unsigned int a1 = 0;
	unsigned int a2 = 1;
	unsigned int fib = 0;

	while (n >= 2)
	{
		fib = a2 + a1;
		a1 = a2;
		a2 = fib;
		--n;
	}
	return fib;
}

/* Recursive Fibonacci */
/*unsigned long RFibonacci(int n)
{
	if (2 <= n)
	{
		return 1;
	}	
	return RFibonacci(n - 1) + RFibonacci(n - 2); 
}
*/

/* More efficient solution */
unsigned long FibonacciImp(int n, unsigned long a1, unsigned long a2)
{	
	if (1 == n)
	{
		return 1;
	}
	else if (0 == n)
	{
		return 0;
	}

	return a1 + FibonacciImp(n - 1, a2, a1 + a2);
}

unsigned long RFibonacci(int n)
{	
	return FibonacciImp(n, 0, 1);
}

/* Recursive String funcs */
size_t Strlen(const char *s)
{
	if ('\0' == *s)
	{
		return 0;
	}

	return 1 + Strlen(++s);
}

int Strcmp(const char *s1, const char *s2)
{
	if ('\0' == *s1 || '\0' == *s2)
	{
		return ((*s1 == *s2) ? 0 : ((*s1 > *s2) ? -1 : 1));
	}
	
	return Strcmp(++s1, ++s2);
}

char *Strcpy(char *dest, const char *src)
{
		if ('\0' == *src)
		{
			*dest = '\0';
			return dest;
		}
		
		*dest = *src;
		return Strcpy(++dest, ++src);
}

char *Strcat(char *dest, const char *src)
{
		if ('\0' == *src)
		{
			*(dest + strlen(dest)) = '\0';
			return dest;
		}
		
		*(dest + strlen(dest)) = *src;
		return Strcat(dest, ++src);
}


/* OPTION 2- call strlen 1 time only */
/* char *StrConcat(char *dest, const char *src, size_t i)
{
		if ('\0' == *src)
		{
			*(dest + i) = '\0';
			return dest;
		}
		
		*(dest + i) = *src;
		StrConcat(dest, ++src, ++i);
}

char *Strcat(char *dest, const char *src)
{
	return StrConcat(dest, src, strlen(dest));
} */

char *StrstrImp(char *haystack, char *needle, size_t size)
{
	if ('\0' == *haystack)
	{
		return ('\0' == *needle) ? (haystack - size) : NULL;	
	}	

	if (*haystack == *needle)
	{
		++size;
		++needle;
	}
	else
	{
		needle -= size;
		size = 0;	
	}

	return StrstrImp(++haystack, needle, size);
}


char *Strstr(const char *haystack, const char *needle)
{
	return StrstrImp((char *)haystack, (char *)needle, 0);
}

slist_node_t *FlipList(slist_node_t *head)
{    
	slist_node_t *new_head;

 	if(NULL == head || NULL == head->next)
	{
		return head;
	}
	
	new_head = FlipList(head->next);

	head->next->next = head;

	head->next = NULL;

	return new_head;
}

void Hanoi(int n, int a, int b)
{
	if (0 == n)
	{
		return;
	}
	
	Hanoi(n - 1, a, 6 - a - b);

	printf("Solving Hanoi with %d rings problem from %d to %d\n", n, a, b);
		
	printf("===== Move 1 ring from %d to %d\n", a, b);	

	Hanoi(n - 1, 6 - a - b, b);			
}

void SortedStackInsert(stack_t *stack, int data)
{	
	int value = 0; 

	if (0 == StackSize(stack) || *(int *)StackPeek(stack) < data)
	{
		StackPush(stack, &data);

		return;
	}
	
	value = *(int *)StackPeek(stack);

	StackPop(stack);

	SortedStackInsert(stack, data);	

	StackPush(stack, &value);	
}

void RecursiveStackSort(stack_t *stack)
{
	int data = 0; 

	if (0 == StackSize(stack))
	{
		return;
	}
	
	data = *(int *)StackPeek(stack);

	StackPop(stack);

	RecursiveStackSort(stack);

	SortedStackInsert(stack, data);
}


