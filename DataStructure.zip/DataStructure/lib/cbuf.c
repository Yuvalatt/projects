#include "../include/cbuf.h"
#include <stdio.h> 
#include <assert.h>  /* assert */
#include <stdlib.h>  /* EXIT_SUCCESS */
#include <string.h>  /* memcpy */

#define MIN(a, b)(a < b ? a : b) 

status_t g_cbuf_errno = SUCCESS;

struct cbuf
{
	size_t count_written;
	char *read_ptr;
	char *start;
	char *end;
}; 

/************************** Complexity O(1) ****************************/
c_buf_t *CBufCreate(size_t n_of_bytes)
{
	c_buf_t *cbuf = (c_buf_t *)malloc(1 * sizeof(c_buf_t));
	assert(n_of_bytes > 0);
	
	if (NULL == cbuf)
	{
		return NULL;
	}
	
	cbuf->start = malloc(n_of_bytes * sizeof(char)); /* sizeof(*cbuf->start) */
	if (NULL == cbuf->start)
	{
		free(cbuf);
		return NULL;
	}
	
	cbuf->count_written = 0;
	cbuf->read_ptr = cbuf-> start;
	cbuf->end = cbuf->start + n_of_bytes;
	
	return cbuf; 
}

/************************** Complexity O(1) ****************************/
void CBufDestroy(c_buf_t *cbuf)
{
	assert(cbuf);
	
	free(cbuf->start);
	cbuf->start = NULL;
	free(cbuf);
	cbuf = NULL; /* ??*/
}

/************************** Complexity O(1) ****************************/
size_t CBufCapacity(const c_buf_t *cbuf)
{
	assert(cbuf);
	return (cbuf->end - cbuf->start); 
}

/************************** Complexity O(1) ****************************/
size_t CBufFreeSpace(const c_buf_t *cbuf)
{
	assert(cbuf);
	return ((cbuf->end - cbuf->start) - cbuf->count_written);
}

int CBufIsEmpty(const c_buf_t *cbuf)
{
	assert(cbuf);
	return (0 == cbuf->count_written);
}

/************************** Complexity O(N) ****************************/
/* Reading from the buffer to users data , if failes changes g_cbuf_errno to NODATA */

size_t CBufRead(c_buf_t *cbuf, char *data, size_t n_bytes)
{		
	size_t bytes_read = 0;
			
	assert(cbuf && data);
	assert(0 < n_bytes);

	if (0 == cbuf->count_written) 
	{	
		g_cbuf_errno = ENODATA;
		return 0;
	}
		
	n_bytes = MIN(cbuf->count_written, n_bytes);
		
	
	if (cbuf->read_ptr + n_bytes <= cbuf->end) 
	{
		memcpy(data, cbuf->read_ptr, n_bytes);		
		bytes_read = n_bytes;
		cbuf->read_ptr += bytes_read;	
	} 
	else	
	{
		memcpy(data, cbuf->read_ptr, cbuf->end - cbuf->read_ptr);
		bytes_read = cbuf->end - cbuf->read_ptr;
		memcpy(data + bytes_read, cbuf->start, n_bytes - bytes_read);
		cbuf->read_ptr = cbuf->start + n_bytes - bytes_read;
		bytes_read = n_bytes;	
	}	

	cbuf->count_written -= bytes_read;	
	return bytes_read; 
}

/************************** Complexity O(N) ****************************/
/* Writing to the buffer from users data, if failes changes g_cbuf_errno to EOVERFLOW */

size_t CBufWrite(c_buf_t *cbuf, const char *data_to_write, size_t n_bytes)
{	
	size_t bytes_written = 0;
	size_t written_index = 0; 
	
	assert(cbuf && data_to_write);
	assert(0 < n_bytes);
	
	if (0 == CBufFreeSpace(cbuf))
	{
		g_cbuf_errno = EOVERFLOW;
		return 0;
	}
	
	n_bytes = MIN(CBufFreeSpace(cbuf), n_bytes);
	written_index = (((cbuf->read_ptr - cbuf->start) + cbuf->count_written) % (cbuf->end - cbuf->start));
		
	if (cbuf->start + written_index + n_bytes  <= cbuf->end)
	{
		memcpy(cbuf->start + written_index, data_to_write, n_bytes);		
		bytes_written = n_bytes;
	}
	else
	{	
		memcpy(cbuf->start + written_index, data_to_write, (cbuf->end - cbuf->start - written_index));
		bytes_written = n_bytes - (cbuf->end - cbuf->start - written_index);
		memcpy(cbuf->start, data_to_write + bytes_written, n_bytes - bytes_written);
		bytes_written = n_bytes;
	}

	cbuf->count_written += bytes_written;
	 
	return bytes_written;
}
