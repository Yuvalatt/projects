#include <stdio.h>
#include <stdlib.h>  		 /*   EXIT_SUCCESS  */
#include <assert.h>  		 /*    assert      */
#include <time.h>		 /*     time      */
#include "../include/barr.h"

#define COLUMNS 8
#define ROWS 8
#define MAX_VAL 999			

#define BOARD_SIZE (COLUMNS * ROWS)
#define KNIGHT_MOVES_NUM 8
#define GET_INDEX(i, j)((((i) * COLUMNS) + (j)))
#define GET_COL(x)((x) % COLUMNS)
#define GET_ROW(x)((x) / COLUMNS)

typedef enum {SUCCESS = 0, FAIL = 1, TIMEOUT = 2} status_t;

static int knights_moves_LUT[BOARD_SIZE][KNIGHT_MOVES_NUM] = {0};

static void InitKnightMovesLUT(void);
static int SolveKnightProblem(int game_board[BOARD_SIZE], int board_index);
static int SolveWansdorff(int game_board[BOARD_SIZE], int board_index, int moves_count, barr_t visited, clock_t start_t);	/* Wansdorff algorithm */
static int SolveRecursive(int game_board[BOARD_SIZE], int board_index, int move_count, barr_t visited, clock_t start_t);   	/*  Simple algorithm   */
static int IsInRange(int i, int j);
static void PrintSolutionMoves(int game_board[]);
static int GetDegree(int board_index);
static int GetMinMoveIndex(int arr[], int k);
static int InitMovesDegrees(int moves_arr[KNIGHT_MOVES_NUM], int index);


int main(void)
{	
	int x = 0; 
	int y = 0; 	
	int board_index = 0;
	int game_board[BOARD_SIZE] = {0};
	status_t status = 0;
	
	srand(time(0));
	x = rand() % COLUMNS;				 /* CR: chooses a random start point  */
	y = rand() % ROWS;	
	board_index = GET_INDEX(y, x);

	
	if (!knights_moves_LUT[0][0])
	{
		InitKnightMovesLUT();
	}

	status = SolveKnightProblem(game_board, board_index);
	if (SUCCESS == status)
	{
		printf("\nSolution starting at [%d][%d] is:\n", x, y);	
		PrintSolutionMoves(game_board);
	}
	else if (TIMEOUT == status)
	{
		puts("Time out!");
	}
	else
	{
		printf("\nSolution starting at [%d][%d] is not found!\n", x, y);
	}

	return EXIT_SUCCESS;
}

/**************************************************************************************************/
static int SolveKnightProblem(int game_board[BOARD_SIZE], int board_index) 
{
	clock_t start_t = time(0);	
	barr_t visited = 0;
	
	/*return SolveRecursive(game_board, board_index, 1, visited, start_t);
	*/
	return SolveWansdorff(game_board, board_index, 1, visited, start_t);		

}

/**************************************************************************************************/
static int SolveWansdorff(int game_board[BOARD_SIZE], int board_index, int moves_count, barr_t visited, clock_t start_t)
{	
	clock_t curr_t = time(0);

	int min_index = 0;
	int next_move = 0;
	int k = 0;
	int i = 0;
	int moves_arr[KNIGHT_MOVES_NUM] = {0};	
	
	if (BOARD_SIZE == moves_count)
	{
		return SUCCESS;
	}

	if (300 <= (curr_t - start_t))
	{   
		return TIMEOUT;
	}
				
	k = InitMovesDegrees(moves_arr, board_index);      						
	for (i = 0; i < k; ++i)
	{
		min_index = GetMinMoveIndex(moves_arr, k); 						/* chooses next move with least moves options */
		next_move = knights_moves_LUT[board_index][min_index];
		moves_arr[min_index] = MAX_VAL;								 /*   marks visited move as invalid next move  */
		
		if (MAX_VAL != next_move && BarrIsOff(visited, next_move))  				 /* checks if next move is valid (unvisited) */
		{			
			visited = BarrSetOn(visited,board_index);			
			game_board[board_index] = moves_count;					

			if (SUCCESS == SolveWansdorff(game_board, next_move, moves_count + 1, visited, start_t))
			{
				return SUCCESS;      			 /* Keep solving recursively - returns SUCCESS if the entire path is available  */
			}	
		}
	}

	visited = BarrSetOff(visited, board_index);   /* If a certain path fails - remove marks from barr & board */
	game_board[board_index] = 0;

	return FAIL;
}

/**************************************************************************************************/
static int SolveRecursive(int game_board[BOARD_SIZE], int board_index, int move_count, barr_t visited, clock_t start_t)
{
	clock_t curr_time = time(0);
 	int next_move = 0;
	int i = 0;

	if (BOARD_SIZE == move_count)
	{
		return SUCCESS;
	}

	if (300 <= (curr_time - start_t))
	{   
		return TIMEOUT;
	}
	
	for (i = 0; i < KNIGHT_MOVES_NUM; ++i)
	{
		next_move = knights_moves_LUT[board_index][i];

		if (-1 != next_move && BarrIsOff(visited, next_move))
		{			
			visited = BarrSetOn(visited, board_index);			
			game_board[board_index] = move_count;			
			
		
			if (SUCCESS == SolveRecursive(game_board, next_move, move_count + 1, visited, start_t))
			{
				return SUCCESS;
			}	
		}
	}

	visited = BarrSetOff(visited, board_index);
	game_board[board_index] = 0;	

	return FAIL;
}

/**************************************************************************************************/
static int GetDegree(int board_index)
{
	int i = 0;
	int count = 0;

	while ((-1 != knights_moves_LUT[board_index][i]) && (i < KNIGHT_MOVES_NUM))
	{
		++count;
		++i;
	}	
	
	return count;	
}

/**************************************************************************************************/
static int InitMovesDegrees(int moves_arr[KNIGHT_MOVES_NUM], int index)
{
	int i = 0;
	int k = 0;
	
	while (-1 != knights_moves_LUT[index][i] && i < KNIGHT_MOVES_NUM)
	{		
		moves_arr[k] = GetDegree(knights_moves_LUT[index][i]);	
		++k;
		++i;
	}
	
	return k;  			 /* returns number of possible next moves */
}

/**************************************************************************************************/
/*   Returns the index of next move with least moves options    */
static int GetMinMoveIndex(int arr[], int k) 
{
	int i = 0;
	int min_index = 0;	
	int min_moves = arr[0];

	for (i = 0; i < k; ++i)
	{
		if (arr[i] < min_moves)
		{
			min_index = i;
			min_moves = arr[i];
		}
	}
	return min_index;
}

/**************************************************************************************************/
static int IsInRange(int i, int j)
{
	return ((i >= 0 && i < ROWS) && (j >= 0 && j < COLUMNS));
}

/**************************************************************************************************/
static void PrintSolutionMoves(int game_board[BOARD_SIZE])
{
	int i = 0;
	int j = 0;

	for (i = 0; i < ROWS; i++)
	{
		for (j = 0; j < COLUMNS; j++)
		{
			printf("  %2d  ", game_board[GET_INDEX(i, j)]);
		}
		puts("");
	}
}

/**************************************************************************************************/
static void PrintMovesLUT(void)
{
	int i, j = 0;

	puts("MOVES LUT:");		
	for (i = 0; i < BOARD_SIZE; i++)
	{
		printf("%d)", i);
		for (j = 0; j < KNIGHT_MOVES_NUM; j++)
		{
			printf(" %2d ", knights_moves_LUT[i][j]);
		}
		puts("");
	}
}

/**************************************************************************************************/
static void InitKnightMovesLUT(void)
{
	int i = 0;
	int j = 0;
	int k = 0;

	int valid_moves[][2] = {{-2, -1}, {-2, 1}, {2, -1}, {2, 1}, {-1, -2}, {-1, 2}, {1, -2}, {1, 2}};

	for (i = 0; i < BOARD_SIZE; i++)
	{
		k = 0;	
		for (j = 0; j < KNIGHT_MOVES_NUM; j++)
		{	
			int x = GET_COL(i) + valid_moves[j][0];
			int y = GET_ROW(i) + valid_moves[j][1];	

			if (IsInRange(y, x))
			{	
				knights_moves_LUT[i][k] = GET_INDEX(y, x);
				++k;	
			}
		}
		knights_moves_LUT[i][k] = -1;
	}
	PrintMovesLUT();
}
