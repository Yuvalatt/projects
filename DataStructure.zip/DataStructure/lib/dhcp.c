#include <stdlib.h>
#include <assert.h>			 /*  assert  */
#include <string.h>			 /*  memcpy  */
#include <stdio.h>

#include "../include/dhcp.h"
#include "../include/barr.h"
#include "../include/dynvec.h"

#define FALSE 0
#define TRUE 1
#define POW2(x)((0x1<<(x)))
#define TREE_HEIGHT(x)(32 - (x->cidr))

typedef struct dhcp_node dhcp_node_t;

struct dhcp_node
{
    dhcp_node_t *parent;
    dhcp_node_t *child[2];
    int is_full;
};

struct dhcp
{
    dhcp_node_t *root;   		
    unsigned char net_addr[4];
    unsigned int cidr;
};

/*************************************************************************************************************************/
static size_t CountAllocated(dhcp_node_t *node, size_t height);
static status_t AllocSavedIPs(dhcp_t *dhcp);
static dhcp_node_t *FindAddressRec(dhcp_node_t *node, barr_t barr, size_t height);
static status_t AllocAddressRec(dhcp_node_t *node, barr_t *barr, size_t height);
static barr_t ArrToBarr(dhcp_t *dhcp, unsigned char array[]);
static void BarrToArr(dhcp_t *dhcp, barr_t barr, unsigned char array[]);
static void FreePath(dhcp_node_t *node);
static void FlipArray(unsigned char array[]);
void PrintFullTrieRec(const dhcp_node_t *node, dv_t *dynvec, int boolean);
 void PrintFullTrie(const dhcp_t *dhcp);
/*************************************************************************************************************************/
static dhcp_node_t *DHCPCreateNode(dhcp_node_t *parent, dhcp_node_t *left_child, dhcp_node_t *right_child, int is_full)
{
	dhcp_node_t *node = NULL;
	node = (dhcp_node_t *)malloc(1 * sizeof(dhcp_node_t));
	if (!node)
	{
		return NULL;
	}
	
	node->parent = parent;
	node->child[0] = left_child;
	node->child[1] = right_child;
	node->is_full = is_full;

	return node;
}

/*************************************************************************************************************************/
dhcp_t *DHCPCreate(unsigned char net_addr[4], unsigned int cidr)
{
	dhcp_t *dhcp = NULL;
	status_t stat = 0;

	unsigned char net[4] = {10, 1, 0, 0};
	unsigned char broad[4] = {10, 1, 255, 255};
	unsigned char server[4] = {10, 1, 255, 254};	

	assert(net_addr && cidr);

	dhcp = (dhcp_t *)malloc(1 * sizeof(dhcp_t));
	if (!dhcp)
	{
		return NULL;
	}
		
	dhcp->root = DHCPCreateNode(NULL, NULL, NULL, 0);
	if (!dhcp->root)
	{
		free(dhcp);
		return NULL;
	}
	
	dhcp->cidr = cidr;	
	memcpy(dhcp->net_addr, net_addr, (cidr / 8) * sizeof(unsigned char));
	
	if (ALLOCATION_FAILURE == AllocSavedIPs(dhcp))     
	{
		free(dhcp->root);
		dhcp->root = NULL;
		free(dhcp);
		return NULL;
	}
	
	return dhcp;
}

/*************************************************************************************************************************/
/* allocates saved Ips --> 1. Net, 2. Broadcast, 3. DHCP server */
static status_t AllocSavedIPs(dhcp_t *dhcp)     
{	
	unsigned char net[4] = {0, 0, 0, 0};
	unsigned char broad[4] = {255, 255, 255, 255};
	unsigned char server[4] = {255, 255, 255, 254};
	unsigned char arr[4] = {0, 0, 0, 0};

	if (ALLOCATION_FAILURE == DHCPAllocIP(dhcp, net, arr) 
	|| ALLOCATION_FAILURE == DHCPAllocIP(dhcp, broad, arr)
   	|| ALLOCATION_FAILURE == DHCPAllocIP(dhcp, server, arr))
	{
		return ALLOCATION_FAILURE;
	}
	return SUCCESS;
}

/*************************************************************************************************************************/
static void DestroyAll(dhcp_node_t *node)
{
	if (!node)
	{
		return;
	}

	DestroyAll(node->child[0]);
	DestroyAll(node->child[1]);
	
	free(node);
	node = NULL;
}

/*************************************************************************************************************************/
void DHCPDestroy(dhcp_t *dhcp)
{
	assert(dhcp); 
	DestroyAll(dhcp->root);
	dhcp->root = NULL;	
	free(dhcp);
}

/*************************************************************************************************************************/
static size_t CountAllocated(dhcp_node_t *node, size_t height)
{	
	if (!node)
	{
		return 0;
	}	

	if (node->is_full)
	{		
		return POW2(height);
	}
	return (CountAllocated(node->child[0], height - 1) + CountAllocated(node->child[1], height - 1));
}

/*************************************************************************************************************************/
size_t DHCPCountFree(const dhcp_t *dhcp)
{
	assert(dhcp);

	return (POW2(TREE_HEIGHT(dhcp)) - CountAllocated(dhcp->root, TREE_HEIGHT(dhcp)));	
}


/*************************************************************************************************************************/
/* Return value: SUCCESS - on success req_ip holds the ip address, otherwise returns ALLOCATION_FAILURE */
status_t DHCPAllocIP(dhcp_t *dhcp, unsigned char base_addr_optional[4], unsigned char req_ip[4])
{
	barr_t barr = BarrAllOff();

	assert(dhcp);

	if (dhcp->root->is_full)	 /* case of full tree  */
	{
		return ALLOCATION_FAILURE;
	}

	if (base_addr_optional)
	{
		barr = ArrToBarr(dhcp, base_addr_optional);
	}
	
	if (ALLOCATION_FAILURE == AllocAddressRec(dhcp->root, &barr, TREE_HEIGHT(dhcp)))			
	{
		return ALLOCATION_FAILURE;
	}

	BarrToArr(dhcp, barr, req_ip);
	memcpy(req_ip, dhcp->net_addr, (dhcp->cidr / 8) * sizeof(unsigned char));

	return SUCCESS;
}
/*************************************************************************************************************************/
static status_t AllocAddressRec(dhcp_node_t *node, barr_t *barr, size_t height)  /* index - starts as Tree height */
{
	int child_side = 0;
	size_t next_height = height - 1;
	dhcp_node_t *next_node = NULL;

	if (0 == height)
	{
		if (!node)
		{
			if (!(node = DHCPCreateNode(node, NULL, NULL, 0)))
			{
				return ALLOCATION_FAILURE;
			}
		}
		node->is_full = 1;

		if (node->parent->child[1] == node)
		{
			*barr = BarrSetOn(*barr, 0);
		}

		return SUCCESS;
	}
		
	child_side = (1 == BarrIsOn(*barr, height - 1));	
	if (!node->child[child_side])								/*  if child doesnt exist - create it   */
	{		
		if (!(node->child[child_side] = DHCPCreateNode(node, NULL, NULL, 0)))
		{
			return ALLOCATION_FAILURE;
		}
	}

	next_node = node->child[child_side];
	if (next_node->is_full) 								/* if next child is full-  toggle next bit & run recursion with same parameters */
	{
		*barr = BarrToggleBit(*barr, height - 1);
		next_node = node;
		next_height = height;
	}

	if (SUCCESS == AllocAddressRec(next_node, barr, next_height))
	{
		node->is_full = ((node->child[child_side] && node->child[!child_side]) ? 
						(node->child[child_side]->is_full && node->child[!child_side]->is_full) : 0);
		return SUCCESS;
	}
	
	return ALLOCATION_FAILURE;
}

/*************************************************************************************************************************/
static dhcp_node_t *FindAddressRec(dhcp_node_t *node, barr_t barr, size_t height)
{
	int child_side = 0;
	
	if (0 == height)
	{
		if (!node->is_full)
		{
			return NULL;
		}

		return node;
	}

	child_side = (1 == BarrIsOn(barr, height - 1));
	if (!node->child[child_side])
	{
		return NULL;
	}
	
	return FindAddressRec(node->child[child_side], barr, height - 1);
}

/*************************************************************************************************************************/
static void FreePath(dhcp_node_t *node)
{
	int child_side = 0;
	dhcp_node_t *parent = NULL;
	
	if (!node->parent) /* root  */	
	{
		if (!node->child[0] && !node->child[1])
		{					 			
			free(node);
		}
		else
		{
			node->is_full = 0;
		}
		return;
	}
	
	parent = node->parent;
	child_side = (node == parent->child[1]); 

	if (!node->child[0] && !node->child[1])
	{
		parent->child[child_side] = NULL;
		free(node);			
		node = NULL;
	}	
	else
	{
		node->is_full = 0;
	}
		
	FreePath(parent);
}

/*************************************************************************************************************************/
/* Return value: SUCCESS or INVALID_IP */
status_t DHCPFreeIP(dhcp_t *dhcp, unsigned char ip_addr[4])
{	
	dhcp_node_t *node = NULL;
	barr_t barr = 0;
	
	assert(dhcp && ip_addr);  
	
	/*if (INVALID_IP == IsValidIP(dhcp, ip_addr))
	{
		puts("Error: Invalid IP");
		return INVALID_IP;
	}*/

	barr = ArrToBarr(dhcp, ip_addr);
	
	node = FindAddressRec(dhcp->root, barr, TREE_HEIGHT(dhcp));	
	if (!node)
	{
		return INVALID_IP;
	}

	FreePath(node);

	return SUCCESS;
}

/*************************************************************************************************************************/
static void FlipArray(unsigned char array[])
{
    size_t i = 0;
    size_t j = 3;
    unsigned char temp = 0;

    while (i<j)
    {
        temp = array[i];
        array[i] = array[j];
        array[j] = temp;
        ++i;
        --j;
    }
}

static barr_t ArrToBarr(dhcp_t *dhcp, unsigned char array[])
{
    barr_t barr = 0;
    size_t size = 0;

    assert(array);

    barr = BarrAllOff();
    size = (TREE_HEIGHT(dhcp) / 8);
    FlipArray(array);
    memcpy(&barr, array, size);

    return barr;
}

static void BarrToArr(dhcp_t *dhcp, barr_t barr, unsigned char array[])
{
    size_t size = 0;

    assert(array);

    size = (TREE_HEIGHT(dhcp) / 8);
    memcpy(array, &barr, size);
    FlipArray(array);

}

/*   For Tests    */
/*************************************************************************************************************************/
 void PrintFullTrie(const dhcp_t *dhcp)
{
    dv_t *dynvec = DVCreate(0, 4);

    puts("START");
    PrintFullTrieRec(dhcp->root, dynvec , 999);
    puts("END");

    free(dynvec);
    dynvec = NULL;
}

void PrintFullTrieRec(const dhcp_node_t *node, dv_t *dynvec, int boolean)
{
    int i = 0;
    int value = boolean;
    
    if (!node)
    {
        return;
    }

    DVPushBack(dynvec, &value);

    if (!node->child[0] && (!node->child[1]))
    {
        for (i = DVSize(dynvec) - 1; i > 0; --i)
        {
            printf("%d<-", *(int *)DVGetItemAddress(dynvec, i));
        }

        printf("Root\n");
        
    }

    PrintFullTrieRec(node->child[0], dynvec, 0);
    PrintFullTrieRec(node->child[1], dynvec, 1);

    DVPopBack(dynvec);
}

