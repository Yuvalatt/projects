#include  "../include/vsm.h"
#include <assert.h> 		/* assert */
#include <unistd.h>		/* ssize_t */

#define MAX_SIZE(a, b)(a > b ? a : b)
#define WORD_SIZE 8

#ifndef NDEBUG
#define MAGIC_STAMP 0x8080808080808080 
#endif

struct vsm
{
	size_t mem_size;
};

typedef struct vsm_block
{
	ssize_t size;
	#ifndef NDEBUG
	unsigned long magic;
	#endif
} vsm_block_t;


static void BlockInit(vsm_block_t *block, ssize_t b_size);
static int IsValidBlock(vsm_block_t *block_ptr);
static int JoinBlocks(char *runner, char *end);

/***********************  Complexity O(1)  ***********************************/
static void BlockInit(vsm_block_t *block, ssize_t b_size)
{
	assert(block);
	
	block->size = b_size;
	
	#ifndef NDEBUG
	block->magic = MAGIC_STAMP;
	#endif
}

/***********************  Complexity O(1)  ***********************************/
vsm_t *VSMInit(void *mem_ptr, size_t mem_size)
{			
	vsm_t *vsm = NULL;
	vsm_block_t *block_ptr = NULL;

	assert(mem_ptr && mem_size);
	
	vsm = mem_ptr;
	vsm->mem_size = mem_size;
										
	block_ptr = (vsm_block_t *)((char *)vsm + sizeof(vsm_t));
	     		 																
	BlockInit(block_ptr, mem_size - sizeof(vsm_t) - sizeof(vsm_block_t));
	
	return vsm;
}
	
/***********************  Complexity O(n)  ***********************************/	
void *VSMAlloc(vsm_t *vsm, size_t block_size) 
{
	ssize_t aligned_size = 0;
	ssize_t next_size = 0;

	char *runner = NULL;
	char *next_runner = NULL;
	char *end = NULL;

	vsm_block_t *block = NULL;
	vsm_block_t *next_block = NULL;
	
	assert(vsm && block_size);

	aligned_size = (0 == block_size % WORD_SIZE) ? block_size : block_size + (WORD_SIZE - block_size % WORD_SIZE);
	
	runner = (char *)vsm + sizeof(vsm_t);
	end = (char *)vsm + vsm->mem_size;
	
	while (runner < end)
	{
		block = (vsm_block_t *)runner;
		
		if (block->size < 0)
		{
			runner = runner - block->size + sizeof(vsm_block_t);
		}
		else if (block->size < aligned_size)
		{
			if (!JoinBlocks(runner, end))
			{
				runner = runner + block->size + sizeof(vsm_block_t);
			}
		}
		else   /* Enough space found */
		{	
			next_runner = runner + sizeof(vsm_block_t) + aligned_size;
							
			if (sizeof(vsm_block_t) + aligned_size <  block->size)    /* Check if init of new block is possible */
			{
				next_block = (vsm_block_t *)next_runner;

				BlockInit(next_block, block->size - aligned_size - sizeof(vsm_block_t)); 
				
				block->size = -aligned_size;
			}
			else
			{
				block->size = -block->size;
			}

			return (runner + sizeof(vsm_block_t));			
		}	
	}			
	
	return NULL; 		/* Space not found */	
}

/***********************  Complexity O(1)  **************************************/
static int JoinBlocks(char *runner, char *end)
{
	char *next_runner = NULL;
	vsm_block_t *block = NULL;
	vsm_block_t *next_block = NULL;
	int joined = 0;
	
	block = (vsm_block_t *)runner;
	
	next_runner = runner + sizeof(vsm_block_t) + block->size;
	
	while (next_runner < end)
	{
		next_block = (vsm_block_t *)next_runner;
		
		if(next_block->size < 0)
		{
			break;	
		}
		else 
		{
			joined = 1;
			block->size += next_block->size + sizeof(vsm_block_t);
			next_runner = next_runner + next_block->size + sizeof(vsm_block_t);	
		}	
	}

	return joined;
}	

/***********************  Complexity O(1)  ***********************************/
void VSMFree(void *ptr)
{
	vsm_block_t *block = NULL;
	
	assert(ptr);
	
	block = (vsm_block_t *)((char *)ptr - sizeof(vsm_block_t)); 
	
	assert(IsValidBlock(block));
	
	block->size = -block->size;   /* Get a negative block_size & set it back to positive */
}

/***********************  Complexity O(1)  ***********************************/
static int IsValidBlock(vsm_block_t *block)
{
	#ifndef NDEBUG
	return (MAGIC_STAMP == block->magic && block->size < 0);
	#endif
}

/***********************  Complexity O(n)  ***********************************/
size_t VSMCountFree(vsm_t *vsm)
{
	size_t free_bytes = 0;
	
	char *runner = NULL;
	char *end = NULL;
	vsm_block_t *block = NULL;
	
	assert(vsm);

	runner = (char *)vsm + sizeof(vsm_t);	
	end = (char *)vsm + vsm->mem_size;

	while (runner < end)
	{
		block = (vsm_block_t *)runner;
		
		if (block->size > 0)
		{
			JoinBlocks(runner, end);
				
			free_bytes += block->size;

			runner = runner + block->size + sizeof(vsm_block_t);
		}
		else 
		{
			runner = runner - block->size + sizeof(vsm_block_t);
		}
	}

	return free_bytes;
}

/***********************  Complexity O(n)  ***********************************/
size_t GetLargest(vsm_t *vsm)
{
	size_t max_size = 0;
	char *runner = NULL;
	char *end = NULL;	
	vsm_block_t *block = NULL;
	
	assert(vsm);
	
	runner = (char *)vsm + sizeof(vsm_t);
	end = (char *)vsm + vsm->mem_size;

	while (runner < end)
	{
		block = (vsm_block_t *)runner;
		
		if (block->size > 0)
		{
			max_size = MAX_SIZE(max_size, (size_t)block->size);

			runner +=  (block->size + sizeof(vsm_block_t));	
		}
		else
		{
			runner = runner - block->size  + sizeof(vsm_block_t);
		}		
	}
	return max_size;		
}
