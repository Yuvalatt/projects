#include "../include/sorts.h"
#include <assert.h>
#include <string.h> /*memcpy*/

typedef struct
{
     size_t iteration;
     const void *args;
     el_to_key_t key_func;
} args_t;

/* The contents of the array are sorted in ascending order according to a comparison function */
void InsertionSort(void *base, size_t nmemb, size_t size, cmp_func_t cmp_func)
{
    long i = 0;
    long j = 0;
    void *key = NULL;

    assert(base && nmemb && size && cmp_func);

    key = malloc(1 * size);
    if(NULL == key)
    {
        return;
    }
    for (i = 1; (unsigned)i < nmemb; ++i)
    {   
        memcpy(key, (char *)base + (i * size), size);
        j = i - 1;
    
        while ((j >= 0) && (0 > (*cmp_func)(key, (char *)base + (size * j))))
        {
            j = j - 1;           
        }
        if (j < 0)
        {
             memmove((char *)base + size ,(char *)base ,i * size);
        }
        else
        {
             memmove((char *)base + (size * (j + 1)),(char *)base + (size * j),(i - j)* size);
        }

        memcpy((char *)base + (size * (j + 1)), key, size);
    }
    free(key);
}

static void Swap(void *val1, void *val2, size_t size)
{
    void *temp =  malloc(1 * size);
    if(NULL == temp)
    {
        return;
    }
    memcpy(temp, val1, size);
    memcpy(val1, val2, size);
    memcpy(val2, temp, size);

    free(temp);

}

void SelectionSort(void *base, size_t nmemb, size_t size, cmp_func_t cmp_func)
{
    int i = 0;
    int j = 0; 
    int min_index = 0;
   
    assert(base && nmemb && size && cmp_func);

    for (i = 0; (unsigned)i < nmemb - 1; ++i)
    {
        min_index = i;

        for (j = i + 1; (unsigned)j < nmemb; ++j)
        {
            if (0 > (*cmp_func)((char *)base + (size * j), (char *)base + (size * min_index)))
            {
                min_index = j;
            }
        }
        Swap((char *)base + (size * min_index),  (char *)base + (size * i), size);
    }

}

void BubbleSort(void *base, size_t nmemb, size_t size, cmp_func_t cmp_func)
{
    long i = 0;
    long j = 0;
    long k = 0;
    long swap_index = nmemb - 1;

    assert(base && nmemb && size && cmp_func);

    for (i = 0; (unsigned)i < nmemb - 1; ++i)
    {
        k = swap_index;
         
       for (j = 0; j < k; ++j)
       {
            if (0 < (*cmp_func)((char *)base + (size * j), (char *)base + (size * (j+1))))
            {
                Swap((char *)base + (size * j), (char *)base + (size * (j+1)), size);
                swap_index = j;
            }
       }
    }

}

void CountingSort(void *base, size_t nmemb, size_t size, el_to_key_idx_t key_func, const void * args, size_t range)
{
    size_t i = 0;
    void *dest = NULL;
    void *histogram = NULL;

    assert(base && nmemb && size && key_func  && range);

    dest = malloc(nmemb * size);
    if (NULL == dest)
    {
        return;
    }
   
    histogram = calloc(range, sizeof(size_t));
    if (NULL == histogram)
    {
        free(dest);
        return;
    }
    
    CountingSortEx(base,dest, nmemb, size, key_func, args, range, histogram);
    memcpy(base, dest, nmemb * size);
    free(histogram);
    free(dest);
}

void CountingSortEx(void *src,void *dest, size_t nmemb, size_t size, el_to_key_idx_t key_func, const void  *args, size_t range, size_t *histogram)
{
    size_t i = 0;
    size_t index_his = 0;
    size_t index_dest = 0;
    size_t index_start = 0;

    assert(src && dest && nmemb && size && key_func  && range && histogram);

    for( i = 0; i < nmemb; ++i)
    {
        index_his = key_func((char *)src + (i* size) , args);
        ++histogram[index_his];
    }
    for (i = 1; i < range; ++i)
    {
        histogram[i] += histogram[i - 1];
    }
    for (i = 0; i < nmemb; ++i)
    { 
        index_his = key_func((char *)src + (i * size), args);
        
        if( 0 == index_his)
        {
            index_dest = index_start;
            ++index_start;
        }
        else
        {
            index_dest = histogram[index_his - 1];
             ++histogram[index_his - 1];
        }
        memcpy((char *)dest + (index_dest * size), (char *)src + (i * size), size);
    }
}

static size_t ElementToKey(const void * element, const void * args)
{
    size_t digit = ((args_t *)args)->key_func(element , ((args_t *)args)->args);
    return (digit  >> (8 * ( ((args_t *)args)->iteration ) ) ) & 0xFF;
}
static void SwapPointers( void **ptr_to_ptr1, void **ptr_to_ptr2)
{
    int *temp = *ptr_to_ptr1;
    *ptr_to_ptr1 = *ptr_to_ptr2;
    *ptr_to_ptr2 = temp;
}
void RadixSort(void *base, size_t nmemb, size_t size, el_to_key_t key_func, const void *args, size_t num_of_bytes)
{
    size_t i = 0;
    args_t data = {0};
    void *dest = NULL;
    void *histogram = NULL;

    assert(base && nmemb && size && key_func  && num_of_bytes);
    
    data.args = args;
    data.key_func = key_func; 
    dest = malloc(nmemb * size);
    if (NULL == dest)
    {
        return;
    }
   
    histogram = calloc(256, sizeof(size_t));
    if (NULL == histogram)
    {
        free(dest);
        return;
    }

    for (i = 0; i < num_of_bytes; ++i)
    {
        memset(histogram, 0, 256 * sizeof(size_t));
        data.iteration = i;
        CountingSortEx(base ,dest, nmemb, size, ElementToKey, &data, 256, histogram);
        SwapPointers(&base, &dest);
        
    }
    if( 0 != num_of_bytes % 2)
    {
        SwapPointers(&base, &dest);
        for ( i = 0; i < nmemb; ++i)
        {
            memcpy((char *)base + (i* size), (char *)dest + (i* size), size);
        }
    }
    free(histogram);
    free(dest);     
}

static void Merge(void *base, void *temp, size_t size, cmp_func_t cmp_func, size_t low, size_t mid, size_t high)
{
    size_t i = 0;
	size_t right_index = 0;
	size_t k = 0;
	size_t left_index = 0;

	left_index = low;
	i = low;
	right_index = mid + 1;

	while ((left_index <= mid) && (right_index <= high))
	{
		if (0 >= (*cmp_func)((char *)base + (size * left_index), (char *)base + (size * right_index))) 
		{
            memcpy((char *)temp + (size * i), (char *)base + (size * left_index), size); 
			left_index++;
		}
		else
		{
            memcpy((char *)temp + (size * i), (char *)base + (size * right_index), size);
			right_index++;
		}
		i++;
	}

	if (left_index > mid)
	{
        k = right_index;
        memcpy((char *)temp + (size * i), (char *)base + (size * k), size * (high - right_index + 1));
	}
	else
	{
        k = left_index;
        memcpy((char *)temp + (size * i), (char *)base + (size * k), size * (mid - k + 1));

	}

    k = low;
    memcpy((char *)base + (size * k),(char *)temp + (size * k) , size *(high - low + 1));
}
static void MergeSortRec(void *base, void *temp, size_t nmemb, size_t size, cmp_func_t cmp_func,size_t low, size_t high)
{
    size_t mid = 0;

	if (low < high)
	{
		mid = (low + high) / 2;
		MergeSortRec(base, temp, nmemb, size,cmp_func, low, mid);
		MergeSortRec(base, temp, nmemb, size,cmp_func, mid + 1, high);
		Merge(base, temp, size, cmp_func, low, mid, high);
	}


}
void MergeSort(void *base, size_t nmemb, size_t size, cmp_func_t cmp_func)
{
    void *temp = malloc(size * nmemb);
    MergeSortRec(base, temp, nmemb, size,  cmp_func, 0, nmemb - 1);
    free(temp);
}


static void Heapify(void *base, size_t nmemb, size_t size, cmp_func_t cmp_func,  size_t index)
{
    size_t largest_index = index;
    size_t left_index = (index * 2) + 1;
    size_t right_index =  (index * 2) + 2;

    void *left_child = NULL;
    void *parent = NULL;
    void *largest = NULL;
    void *right_child = NULL;
							/* CR: Extra spaces ...*/

    parent  = (char *)base + (size * index);
   
    if (left_index < nmemb)
    {   
        left_child = (char *)base + (size * left_index);
        if (0 < cmp_func(left_child, parent))
        {
             largest_index = left_index;
        }    
    }							/* CR: add a space line */
    if (right_index < nmemb)
    {    
        right_child = (char *)base + (size * right_index);
        largest = (char *)base + (size * largest_index);
        if (0 < cmp_func(right_child,largest))
        {
            largest_index = right_index;
        }

        						/* CR: Extra spaces ...*/
    }
    
    if (largest_index != index)
    {
        largest =  largest = (char *)base + (size * largest_index);
        Swap(largest, parent,size);
        Heapify(base, nmemb, size, cmp_func, largest_index);
    }

}
static void BuildHeap(void *base, size_t nmemb, size_t size, cmp_func_t cmp_func)
{
    long i = 0;

    for (i = (nmemb / 2); i >= 0 ; --i)
    {
        Heapify(base,nmemb,size,cmp_func, i);
    }
}
void HeapSort(void *base, size_t nmemb, size_t size, cmp_func_t cmp_func)
{
    size_t i = 0;
    
    BuildHeap(base, nmemb, size, cmp_func);

    for (i = (nmemb - 1) * size ; i >= size ; i -= size)	/* CR: spaces */
    {   
        Swap(base, (char *)base + i, size);  
        nmemb -= 1;
        Heapify(base,nmemb,size,cmp_func, 0);			/* CR: add spaces */
    }
}
