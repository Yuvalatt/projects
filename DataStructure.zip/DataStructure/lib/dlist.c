#include "../include/dlist.h"
#include <assert.h>  /* assert */

#define END_STUB 0xDEADBEEF
#define START_STUB 0xBEEFDEAD


struct dlist_node
{
	void *val;	
	struct dlist_node *prev;
	struct dlist_node *next;
};

struct dlist
{
	struct dlist_node head;
	struct dlist_node tail;
};

typedef struct dlist_node dlist_node_t;

static dlist_node_t *DListCreateNode(void *val, dlist_node_t *prev, dlist_node_t *next);

void DListFreeAll(dlist_t *dlist, dlist_node_t *head);

size_t DListCount(const dlist_node_t *head);

/***********************  Complexity O(N)  ***********************************/

void DListFreeAll(dlist_t *dlist, dlist_node_t *head)
{	
	dlist_node_t *tmp = NULL;
	
	while (&dlist->tail != head)
	{
		tmp = head;
		head = head->next;
		free(tmp);
		tmp = NULL;
	} 
}
/***********************  Complexity O(1)  ***********************************/

static dlist_node_t *DListCreateNode(void *val, dlist_node_t *prev, dlist_node_t *next)
{
	dlist_node_t *node = malloc(1 * sizeof(dlist_node_t));
	
	assert(val);

	if(NULL == node)
	{
		return NULL;
	}
	node->val = val; 
	node->next = next;
	node->prev = prev;

	return node;
}									
/***********************  Complexity O(1)  ***********************************/

dlist_t *DListCreate(void)
{
	dlist_t *dlist = malloc(1 * sizeof(dlist_t));
	
	if(NULL == dlist)
	{
		return NULL;
	}
	
	dlist->tail.val = (void *)END_STUB;
	dlist->tail.next = NULL; 	
	dlist->head.val = (void *)START_STUB;
	dlist->head.prev = NULL;
	dlist->head.next = &dlist->tail;
	dlist->tail.prev = &dlist->head;

	return dlist;
}
/***********************  Complexity O(1)  ***********************************/

void DListDestroy(dlist_t *dlist)
{
	DListFreeAll(dlist, dlist->head.next);
	free(dlist);

	dlist = NULL;
}
/***********************  Complexity O(N)  ***********************************/

size_t DListCount(const dlist_node_t *head)
{
	size_t count = 0;
	
	while(NULL != head)
	{
		++count;
		head = head->next;
	}
	return count;
}
/***********************  Complexity O(N)  ***********************************/

size_t DListSize(const dlist_t *dlist)
{
	assert(dlist); 

	return (DListCount(&dlist->head) - 2);	
}
/***********************  Complexity O(1)  ***********************************/
 /* Return value: True - 1, False - 0*/

int DListIsEmpty(const dlist_t *dlist)  
{
	assert(dlist);
	
	return (dlist->head.next == &dlist->tail);   
}
/***********************  Complexity O(1)  ***********************************/

dlist_iter_t DListBegin(const dlist_t *dlist)
{
	assert(dlist);

	return (dlist->head.next);
}
/***********************  Complexity O(1)  ***********************************/

dlist_iter_t DListEnd(const dlist_t *dlist)
{
	assert(dlist);

	return ((void *)&dlist->tail);
}
/***********************  Complexity O(1)  ***********************************/ 

dlist_iter_t DListNext(const dlist_iter_t iter)
{
	assert(iter);

	return (((dlist_node_t *)iter)->next);
}
/***********************  Complexity O(1)  ***********************************/ 

dlist_iter_t DListPrev(const dlist_iter_t iter)
{
	assert(iter);

	return (((dlist_node_t *)iter)->prev);
}
/***********************  Complexity O(1)  ***********************************/ 

void *DListGetData(const dlist_iter_t iter)
{
	assert(iter);

	return (((dlist_node_t *)iter)->val);
}
/***********************  Complexity O(1)  ***********************************/ 
/* Return value: True - 1, False - 0*/

int DListIsSameIter(const dlist_iter_t iter1, const dlist_iter_t iter2)
{
	assert(iter1 && iter2);

	return (iter1 == iter2);
}
/***********************  Complexity O(1)  ***********************************/

/* Inserts the value before the given iterator.
 * Return value: iterator to the value inserted ,END iterator on failure */	

dlist_iter_t DListInsert(dlist_t *dlist, dlist_iter_t iter, void *val)
{
	dlist_node_t *node =  DListCreateNode(val, NULL, NULL);
	
	assert(iter && (&dlist->head != iter));
	
	if (NULL == node)                      
	{
		return (DListEnd(dlist));
	}
	
	((dlist_node_t *)iter)->prev->next = node;
	node->next = iter;
	node->prev = ((dlist_node_t *)iter)->prev;
	((dlist_node_t *)iter)->prev = node;
	
	return node; 
}
/***********************  Complexity O(1)  ***********************************/

/* Inserts the value after the given iterator.
*  Return value: iterator to the value inserted ,END iterator on failure */	

dlist_iter_t DListInsertAfter(dlist_t *dlist, dlist_iter_t iter, void *val)
{
	dlist_node_t *node =  DListCreateNode(val, NULL, NULL);
	
	assert(iter && (&dlist->tail != iter));
	
	if (NULL == node)                      
	{
		return (DListEnd(dlist));
	}
	
	node->next = ((dlist_node_t *)iter)->next;	
	((dlist_node_t *)iter)->next = node;	
	node->prev = iter;	
	node->next->prev = node;

	return node;
}
/***********************  Complexity O(1)  ***********************************/
/* Erase current node */

dlist_iter_t DListErase(dlist_iter_t iter)
{
	dlist_iter_t next = NULL;	
	assert(iter && ((void *)END_STUB != ((dlist_node_t *)iter)->val) && ((void *)START_STUB != ((dlist_node_t *)iter)->val));
	
	next = ((dlist_node_t *)iter)->next;
	((dlist_node_t *)iter)->prev->next = ((dlist_node_t *)iter)->next;
	((dlist_node_t *)iter)->next->prev = ((dlist_node_t *)iter)->prev;
	
	free(iter);
	iter = NULL;

	return next;
}
/***********************  Complexity O(1)  ***********************************/

dlist_iter_t DListPushFront(dlist_t *dlist, void *val)
{
	assert(dlist && val);
	
	return (DListInsert(dlist, DListBegin(dlist), val));
}
/***********************  Complexity O(1)  ***********************************/

dlist_iter_t DListPushBack(dlist_t *dlist, void *val)
{
	assert(dlist && val);
	
	return (DListInsert(dlist, DListEnd(dlist), val));
}
/***********************  Complexity O(1)  ***********************************/

void DListPopBack(dlist_t *dlist)
{
	assert(dlist);
	
	DListErase(dlist->tail.prev);
}
/***********************  Complexity O(1)  ***********************************/

void DListPopFront(dlist_t *dlist)
{
	assert(dlist);
	
	DListErase(dlist->head.next);
}
/***********************  Complexity O(N)  ***********************************/

dlist_iter_t DListFind(const dlist_t *dlist, const dlist_iter_t from_it, const dlist_iter_t to_it, cmp_func_t CmpFunc, const void *param, const void *data)
{
	dlist_iter_t iter = from_it;	
	
	assert(dlist && from_it && to_it && CmpFunc);

	while(iter != to_it)
	{
		if (1 == CmpFunc(DListGetData(iter), param, data))
		{
			return iter;
		}
		iter = DListNext(iter);
	}	
	return DListEnd(dlist);
}
/***********************  Complexity O(N)  ***********************************/

int DListForEach(dlist_iter_t from_it, dlist_iter_t to_it, act_func_t ActFunc, void *param)
{
	dlist_iter_t iter = from_it;
	
	assert(from_it && to_it && ActFunc);
	
	while(iter != to_it)
	{
		if( 0 ==  ActFunc(DListGetData(iter), param))
		{
			return 0;	
		}
		iter = DListNext(iter);
	}
	return 1;
}
/***********************  Complexity O(1)  ***********************************/

void DListSpliceBefore(dlist_iter_t where, dlist_iter_t from, dlist_iter_t to)
{
	dlist_node_t *tmp = NULL;
	assert(where && from && to);
	
	((dlist_node_t *)to)->prev->next = where;
	((dlist_node_t *)where)->prev->next = from;
	((dlist_node_t *)from)->prev->next = to;
	tmp = ((dlist_node_t *)to)->prev;
	
	((dlist_node_t *)to)->prev = ((dlist_node_t *)from)->prev;
	((dlist_node_t *)from)->prev = ((dlist_node_t *)where)->prev;
	((dlist_node_t *)where)->prev = tmp;	
	
}
