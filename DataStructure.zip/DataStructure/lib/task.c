#include <stdlib.h>
#include <assert.h>

#include "../include/uid.h"
#include "../include/task.h"

typedef struct task
{
	uniqid_t uid;
	task_func_t task_func;
	void *param;
	time_t period_is_secs;
	time_t activation_time;
};

task_t *TaskCreate(task_func_t task_func, void *param, time_t period_is_secs)
{
	task_t *task = malloc(1 * sizeof(task_t));
	assert(task_func);

	if(NULL == task)
	{
		return NULL;
	}

	task->uid = UIDCreate();
	if(UIDIsBad(&task->uid))
	{
		free(task);
		return NULL;
	}

	time(&task->activation_time);
	task->task_func = task_func;
	task->period_is_secs = period_is_secs;
	task->param = param;
	task->activation_time += period_is_secs;

	return task;
}

void TaskDestroy(task_t *task)
{
	free(task);

	task = NULL;
}

void TaskTimeUpdate(task_t *task)
{
	assert(task);

	task->activation_time +=  task->period_is_secs;
}

int TaskRun(task_t *task)
{
	assert(task);

	return task->task_func(task->param);
} 

time_t TaskGetActTime(task_t *task)
{
	assert(task);

	return task->activation_time;
}

uniqid_t TaskGetId(task_t *task)
{
	assert(task);

	return task->uid;
}

time_t TaskGetPeriodInSec(task_t *task)
{
	assert(task);

	return task->period_is_secs;
}

int TaskIsSame(task_t *task1, task_t *task2)
{
	return UIDIsSame(&task1->uid, &task2->uid);
}
