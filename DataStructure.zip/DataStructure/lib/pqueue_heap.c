#include <assert.h> 			 /* assert */
#include "../include/pqueue.h"
#include "../include/heap.h"

struct pqueue
{
	heap_t *heap;
};

/***********************  Complexity O(1)  ***********************************/
pq_t *PQCreate(pq_is_before_t is_before, void *param)
{
	pq_t *pqueue = NULL;
	assert(is_before);

	pqueue = malloc(1 * sizeof(pq_t));

	if(NULL == pqueue)
	{
		return NULL;
	}
	
	pqueue->heap = HeapCreate((heap_cmp_func_t)is_before, param);
	
	if (NULL == pqueue->heap)                      
	{
		free(pqueue);
		return NULL;
	}

	return pqueue;
}
/***********************  Complexity O(N)  ***********************************/
void PQDestroy(pq_t *pqueue)
{
	assert(pqueue);

	HeapDestroy(pqueue->heap);
	
	free(pqueue);
	pqueue = NULL;
}
/***********************  Complexity O(N)  ***********************************/
size_t PQSize(const pq_t *pqueue)
{
	assert(pqueue);

	return HeapSize(pqueue->heap);
}
/***********************  Complexity O(1)  ***********************************/
/* return value empty - 1, not empty - 0 */

int PQIsEmpty(const pq_t *pqueue)
{
	assert(pqueue);

	return HeapIsEmpty(pqueue->heap);
}
/***********************  Complexity O(N)  ***********************************/
/*   SUCCESS - 0, FAILURE (malloc) - 1 	 */

int PQEnqueue(pq_t *pqueue, void *data)
{
	assert(pqueue);

	return HeapPush(pqueue->heap, data);
} 
	
/***********************  Complexity O(1)  ***********************************/
/*   Do not perform on an empty queue 	 */

void *PQDequeue(pq_t *pqueue)
{
	assert(pqueue);

	if (PQIsEmpty(pqueue))
	{
		return NULL;
	}

	return HeapPop(pqueue->heap);
}			 	
/***********************  Complexity O(1)  ***********************************/
/*   Do not perform on an empty queue 	 */

void *PQPeek(const pq_t *pqueue)
{
	assert(pqueue);

	if (PQIsEmpty(pqueue))
	{
		return NULL;
	}
	
	return HeapPeek(pqueue->heap);
} 			
/***********************  Complexity O(N)  ***********************************/
void *PQErase(pq_t *pqueue, pq_cmp_func_t CmpFunc, void *param)
{
	assert(pqueue && CmpFunc);

	return HeapRemove(pqueue->heap, (heap_find_t)CmpFunc, param, NULL);
}

/***********************  Complexity O(N)  ***********************************/
void PQClearAll(pq_t *pqueue)
{
	assert(pqueue);

	while (!PQIsEmpty(pqueue))
	{
		PQDequeue(pqueue);
	}	
}
