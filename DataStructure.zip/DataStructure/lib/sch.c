#include "../include/sch.h"
#include "../include/uid.h"
#include "../include/pqueue.h"

#include <assert.h>

#define UNUSED(X)(void)(X)

static int IsBefore(const void *data1, const void *data2, void *param);
static int AreEqual(const void *val, void *param);
void ClearAllTasks(sch_t *sch);

enum status {SUCCESS = 0, FAIL = 1};

typedef struct sch
{
	pq_t *task_list;
	int stop_flag;
};

/* Compexity - O(1) */
sch_t *SCHCreate(void)
{
	sch_t *sch = malloc(1 * sizeof(sch_t));
	
	if(NULL == sch)
	{
		return NULL;
	}
	
	sch->task_list = PQCreate(&IsBefore, NULL);
	if(NULL == sch->task_list)
	{
		free(sch);
		return NULL;
	}
	
	sch->stop_flag = 0;
	return sch;
}

/* Compexity - O(N) */
void SCHDestroy(sch_t *sch)
{
	assert(sch);
	
	ClearAllTasks(sch);	
	PQDestroy(sch->task_list);	

	sch->task_list = NULL;
	free(sch);
	sch = NULL;
}

/* Compexity - O(N) */
size_t SCHSize(const sch_t *sch)
{
	assert(sch);
	
	return PQSize(sch->task_list);
}

/* Compexity - O(1) */
/* Return value: True - 1, False - 0*/
int SCHIsEmpty(const sch_t *sch)
{
	assert(sch);

	return PQIsEmpty(sch->task_list);	
}

/* Compexity - O(N) */
/*  Return value:  SUCCESS -return the uid of the task, FAILURE - returns bad uid  */
uniqid_t SCHAddTask(sch_t *sch, task_func_t task_func, void *param, size_t period_is_secs)
{
	task_t *task = TaskCreate(task_func, param, period_is_secs);

	assert(task_func);
	
	if(NULL == task)
	{
		return UIDGetBad();
	}

	if(1 == PQEnqueue(sch->task_list, task))
	{
		free(task);
		return UIDGetBad();
	}
	
	return TaskGetId(task);
}

/* Compexity - O(N) */
/* Return value: SUCCESS - 0, FAILURE - 1*/
int SCHRemoveTask(sch_t *sch, uniqid_t uid)
{
	task_t *task = NULL;
	
	/*assert(sch && !UIDIsBad(&uid));
	*/
	task = PQErase(sch->task_list, &AreEqual, &uid);

	if (NULL == task)
	{
		return FAIL;
	}
	
	TaskDestroy(task);
	
	return SUCCESS; 
}

/* Compexity - O(N) */
/* Returns FAIL - 1 if a task failed or stop_flag is not on. Else, returns SUCCESS - 0 */
int SCHRun(sch_t *sch)
{
	assert(sch);

	while(0 == sch->stop_flag && 0 == SCHIsEmpty(sch))
	{
		task_t *task = NULL;
		task = PQDequeue(sch->task_list);

		if (NULL == task) 
		{
			return FAIL;
		}

		sleep(TaskGetActTime(task) - time(NULL));

		if (1 == TaskRun(task))
		{
			return FAIL;
		}
		
		TaskTimeUpdate(task);

		if (TaskGetActTime(task) > time(NULL))      /* Checks if period in sec is 0 - do not insert task again to the queue */ 
		{
			 PQEnqueue(sch->task_list, task);
		}
		else
		{
			TaskDestroy(task);
		}
	}

	return (!sch->stop_flag ? FAIL : SUCCESS);      /*  If while loop did not run - FAIL . Else - SUCCESS */ 
}

/* Compexity - O(1) */
void SCHStop(sch_t *sch)
{
	assert(sch);

	sch->stop_flag = 1;
}

/* Compexity - O(N) */
void ClearAllTasks(sch_t *sch)
{
	task_t *task = NULL;
	assert(sch);

	while (!PQIsEmpty(sch->task_list))
	{
		task = PQDequeue(sch->task_list);
		
		TaskDestroy(task);
	}
}

/* Compexity - O(1) */
static int IsBefore(const void *data1, const void *data2, void *param)
{
	UNUSED(param);
	
	return (TaskGetActTime((task_t *)data1) <= TaskGetActTime((task_t *)data2));
}

/* Compexity - O(1) */
static int AreEqual(const void *val, void *param)
{	
	assert(val);

	return TaskIsSame((task_t *)val, (task_t *)param);
}

