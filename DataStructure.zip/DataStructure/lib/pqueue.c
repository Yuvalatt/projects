#include "../include/pqueue.h"
#include "../include/sortedlist.h"

#include <assert.h>  /* assert */

struct pqueue
{
	sorted_list_t *list;
};

/***********************  Complexity O(1)  ***********************************/
pq_t *PQCreate(pq_is_before_t is_before, void *param)
{
	pq_t *pqueue = NULL;
	assert(is_before);

	pqueue = malloc(1 * sizeof(pq_t));

	if(NULL == pqueue)
	{
		return NULL;
	}
	
	pqueue->list = SortedListCreate(is_before, param);
	
	if (NULL == pqueue->list)                      
	{
		free(pqueue);
		return NULL;
	}

	return pqueue;
}
/***********************  Complexity O(N)  ***********************************/
void PQDestroy(pq_t *pqueue)
{
	assert(pqueue);

	SortedListDestroy(pqueue->list);
	free(pqueue);
	pqueue = NULL;
}
/***********************  Complexity O(N)  ***********************************/
size_t PQSize(const pq_t *pqueue)
{
	assert(pqueue);

	return (SortedListSize(pqueue->list));
}
/***********************  Complexity O(1)  ***********************************/
/* return value empty - 1, not empty - 0 */

int PQIsEmpty(const pq_t *pqueue)
{
	assert(pqueue);

	return (SortedListIsEmpty(pqueue->list));
}
/***********************  Complexity O(N)  ***********************************/
/*   SUCCESS - 0, FAILURE (malloc) - 1 	 */

int PQEnqueue(pq_t *pqueue, void *data)
{
	assert(pqueue);

	return (SortedListIsSameIter(SortedListInsert(pqueue->list, data), SortedListEnd(pqueue->list)));
} 
	
/***********************  Complexity O(1)  ***********************************/
/*   Do not perform on an empty queue 	 */

void *PQDequeue(pq_t *pqueue)
{
	assert(pqueue);

	if (PQIsEmpty(pqueue))
	{
		return NULL;
	}

	return (SortedListPopFront(pqueue->list));
}			 	
/***********************  Complexity O(1)  ***********************************/
/*   Do not perform on an empty queue 	 */

void *PQPeek(const pq_t *pqueue)
{
	assert(pqueue);

	if (PQIsEmpty(pqueue))
	{
		return NULL;
	}
	
	return (SortedListGetData(SortedListBegin(pqueue->list)));
} 			
/***********************  Complexity O(N)  ***********************************/
void *PQErase(pq_t *pqueue, pq_cmp_func_t CmpFunc, void *param)  /* Removed data. param represents the required data to erase */
{
	sorted_list_iter_t iter = NULL;
	void *data = 0;

	assert(pqueue && CmpFunc);

	if (PQIsEmpty(pqueue))
	{
		return NULL;
	}

	iter = SortedListFind(pqueue->list, SortedListBegin(pqueue->list), SortedListEnd(pqueue->list), CmpFunc, param);

	if (SortedListEnd(pqueue-> list) == iter)
    {
        return NULL;
    }

	data = SortedListGetData(iter);
 	
	SortedListErase(iter);
	
	return data;
}
/***********************  Complexity O(N)  ***********************************/
void PQClearAll(pq_t *pqueue)
{
	assert(pqueue);

	while (!PQIsEmpty(pqueue))
	{
		PQDequeue(pqueue);
	}	
}
