#include "../include/uid.h"
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/time.h>
#include <time.h>

/* For testing */
#include <assert.h>
#include <stdio.h>

static size_t counter;

uniqid_t UIDCreate(void)
{
	uniqid_t uid = {0};
	int status = 0;
	++counter;

	uid.counter = counter;
	uid.pid = getpid();	
	status = gettimeofday(&uid.time, NULL);

	if (0 != status)
	{
		return UIDGetBad();
	}

	return uid;
}

int UIDIsSame(const uniqid_t *uid1, const uniqid_t *uid2)
{
	assert(uid1 && uid2);

	return (uid1->counter == uid2->counter && uid1->pid == uid2->pid);
}

int UIDIsBad(const uniqid_t *uid)
{
	assert(uid);
	
	return (-1 == uid->pid);
}

uniqid_t UIDGetBad(void)
{
	uniqid_t bad_uid = {0};
	
	bad_uid.pid = -1;
	
	return bad_uid;
}


