#include <assert.h>
#include "../include/heap.h"
#include "../include/dynvec.h"
							/* CR: improve spacing in all file ! */
 struct heap
 {
     dv_t *dvec;
     heap_cmp_func_t cmp_func;
     const void *param;
 };

heap_t *HeapCreate(heap_cmp_func_t cmp_func, const void *param)
{
    heap_t *heap = malloc(1 * sizeof(heap_t));
    if(NULL == heap)
    {
        return NULL;
    }
    heap->dvec = DVCreate(1, sizeof(void *));
    if(NULL == heap->dvec)
    {
        free(heap);
        return NULL;
    }
    heap->cmp_func = cmp_func;				/* CR: add a space line...  */
    heap->param = param;
    return heap;
}

void HeapDestroy(heap_t *heap)
{
    assert(heap && heap->dvec);

    DVDestroy(heap->dvec);
    heap->dvec = NULL;
    free(heap);
    heap = NULL;
}

size_t HeapSize(const heap_t *heap)
{
    assert(heap && heap->dvec);

    return DVSize(heap->dvec) - 1; 			/* CR: add () */
}

int HeapIsEmpty(const heap_t *heap)			/* return value empty - 1, not empty - 0 */
{
    assert(heap && heap->dvec);

    return (0 == DVSize(heap->dvec) -1);		/* CR: could be return (1 == DVSIZE) */	
}
static void Swap(void **data1, void **data2)		/* CR: add a space line between funcs  */
{
    void *temp = *data1;
    *data1 = *data2;
    *data2 = temp;
}
static void HeapifyDown(heap_t *heap, size_t index)
{
    size_t largest_index = index;
    size_t left_index = index * 2;
    size_t right_index =  (index * 2) + 1;
    void **left_child = NULL;
    void **parent = NULL;
    void **largest = NULL;
    void **right_child = NULL;
									/* CR: extra space lines..  */

    parent  = DVGetItemAddress(heap->dvec, index);
   
    if (left_index <= HeapSize(heap))
    {   
        left_child = DVGetItemAddress(heap->dvec, left_index);
        if (0 < heap->cmp_func(*left_child,*parent, heap->param ))
        {
             largest_index = left_index;
        }    
    }
    if (right_index <= HeapSize(heap))
    {    
        right_child = DVGetItemAddress(heap->dvec,right_index);
        largest = DVGetItemAddress(heap->dvec, largest_index);
        if (0 < heap->cmp_func(*right_child,*largest, heap->param))
        {
            largest_index = right_index;
        }

        								/* CR: extra space lines..  */
    }
    
    if (largest_index != index)
    {
        largest = DVGetItemAddress(heap->dvec, largest_index);
        Swap(largest, parent); 
        HeapifyDown(heap, largest_index);
    }

}																/* CR: add a space line  */
static void HeapifyUP(heap_t *heap, size_t index)
{
    void **parent = NULL;
    void **child = NULL;

    if(1 == index)
    {
        return;
    }

    parent = DVGetItemAddress(heap->dvec,index / 2);
    child = DVGetItemAddress(heap->dvec, index);

    if ( 0 < heap->cmp_func(*child, *parent , heap->param))
    {

        Swap(child, parent);
    }
    else
    {
    	return;
    }

    HeapifyUP(heap,index / 2);
}
heap_stat_t HeapPush(heap_t *heap, void *data)
{
    size_t index = 0;

    assert(heap && heap->dvec);

    index = DVSize(heap->dvec);
    if (1 == DVPushBack(heap->dvec, &data))						/*Failure */   
    {
        return HEAP_MALLOC_FAILURE;
    }
    if (DVSize(heap->dvec) > 1)								/* CR: I think you check it anyway in your heapifyup func, you can change stop condition to if (1 => index)  */   
    {
    	HeapifyUP(heap,index);
    }


    return HEAP_SUCCESS;
}

void *HeapPop(heap_t *heap)
{
    void **root = NULL;
    void *root_data = NULL;
    void **leaf = NULL;

    assert(heap && heap->dvec);
    root = DVGetItemAddress(heap->dvec, 1);
   
    root_data = *root;

    leaf = DVGetItemAddress(heap->dvec, HeapSize(heap));

    Swap(root, leaf);
    DVPopBack(heap->dvec);
    if (HeapSize(heap) > 0)									/* CR: I think you check it anyway in your heapifydown func  */   
    {
          HeapifyDown(heap, 1);
    }
  
  
    return root_data;


}

void *HeapPeek(const heap_t *heap) 	/*   Do not perform on an empty heap  */
{
     void **address = NULL;

     assert(heap && heap->dvec && (HeapSize(heap) > 0));

     address = DVGetItemAddress(heap->dvec, 1);

     return *address;

}
void *HeapRemove(heap_t *heap, heap_find_t find_func, void *data_to_remove, void *param)
{
    size_t index = 0;
    void *data = NULL;
    void **leaf = NULL;
    void **node_found = NULL;

    assert(heap && heap->dvec && find_func && (HeapSize(heap) > 0));

    for (index = 1 ; index <= HeapSize(heap); ++index )					/* CR: spaces */		
    {
        
        node_found = DVGetItemAddress(heap->dvec, index);
        if (find_func(*node_found, data_to_remove , param))
        {																/* CR: better add this line inside this if: data = *node_found; */	
           break;
        }
    }
  
    if (index >  HeapSize(heap)) /* not found*/
    {
    	return NULL;
    }
   
    data = *node_found;
   
    leaf = DVGetItemAddress(heap->dvec, HeapSize(heap));    
    Swap(node_found, leaf);

    DVPopBack(heap->dvec);
    if (HeapSize(heap) > 1 )										/* CR: spaces */
    {
        HeapifyDown(heap, 1);
        
        index = (index > HeapSize(heap)) ? HeapSize(heap) : index;
        HeapifyUP(heap, index);

    }

    return data;

}
