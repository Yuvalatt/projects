#include  "../include/fsm.h"
#include <assert.h>  /* assert */

#define META_SIZE 8
#define WORD_SIZE 8

static size_t FSMGetBlockSize(size_t block_size);
static void Swap(size_t *size1, size_t *size2);
static void InitMetaData(fsm_t *fsm);
static int IsValidPtr(void *ptr, fsm_t *fsm);
static int IsValidOffset(void *ptr, fsm_t *fsm);

struct fsm
{
	size_t block_size;
	size_t num_of_blocks;
	size_t next_free;     /* Offset of the next free block */
};

/***********************  Complexity O(1)  ***********************************/
size_t FSMSuggestSize(size_t num_of_elements, size_t block_size)
{
	assert(num_of_elements && block_size);

	return (num_of_elements * FSMGetBlockSize(block_size) + sizeof(fsm_t));
}

/***********************  Complexity O(1)  ***********************************/
static size_t FSMGetBlockSize(size_t block_size)
{
	size_t calc_block = 0;
	size_t remainder = 0;
	assert(block_size);

	calc_block = block_size + META_SIZE;
	remainder = calc_block % WORD_SIZE;

	return ((0 == remainder) ? calc_block : calc_block + (WORD_SIZE - remainder));
}

/***********************  Complexity O(n)  ***********************************/
fsm_t *FSMInit(void *mem_ptr, size_t mem_size, size_t block_size)    
{
	fsm_t *fsm = NULL;
	size_t fsm_size = 0;

	assert(mem_ptr);
	fsm_size = sizeof(fsm_t);

	fsm = mem_ptr;
	fsm->block_size = FSMGetBlockSize(block_size);
	fsm->num_of_blocks = (mem_size - fsm_size) / fsm->block_size;
	fsm->next_free = fsm_size;

	InitMetaData(fsm);
	
	return fsm;
}

/***********************  Complexity O(1)  ***********************************/
void *FSMAlloc(fsm_t *fsm)
{	
	char *alloc_block = NULL;
	assert(fsm);
	
	if (0 == fsm->next_free)
	{
		return NULL;
	}	

	alloc_block = (char *)fsm + fsm->next_free;     /* move from base in the offset of the next free block */
	Swap((size_t *)alloc_block, &fsm->next_free);   /* swap meta data & control unit next free */ 
	
	return (alloc_block + META_SIZE);
}

/***********************  Complexity O(1)  ***********************************/
void FSMFree(void *ptr)
{
	fsm_t *fsm = NULL;
	char *block_ptr = NULL;

	assert(ptr);
	
	block_ptr = (char *)ptr - META_SIZE;	
	fsm = (fsm_t *)(block_ptr - *(size_t *)block_ptr);

	assert(IsValidPtr(block_ptr, fsm) && IsValidOffset(block_ptr, fsm));

	Swap((size_t *)block_ptr, &fsm->next_free);	 	
}

/***********************  Complexity O(n)  ***********************************/
size_t FSMCountFree(const fsm_t *fsm)
{
	size_t free_cnt = 0;
	size_t offset = 0;
	assert(fsm);	
	offset = fsm->next_free;

	while (0 != offset)
	{			
		++free_cnt;	
		offset = *(size_t *)((char *)fsm + offset);
	}

	return free_cnt;
}

/***********************  Complexity O(n)  ***********************************/
static void InitMetaData(fsm_t *fsm)
{
	size_t blocks_ctr = 0;
	char *runner = NULL;
	assert(fsm);

	runner = (char *)fsm + fsm->next_free;
	
	while(blocks_ctr < fsm->num_of_blocks - 1)
	{
		*(size_t *)runner = (size_t)(runner + fsm->block_size - (char *)fsm); 
		++blocks_ctr;
		runner = runner + fsm->block_size;
	}
	*(size_t *)runner = 0;  /* last block meta data */
}

/***********************  Complexity O(1)  ***********************************/
static void Swap(size_t *size1, size_t *size2)
{
	size_t temp = *size1;
	*size1 = *size2;
	*size2 = temp; 
}

/***********************  Complexity O(1)  ***********************************/
static int IsValidPtr(void *ptr, fsm_t *fsm)
{
	return (0 == (size_t)ptr % WORD_SIZE &&
		  (char *)ptr >= (char *)fsm  &&
		  (char *)ptr <= (char *)(fsm + fsm->block_size * fsm->num_of_blocks));
}

/***********************  Complexity O(1)  ***********************************/
static int IsValidOffset(void *ptr, fsm_t *fsm)
{
	return ((0 == (*(size_t *)ptr - sizeof(fsm_t)) % fsm->block_size) &&
		   *(size_t *)ptr <= sizeof(fsm_t) + (fsm->block_size * (fsm->num_of_blocks - 1)));
}

