#include <stdio.h>
#include <stdlib.h> /*EXIT_SUCCESS*/
#include <assert.h> /*For testing*/

#define BIT0 0x1
#define BIT6 (1<<6)
#define BIT2 (1<<2)
#define BIT3 (1<<3)
#define BIT5 (1<<5)

static unsigned char SwapBits(unsigned char a);
static unsigned int DividedBy16(unsigned int num);
static void Swap(unsigned int *num1, unsigned int *num2);
static int CountSetLoop(unsigned int num);
static int CountSet(unsigned int num);
static int BothOn(unsigned char a);
static int AtLeastOneOn(unsigned char a);
static void PrintFloat(float num);

static void TestBothOn(void);
static void TestAtLeastOneOn(void);
static void TestSwapBits(void);
static void TestSwap(void);
static void TestDividedBy16(void);
static void TestCountSet(void);
static void TestPrintFloat(void);


int main()
{
	TestBothOn();
	TestAtLeastOneOn();
	TestSwapBits();
	TestSwap();
	TestCountSet();
	TestDividedBy16();
	TestPrintFloat();

	return EXIT_SUCCESS;
}

/* Swaping bits 3 and 5 */
static unsigned char SwapBits(unsigned char a)
{	
	unsigned char b = a;
	a = (a & (~BIT3 & ~BIT5)); /* Turning off bit 5 and bit 3 */
	b = ((b >> 2) & 0x8) | ((b << 2) & 0x20);
    return (a | b); 
}

/* check if bit 2  &  bits 6 are on */
static int BothOn(unsigned char a)
{
	return ((a & BIT6) && (a & BIT2)); 
}

/* check if bit 2 or bits 6 (or both) are on */
static int AtLeastOneOn(unsigned char a)
{
	return ((a & BIT6) || (a & BIT2)); 
}

/* Returns the closest number to num which is a devision of 16 */
static unsigned int DividedBy16(unsigned int num) 
{	
	num >>= 4;
	num <<= 4;
	return (num);
}

/* Returns the number of set(on) bits in a number */
static int CountSetLoop(unsigned int num) 
{
	int count = 0;
	/* Better version */
	while (num > 0)
	{
		num &= (num - 1);
		++count;
	}
	/*while (0 != num)
	{
		if (1 == (num & BIT0))
		{
			count++;
		}
		num >>= 1;
 	}*/
 	return count;
}

/* Returns the number of set(on) bits in a number */
static int CountSet(unsigned int x) 
{
 /* Sums up pairs of bits and  double shifting in each step */
	x = ((x >> 1) & 0x55555555) + (x & 0x55555555);
	x = ((x >> 2) & 0x33333333) + (x & 0x33333333);
	x = ((x >> 4) & 0x0f0f0f0f) + (x & 0x0f0f0f0f);
	x = ((x >> 8) & 0x00ff00ff) + (x & 0x00ff00ff);
	x = ((x >> 16) & 0x0000ffff) + (x & 0x0000ffff);
	
	return x;
}

static void Swap(unsigned int *num1, unsigned int *num2)
{
	*num1 = *num1 ^ *num2;
	*num2 = *num1 ^ *num2;
	*num1 = *num1 ^ *num2;
}

static void PrintFloat(float num) /* Prints the binary value of a float num */
{
	unsigned int *ui_ptr = (unsigned int *) &num;
	int i = 31;
	
	for (i = 31; 0 <= i; i--) 
	{
	    /* Prints each bit by a mask of bit in place i, shifting it to the rightmost bit */
	    
		printf("%d ", ((*ui_ptr & (1 << i)) >> i));    /* >>i  returns either 0 or 1 */ 	
	}
	
	puts("");
}

/**************** TESTS **********************/

static void TestBothOn()
{
	assert(1 == BothOn(255));
	assert(1 == BothOn(68));
	assert(0 == BothOn(61));
	
	puts("TestBothOn - SUCCESS\n");
}

static void TestAtLeastOneOn()
{
	assert(1 == AtLeastOneOn(68));
	assert(1 == AtLeastOneOn(4));
	assert(0 == AtLeastOneOn(59));
	
	puts("TestAtLeastOneOn - SUCCESS\n");
}

static void TestSwapBits()
{
	assert(48 == SwapBits(24));
	assert(169 == SwapBits(169));
	assert(48 == SwapBits(24));
	assert(32 == SwapBits(8));
	
	puts("TestSwapBits - SUCCESS\n");
}

static void TestSwap()
{
	unsigned int a = 6;
	unsigned int b = 7;
	
	printf("Before swap: [%u,%u] \n\n", a, b);
	Swap(&a, &b);
	printf("After swap: [%u,%u] \n\n", a, b);
}

static void TestDividedBy16()
{
	assert(16 == DividedBy16(22));
	assert(32 == DividedBy16(35));
	assert(80 == DividedBy16(82));
	assert(0 == DividedBy16(14));
	
	puts("TestDividedBy16 - SUCCESS\n");
}

static void TestCountSet()
{
	assert(3 == CountSetLoop(7));
	assert(3 == CountSet(7));
	puts("TestCountSet - SUCCESS\n");
}

static void TestPrintFloat()
{
	PrintFloat(1.25);
	puts("");
	PrintFloat(4.5);
	puts("");
	PrintFloat(3);
}


