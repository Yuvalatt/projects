#include <stdio.h>
#include <stdlib.h> /*EXIT_SUCCESS*/

#define ARRAY_SIZE(arr)(sizeof(arr)/sizeof(arr[0])) 
#define BYTE_SIZE 8
#define BIT0 0x1

static double Pow2(unsigned int x, int y);
static int IsPowOf2Loop(unsigned int num);
static int IsPowOf2(unsigned int num);
static unsigned int Add1(unsigned int x, unsigned int y);
static void ThreeBitsOn(unsigned int arr[], size_t size);
static unsigned int ByteMirrorLoop(unsigned int num);
static unsigned int ByteMirror(unsigned int num);


static void TestPow2(unsigned int num, unsigned int y);
static void TestAdd1(unsigned int y);
static void TestIsPowOf2Loop(unsigned int y);
static void TestIsPowOf2(unsigned int num);
static void TestByteMirrorLoop(unsigned int num);
static void TestByteMirror(unsigned int num);

	

int main()
{	
	unsigned int arr[] = {1, 3, 7, 9, 12, 14};

	ThreeBitsOn(arr, ARRAY_SIZE(arr));
	TestPow2(3, -1);
	TestIsPowOf2Loop(0);
	TestIsPowOf2(0);
	TestIsPowOf2Loop(1);
	TestIsPowOf2(1);
	TestAdd1(3);
	TestByteMirrorLoop(128);
	TestByteMirror(128);

	return EXIT_SUCCESS;
}

static unsigned int ByteMirrorLoop(unsigned int num) /* Returns a number which is a bit mirror of num */
{
	int i = 0;
	unsigned int mirror = 0;
	
	for (i = 0; i < BYTE_SIZE ; i++) 
	{
		mirror <<= 1;
		mirror |= (num & 1);
		num >>= 1; 
	}
	
	return mirror;
}


static unsigned int ByteMirror(unsigned int num) /*Use shifting and masking to replace bits*/ 
{
	num = (((num >> 4) & 0x0F) | ((num << 4) & 0xF0)); /* replace 4 bits */
	num = (((num >> 2) & 0x33) | ((num << 2) & 0xCC)); /* replace 2 bits */
	num = (((num >> 1) & 0x55) | ((num << 1) & 0xAA)); /* replace 1 bits */
	
	return num;
}


static void ThreeBitsOn(unsigned int arr[], size_t size) /*Prints numbers of array that has 3 bits on*/ 
{
	size_t i = 0;
	int count = 0;
	unsigned int num = 0;
	
	for(i = 0; i < size; i++)
	{
		count = 0;
		
		num = arr[i];
		
		while ((0 != num) && (count <= 3))
		{
			if (1 == (num & BIT0))
			{
				count++;
			}
			num >>= 1;
		}
		
		if (3 == count)
		{
			printf("Number %u has 3 bits on\n", arr[i]); 
		}	
	}
}


static int IsPowOf2Loop(unsigned int num)
{
	unsigned int i = 0;
	unsigned int n = 1; 
	
	for (i = 0; i < num; i++)
	{
		if ((n <<= 1) == num)
		{
			return 1;
		} 
	}
	
	return (1 == i) ? 1 : 0;
}


static int IsPowOf2(unsigned int num)
{
	return ((0 == (num & (num - 1)) && (num != 0) ? 1 : 0));
}


static unsigned int Add1(unsigned int x, unsigned int y)
{
	unsigned int carry = 0;
	
    while (y != 0)
    {
        carry = x & y;
        x = x ^ y; 
        y = carry << 1;
    }  
      
    return x;
}



static double Pow2(unsigned int x, int y)
{
	return ( (0 <= y) ? (x << y) : (x >> (-y)));
}


/**************** Testing ****************************/

static void TestPow2(unsigned int num, unsigned int y)
{
	printf("\nResult is: %f \n\n", Pow2(num,(unsigned int)y));
}

static void TestAdd1(unsigned int y)
{
	printf("%d + 1 = is: %u \n\n", y, Add1(y,1));
}

static void TestIsPowOf2Loop(unsigned int y)
{
	printf("Is pow of 2? : %d \n", IsPowOf2Loop(y));
}

static void TestIsPowOf2(unsigned int num)
{
	printf("Is pow of 2? %d \n\n", IsPowOf2(num));
}

static void TestByteMirrorLoop(unsigned int num)
{
	printf("Mirror of %u is %u\n", num, ByteMirrorLoop(num));
}

static void TestByteMirror(unsigned int num)
{
	printf("Mirror of %u is %u\n\n", num, ByteMirror(num));
}


