#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

float t = 14.6;
extern char c;
int r = 0;
const char u = 'U';

int AddToSum(int x, int y)
{
	static int a = 8;
	return (a + y + x);
}


extern double SumDivision(int n1, int n2);

int main(int argc, char **argv, char **envp)
{
  int j = 12;
  int b = 0;
  const int x = 200;
  static int v = 5;
  char *str = malloc(3 * sizeof(char));
  int *m1 = malloc(5 * sizeof(int));
  int *m2 = malloc(5 * sizeof(int));

  FILE *fp;

  if(0 == (fp = fopen("file1", "w")))
    {
      printf("well, that didn\'t work!\n");
      return -1;
    }
  
	fprintf(fp, "----------------- Stack - Local variables --------------------\n");
	fprintf(fp, "Local int address: %p\n", &j);
	fprintf(fp, "Local int address: %p\n", &b);
	fprintf(fp, "Local int address: %p\n\n", &x);

	fprintf(fp, "----------------- Heap - Dynamic allocation --------------------\n");
	fprintf(fp, "Heap address: %p\n", str);
	fprintf(fp, "Heap address: %p\n", m1);
	fprintf(fp, "Heap address: %p\n\n", m2);
	
	fprintf(fp, "----------------- Data - Static variables --------------------\n");

	fprintf(fp, "----------------- BSS Variables --------------------\n");
	fprintf(fp, "Bss variable address: %p\n\n", &r);

	fprintf(fp, "----------------- Global Variables --------------------\n");
	fprintf(fp, "Global variable address: %p\n\n", &c);

	fprintf(fp, "Static variable (in function) address: %p\n", &v);
	fprintf(fp, "Static variable address: %p\n\n", &t);
	
	fprintf(fp, "----------------- Const (RO) Variables --------------------\n");
	fprintf(fp, "Const variable address: %p\n\n", &u);

	fprintf(fp, "----------------- Code (Text) - Functions --------------------\n");
	fprintf(fp, "Global function address: %p\n", SumDivision);
	fprintf(fp, "Static function address: %p\n\n", AddToSum);

  if(fclose(fp))
    {
      printf("oh well.");
      return -1;
    }

  return 0;
}

