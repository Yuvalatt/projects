#include <stdio.h>
#include <stdlib.h> /* EXIT_SUCCESS */



int main(void)
{
	printf("Size of %s is: %d\n", "char", (int)sizeof(char));
	printf("Size of %s is: %d\n", "unsigned char", (int)sizeof(unsigned char));
	printf("Size of %s is: %d\n", "int", (int)sizeof(int));
	printf("Size of %s is: %d\n", "unsigned int", (int)sizeof(unsigned int));
	printf("Size of %s is: %d\n", "float", (int)sizeof(float));
	printf("Size of %s is: %d\n", "double", (int)sizeof(double));
	printf("Size of %s is: %d\n", "short", (int)sizeof(short));
	printf("Size of %s is: %d\n", "unsigned short", (int)sizeof(unsigned short));
	printf("Size of %s is: %d\n", "long", (int)sizeof(long));
	printf("Size of %s is: %d\n", "unsigned long", (int)sizeof(unsigned long));
	printf("Size of %s is: %d\n", "int *", (int)sizeof(int *));
	printf("Size of %s is: %d\n", "int **", (int)sizeof(int **));
	printf("Size of %s is: %d\n", "char *", (int)sizeof(char *));
	printf("Size of %s is: %d\n", "char **", (int)sizeof(char **));
	
	return EXIT_SUCCESS;
}

