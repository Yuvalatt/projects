#include <stdio.h>
#include <assert.h>
#include <ctype.h> /* tolower() */
#include <string.h> /* strlen() */
#include <stdlib.h> /* EXIT_SUCCESS */
#define UNUSED(x)(void)(x)

static char ** DupEnv(char **env);
static void PrintLowerEnv(char **env);
static char * Lower(char *str);
static int  Count(char **env);
static void CleanUp(char **copy);


int main(int argc, char *argv[], char *env[])
{
	char **buffer= NULL;
	
	UNUSED(argc);
	UNUSED(argv);
	
	printf("Number of arguments in ENV is: %d\n", Count(env));
	
	buffer = DupEnv(env);
	if (buffer != NULL)
	{
		printf("Number of arguments in BUFFER is: %d\n", Count(buffer));
		PrintLowerEnv(buffer);
		CleanUp(buffer);		
		buffer = NULL;
	}
	
	return EXIT_SUCCESS;
}

static int Count(char **env) 
{
	int count = 0;
	assert(env);
	while (NULL != *env)
	{
		count++;
		env++;
	}
	return count;
}

static char ** DupEnv(char **env)
{
	char **buff =NULL;
	char **buff_origin = NULL;
	
	assert(env);
	
	buff = (char **) malloc((Count(env) + 1) * sizeof(*buff));
	
	buff_origin = buff; /*define buff runner*/
	
	if (NULL != buff)
	{
		while (NULL != *env) 
		{
			*buff= (char *) malloc((strlen(*env) + 1) * sizeof(**buff)); 
			 
			if(NULL != *buff)
			{
				strcpy(*buff, *env);
			}
			else
			{
				CleanUp(buff_origin);
				return NULL;
			}
			env++;
			buff++;
			
		}
	}
	else
	{
		return NULL;
	}

	return buff_origin;	
}

/* Gets a string and returns it in lower case letters*/
static char * Lower(char *str)
{
	char *s = str;
	while ('\0' != *str)
		{
			*str=tolower(*str);
			str++;
		}
	return s;
}

static void PrintLowerEnv(char **env)
{
	assert(env);
	
	while (NULL != *env)
	{
		printf("%s\n", Lower(*env));
		env++;
	}
}

static void CleanUp(char **copy)  
{
	char **copy_origin = copy;
	int i = 0;
	while (NULL != *copy) 
	{
		free(*copy);
		copy++;
		i++;
	}
	
	free(copy_origin);
}
