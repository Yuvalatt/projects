#include <stdio.h>
#include <stdlib.h> /* EXIT_SUCCESS */

int Flavious(int soldiers_num);

	 
int main()
{
	int num;	
	printf("Please enter number of soldiers:\n");
	scanf("%d",&num);	
	printf("Luckiest soldier is soldier number %d!\n", Flavious(num));
	
	return EXIT_SUCCESS;
}

int Flavious(int soldiers_num)
{						
	int i = 0;
	int *circle = (int *)calloc(soldiers_num , sizeof(int));

	if (circle == NULL)
	{ 
		puts("FAILED");
	}
	else
	{
		for (i = 0; i < soldiers_num-1; i++)
		{
			circle[i]= i + 1;
		}
	
		circle[i] = 0;
		i = 0;
		
		while (i != circle[i])
		{
			circle[i] = circle[circle[i]];
			i = circle[i]; 
		}
	
		free(circle);
		circle = NULL;
	}
	return (i+1);
}
