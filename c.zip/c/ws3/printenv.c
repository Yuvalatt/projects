#include <stdio.h>
#include <assert.h>
#include <ctype.h> /* tolower() */
#include <stdlib.h> /* EXIT_SUCCESS */
#define UNUSED(x)(void)(x)

void PrintEnv(char **env);

int main(int argc, char *argv[], char *env[])
{
	UNUSED(argc);
	UNUSED(argv);
	PrintEnv(env);
	PrintEnv(env);
	
	return EXIT_SUCCESS;
}


void PrintEnv(char **env)
{
	assert(env);
	
	while (NULL != *env) /*Run until a char pointer is NULL*/
	{
		printf("%s\n", *env);
		env++;
	}

}

