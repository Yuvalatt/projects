#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define UNUSED(x) (void)(x)
#define BUFFER_SIZE 256

static int IsCmdMatch(const char *cmd_to_match, const char *cmd);
static int IsPrepend(const char *cmd_to_match, const char *cmd);
static int IsAppend(const char *cmd_to_match, const char *cmd);

/*
enum status {OK, FAIL};

typedef enum status status_t; 
*/

typedef enum {OK, FAIL} status_t; 

static status_t Append(const char *fname, const char *txt);
static status_t Remove(const char *fname, const char *txt);
static status_t Count(const char *fname, const char *txt);
static status_t Prepend(const char *fname, const char *txt);
static status_t Exit(const char *fname, const char *txt);

typedef	int (*CmpFunc_t)(const char *, const char *);

struct cmd
{
	const char *cmd_to_match;
	CmpFunc_t CmpFunc;
	status_t (*OptFunc)(const char *, const char *);
};

struct cmd cmd_arr[] = {
							{"-remove\n", IsCmdMatch, Remove}, 
							{"-count\n", IsCmdMatch, Count}, 
							{"-exit\n", IsCmdMatch, Exit}, 
							{"<", IsPrepend, Prepend},
						/* Append is the default - must be last! */
							{NULL, IsAppend, Append}
																};

int main(int argc, char *argv[])
{
	int i = 0;
	
	static char buffer[SIZE] = {0};

	if (2 > argc)
	{
		bad !!!!
	}
	
	while (1)
	{
		fgets(buffer, SIZE, stdin);
		
		for (i = 0 ; i < sizeof(cmd_arr)/sizeof(cmd_arr[0]) ; i++)
		{
			if (cmd_arr[i].CmpFunc(cmd_arr[i].cmd_to_match, buffer))
			{
				cmd_arr[i].OptFunc(argv[1], buffer);
				break;
			}
		}
	}
	
	return EXIT_SUCCESS;
}

static int IsCmdMatch(const char *cmd_to_match, const char *cmd)
{
	return (0 == strcmp(cmd_to_match, cmd));
}

static int IsPrepend(const char *cmd_to_match, const char *cmd)
{
	return (*cmd_to_match == *cmd);
}

static int IsAppend(const char *cmd_to_match, const char *cmd)
{
	return (1);
}

static int Append(const char *fname, const char *txt)
{
	FILE *file_ptr = fopen(fname, "a");
	if (NULL == file_ptr)
	{
		puts("failed to load file");
		return EXIT_FAILURE;
	}
	
	fputs(txt, file_ptr);
	fclose(file_ptr);
	
	return EXIT_SUCCESS;
}

static int Remove(const char *fname, const char *txt)
{
	int check = 0;
	
	check = remove(fname);
	
	if (-1 == check)
	{
		puts("failed to remove file");
		return EXIT_FAILURE;
	}
	
	return EXIT_SUCCESS;
}

static int Count(const char *fname, const char *txt)
{
	size_t counter = 0;
	int curr_char = 0;
	
	FILE *file_ptr = fopen(fname, "r");
	if (NULL == file_ptr)
	{
		puts("failed to load file");
		return EXIT_FAILURE;
	}
	
	curr_char = fgetc(file_ptr);
	
	while (EOF != curr_char)
	{
		if ('\n' == curr_char)
		{
			counter++;
		}
		curr_char = fgetc(file_ptr);
	}
	
	printf("number of lines in the file: %lu\n", counter);
	fclose(file_ptr);
	
	return EXIT_SUCCESS;
}

static int Prepend(const char *fname, const char *txt)
{
	FILE *tmp_file_ptr = NULL;
	FILE *file_ptr = NULL;
	int ch = 0;
	
	file_ptr = fopen(fname, "r");
	if (NULL == file_ptr)
	{
		puts("failed to load file");
		return EXIT_FAILURE;
	}
	
	/* better use: standard call to get a temp file name */
	tmp_file_ptr = fopen("./tmp.txt", "a");		/* opening a tmp file */
	if (NULL == tmp_file_ptr)
	{
		puts("failed to prepend file");
		return EXIT_FAILURE;
	}
	
	fputs(txt + 1, tmp_file_ptr);			/* prepending the text (skip first char)*/
	
	ch = fgetc(file_ptr);
	
	while (EOF != ch)					/* appending the sent file */
	{
		fputc(ch, tmp_file_ptr);
		ch = fgetc(file_ptr);
	}
	
	fclose(file_ptr);
	fclose(tmp_file_ptr);
	
	ch = rename("tmp.txt", fname);		/* rename overwrites the file */
	if (-1 == ch)
	{
		puts("failed to prepend file");
		return EXIT_FAILURE;
	}
	
	return EXIT_SUCCESS;
}

static int Exit(const char *fname, const char *txt)
{
	exit(EXIT_SUCCESS);
}
