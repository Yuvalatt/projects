#include <stdio.h>
#include <string.h> /* strcmp() */
#include <stdlib.h> /* exit()  */


#define ARRAY_SIZE 5 /* Array size of commands */
#define MAX_INPUT 256  /* Max size of users input */
#define UNUSED(x)(void)(x)


static int Append(const char *str, const char *fname);
static int Prepend(const char *str, const char *fname);
static int Remove(const char *str, const char *fname);
static int Count(const char *str, const char *fname);
static int Exit(const char *str, const char *fname);

static int Compare(const char *cmd, const char *cmd_to_match);
static int CompareAppend(const char *cmd, const char *cmd_to_match);
static int ComparePrepend(const char *cmd, const char *cmd_to_match);


enum status{OK = 1, FAILED = 0};

/********************************************************************************/

static int Append(const char *str, const char *fname)
{
	FILE *fptr = fopen(fname, "a");
	int status = 0;
	
	if (NULL == fptr)
	{
 	  puts("Error! opening file");
 	  return FAILED;
	}
	else
	{
		status = fputs(str, fptr);
		fclose(fptr);
	}
	
	return (EOF != status) ? OK : FAILED;
}

/*********************************************************************************/

static int Prepend(const char *str, const char *fname)
{
	int status = 0;
	FILE *fptr = fopen(fname, "r");
	FILE *temp = fopen("temp.txt", "w");
	
	if (NULL == fptr)
	{
 	  puts("Error! opening file");
 	  return FAILED;
	}
	else if (NULL == temp)
	{
		puts("Error! opening file");
 	 	 return FAILED;
	}
	else
	{
		int c = fgetc(fptr);
		status = fputs(str + 1, temp); /*Append to first line of file without '>' char */
		
		if (EOF == status)
		{
			puts("Error: prepend text to the file");
			return FAILED;
		}
		
		while (EOF != c)
		{
			 fputc(c, temp);
			 c = fgetc(fptr);
		}
	
		fclose(fptr);
		fclose(temp);
		
		c = rename("temp.txt",fname);
		
		if (-1 == c )
		{
			puts("Error: prepend text to the file");
			return FAILED;
		}
	}
	return OK;
}

/*********************************************************************************/

static int Remove(const char *str, const char *fname)
{
	int ret = remove(fname);
   
   	UNUSED(str);
   	
   	if (FAILED == ret) 
   	{
    	puts("File deleted successfully");
  	}
  	else 
   	{
   	   puts("Error: unable to delete the file");
   	   
   	   return FAILED;
   	}
   	return OK;
}

/*********************************************************************************/

static int Count(const char *str, const char *fname)
{
	int rows = 0;
	int c = 0;
	FILE *fptr = fopen(fname, "r");
	
	UNUSED(str);
	
	if (NULL != fptr)
	{
		while (EOF != c)
		{
			c = fgetc(fptr);
			
			if ('\n' == c)
			{
				rows++;
			}
		} 
		printf("Number of rows in file %s is: %d\n", fname, rows);
		
		fclose(fptr);	
	}
	else
	{
		puts("Error: unable to open the file");
		return FAILED;
	}
	return OK;
}

/*********************************************************************************/

static int Exit(const char *str, const char *fname)
{
	UNUSED(str);
	UNUSED(fname);
	
	puts("Bye!");
	exit(OK);
	return OK;
}

/*********************************************************************************/

int Compare(const char *cmd, const char *cmd_to_match)
{
	return ( 0 == strcmp(cmd, cmd_to_match));
}

/********************************************************************************/

static int CompareAppend(const char *cmd, const char *cmd_to_match)
{
	UNUSED(cmd);
	UNUSED(cmd_to_match);
	return 1;
}

/********************************************************************************/

static int ComparePrepend(const char *cmd, const char *cmd_to_match)
{
	UNUSED(cmd_to_match);
	return (*cmd_to_match == *cmd);
}

/********************************************************************************/
	
int main(int argc, char *argv[])
{

	struct cmd
	{
		const char *cmd_to_match;
		int (*Compare)(const char *, const char *);
		int (*Operate)(const char *, const char *);
	};
	
	struct cmd commands[5] ={{"-exit\n",Compare, Exit},
							 {"-count\n", Compare, Count},
							 {"-remove\n", Compare, Remove},
						 	 {"<", ComparePrepend, Prepend},
						 	 {"", CompareAppend, Append}};
	
	
	char *file_name = argv[1];
	char cmd[MAX_INPUT] ={0};
	int i = 0;
	
	UNUSED(argc);
	
	while (OK)
	{
		puts("\nPlease insert a command:");
		
		fgets(cmd, MAX_INPUT, stdin);
		
		if (NULL != cmd)
		{
			for (i = 0; i < ARRAY_SIZE; i++)
			{
				if ((commands[i].Compare)(cmd, commands[i].cmd_to_match))
				{
					(*commands[i].Operate)(cmd, file_name);
					break;
				}
			}
		}
		
		else
		{
			puts("Error: Invalid command");
		}
	}

	return OK;
}	
