#include <stdio.h>
#include <unistd.h>


char c = 'd';

double SumDivision(int n1, int n2)
{
	int d = 6;
	return (n1 + n2)/d;
}

