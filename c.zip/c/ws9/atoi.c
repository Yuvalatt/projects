#include <stdio.h>
#include <stdlib.h> /* EXIT_SUCCESS */
#include <string.h> /* strlen() */
#include <assert.h> /* for testing */
#include <ctype.h> /* isalnum() */

int Atoi(const char *nptr, int base);
static void TestAtoi(void);

/*******************************************************************************************/
int main()
{
	TestAtoi();
	return EXIT_SUCCESS;
}

/*******************************************************************************************/
/* Psudo- code: Converting from string to int.
 1. scan from start to end.
 2. for each char:  a. check if alphanumeric, if not- return -1.
 					b. chack if Uppercase letter- save digit as char -'A' + 10
 					c. chack if lowercase letter- save digit as char -'a' + 10
 					d. if char is numeric save it as char - '0' 
 3. num += digit, num = (num * base) */ 
/*******************************************************************************************/    

int Atoi(const char *nptr, int base)
{	
	const char *end = nptr + strlen(nptr) - 1; /* Define a pointer to the end of array */
	int digit = 0;
	int num = 0;
	
	assert((2 <= base) && (36 >= base));
	assert(nptr);
	
	while (nptr <= end)
	{
		/* Chack range of char and save its matching numeric value */	
		
		if ((*nptr >= 'A') && (*nptr <= 'A' + base -10))  
		{
			digit = *nptr - 'A' + 10;  
		}		
		else if ((*nptr >= 'a') && (*nptr <= 'a' + base -10))
		{
			digit = *nptr - 'a' + 10; 
		}
		else if ((*nptr >= '0') && (*nptr <= '0' + base))
		{
			digit = *nptr - '0';
		}
		else
		{
			return -1;
		}
			num = (num * base) + digit;
	 		nptr++;	
	}
	 
	return (num);
}

/*******************************************************************************************/

static void TestAtoi(void)
{
	const char *str= "1100";
	const char *str1= "11a";
	const char *str2= "f";
	const char *str3= "f%&f*f";
	
	printf("%d\n", Atoi(str, 2));
	printf("%d\n", Atoi(str1, 16));
	printf("%d\n", Atoi(str2, 16));
	printf("%d\n", Atoi(str3, 5));
	
	assert(8 == Atoi("1000", 2));
	assert(282 == Atoi("11A", 16));
	assert(888 == Atoi("888", 10));
	assert(0 == Atoi("0", 15));
	
	puts("SUCCESS - Atoi base 10");
	
}
