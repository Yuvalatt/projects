#include <stdio.h>
#include <stdlib.h> /* EXIT_SUCCESS */
#include <string.h> /* strlen */
#include <ctype.h>  /* isdigit() */
#include <assert.h> /* for testing */

#define BASE 10

char * itoa(int value, char *str, int base);
static void TestItoa(void);

/*******************************************************************************************/

int main()
{
	TestItoa();
	return EXIT_SUCCESS;
}

/*******************************************************************************************/

/* psudo-code:  1. save a flag if value is negative and set value to -value
				2. Add chars to string from end to start.
					save each digit of value as a char in str
				3. find next digit until value is 0.
				4. if flag is TRUE add '-' at the beggining of str*/

char * Itoa(int value, char *str, int base)
{	
	 char *str_runner = str + strlen(str) - 1;
	 int flag = 0; 
	 if (value < 0)
	 {
	 	value = -value;
	 	flag = 1;
	 }
	 
	 while (0 < value)
	 {
	 	*str_runner = (value % base) + '0';
	 	--str_runner;
	 	value /= base;
	 }
	 
	if (1 == flag)
	 {
	 	*str_runner = '-';
	 }
	 
	return str;
	
}

/*******************************************************************************************/

static void TestItoa(void)
{
	char str[11] = "0000000000";
	char str2[]="00000";
	char str3[]="0";
	/*char str4[]="67&*8";*/
	
	assert(0 == strcmp("-245698795", Itoa(-245698795, str, BASE)));
	assert(0 == strcmp("12345", Itoa(12345, str2, BASE)));
	assert(0 == strcmp("0", Itoa(0, str3, BASE)));
	/*assert(0 == Itoa(0, str4, BASE));*/
	
	puts("SUCCESS - Itoa base 10");
	
}

