#include <stdio.h>
#include <stdlib.h> /* EXIT_SUCCESS */
#include <assert.h> /* for testing */
#include <string.h> /* for testing - strcmp */

char * itoa(int value, char *str, int base);
static void TestItoa(void);

/*******************************************************************************************/

int main()
{
	TestItoa();
	return EXIT_SUCCESS;
}

/*******************************************************************************************

 Psudo- code: Converting from int to string.
 1. scan from end to start. Assuming returned str is in max size 11.
 2. for each char:  a. check if last digit is in range of base.
 					b. if digit is more than 9 - save its matching ASCII character
 					c. if digit is more than 9 - save its matching ASCII num
3. Handle case value is 0.
 
********************************************************************************************/

char * Itoa(int value, char *str, int base)
{	
	int ch = 0;
	char *str_runner = str;
	
	assert(str);
	assert((base >= 2) && (base <= 36));
	
	*(str_runner + 10) = '\0';
	str_runner = str_runner + 9; /* promote str_runner to the end of str */
	
	if (0 == value) /* Handle case of 0 value */
	{
		*str_runner = '0';
		--str_runner;	
	}
	
	while (0 < value)
	{
		ch = (value % base); 
		
		if (ch > base) /* Check validity of last digit */
		{
			return NULL;
		}
		
		if (ch > 9)
		{
			*str_runner = ch + 'A' - 10;	
		}
		else
		{
			*str_runner = ch + '0';
	 	}
	 	--str_runner;
	 	value /= base;
	}
	 
	return (str_runner + 1);
	
}

/*******************************************************************************************/

static void TestItoa(void)
{	
	char str[11] = {0};
	
	printf("%s\n", Itoa(8, str, 2));
	printf("%s\n", Itoa(282, str, 16));
	printf("%s\n", Itoa(12, str, 2));
	printf("%s\n", Itoa(888, str, 10));
	printf("%s\n", Itoa(0, str, 15));
	
	assert(0 == strcmp("1000", Itoa(8, str, 2)));
	assert(0 == strcmp("11A", Itoa(282, str, 16)));
	assert(0 == strcmp("888", Itoa(888, str, 10)));
	assert(0 == strcmp("0", Itoa(0, str, 15)));
	
	puts("SUCCESS - Itoa Base");
	
}

