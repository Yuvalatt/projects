#include <stdio.h>
#include <stdlib.h> /*EXIT_SUCCESS*/
#include <string.h> /*strcmp and memcpy */
#include <assert.h> /*for testing*/

#define WORD_SIZE 8

typedef size_t word_t;

void * Memcpy(void *dest, const void *src, size_t n);
void TestMemcpy(void); 

/*******************************************************************************************/

int main()
{
	TestMemcpy();
	return EXIT_SUCCESS;
}

/*******************************************************************************************/

/* psudo-code:  0. Define pointers of type char and type word to both src and dest.
				1. Check if address of dest is aligned (divided by 8)
				2. If not aligned- copy chars from src to dest byte by byte n times (until address is aligned).
				3. If aligned- copy words from src to dest as many as possible.
				4. Copy chars from src to dest byte by byte remaining of n times. */
				
void * Memcpy(void *dest, const void *src, size_t n)
{	
	char *dest_runner = dest;
	word_t *word_dest = dest;
	
	const char *src_runner = src;
	const word_t *word_src = src;
	
	while ((0 != ((word_t)src_runner % WORD_SIZE)) && (n > 0))
	{
		*dest_runner = *(char *)(src_runner);
		dest_runner++;
		src_runner++;
		n--;
	}
	
	word_src = (word_t *)src_runner;
	word_dest = dest;
	
	while (n >= WORD_SIZE)             /*address is divided by 8*/
	{	
		*word_dest = *(word_t *)(word_src);
		word_src++; 
		word_dest++;                  /* promote s in WORD_SIZE */
		n -= WORD_SIZE;
	}
	
	src_runner = (char *)word_src;
	dest_runner = (char *)word_dest;
	
	while (n > 0)                   /*for last padding if needed*/
	{
		*dest_runner = *(char *)(src_runner);
		dest_runner++;
		src_runner++;
		n--;
	}	
	return dest;
}

/*******************************************************************************************/


void TestMemcpy(void)
{
	char dest[] = "abcdefghijttttttk!";
	char src[] = "12345678**1234!";
	char dest_c[] = "abcdefghijttttttk!";
	char src_c[] = "12345678**1234!";
	
	char dest1[] = "abcdefghijttttttk!";
	char src1[] = "12345678**1234!";
	char dest1_c[] = "abcdefghijttttttk!";
	char src1_c[] = "12345678**1234!";
	
	char dest2[] = "abcdefghijttttttk!";
	char src2[] = "12345678**1234!";
	char dest2_c[] = "abcdefghijttttttk!";
	char src2_c[] = "12345678**1234!";
	
	char dest3[] = "abcdefghijttttttk!";
	char src3[] = "12345678**1234!";
	char dest3_c[] = "abcdefghijttttttk!";
	char src3_c[] = "12345678**1234!";
	
	char dest4[] = "abcdefghijttttttk!";
	char src4[] = "12345678**1234!";
	char dest4_c[] = "abcdefghijttttttk!";
	char src4_c[] = "12345678**1234!";
	
/* Test1 - n < 8 */	
	Memcpy(dest, src, 4);
	printf("%s\n", dest);
	assert(0 == strcmp(Memcpy(dest1, src1, 4), memcpy(dest1_c, src1_c, 4)));

/* Test2 - n > 8 */	
	Memcpy(dest1, src1, 4);
	printf("%s\n", dest1);
	assert(0 == strcmp(Memcpy(dest, src, 4), memcpy(dest_c, src_c, 4)));	

/* Test3 - address not aligned, n < 8 */
	Memcpy(dest2 + 2 , src2, 4);
	printf("%s\n", dest2);
	assert(0 == strcmp(Memcpy(dest2 + 2, src2, 4), memcpy(dest2_c + 2, src2_c, 4)));

/* Test4 - address not aligned, n > 8 */
	Memcpy(dest3 + 2 , src3, 10);
	printf("%s\n", dest3);
	assert(0 == strcmp(Memcpy(dest3 + 2, src3, 10), memcpy(dest3_c + 2, src3_c, 10)));
	
/* Test 5-  n = 0 */
	Memcpy(dest4 , src4, 0);
	printf("%s\n", dest4);
	assert(0 == strcmp(Memcpy(dest4 , src4, 0), memcpy(dest4_c, src4_c, 0)));
}
