#include <stdio.h>
#include <stdlib.h> /*EXIT_SUCCESS*/
#include <string.h> /*strcmp and memset*/
#include <assert.h> /*for testing*/

#define WORD_SIZE 8

typedef size_t word_t;

void * Memset(void *s, int c, size_t n);
word_t CreateWord(int c);

void TestMemset(void);

/*******************************************************************************************/

int main()
{
	TestMemset();
	return EXIT_SUCCESS;
}

/*******************************************************************************************/

/*Creating a word by copying first byte of int (casting to char) 8 times */
word_t CreateWord(int c)
{	
	int i = 0;
	word_t w = 0;
	for (i = 0; i < WORD_SIZE; i++)
	{
		w <<= 8; 
		w |= (char)c;
	}
	return w;
}

/*******************************************************************************************/

/* psudo-code:  1. Check if address of s is aligned (divided by 8)
				2. If not aligned- copy char c byte by byte to s n times (until address is aligned).
				3. If aligned- if n > 8 - create a word of int c, copy words to s as many as possible.
				4. Copy c byte by byte remaining of n times. */

void * Memset(void *s, int c, size_t n)
{	
	char *runner = s;
	word_t word = 0;
	
	while ((0 != ((word_t)s % WORD_SIZE)) && (n > 0))     /*check if memory address is aligned*/
	{
		*runner = (char)c;
		runner++;
		n--;
	}

	if (n >= WORD_SIZE) 
	{
		word = CreateWord(c);
		while (n >= WORD_SIZE)  	     /*have at least one word to copy*/
		{	
			*(word_t *)runner = word;
			runner += WORD_SIZE;        /* promoting s in WORD_SIZE */
			n -= WORD_SIZE;
		}
	}
		
	while (n > 0)                    /*for last padding if needed*/
	{
		*runner = (char)c;
		runner++;
		n--;
	}	
	return s;
}

/*******************************************************************************************/

void TestMemset(void)
{
	char str[] = "aaaaaaaaa!";
	char str_c[] = "aaaaaaaaa!";
	
	char str1[] = "bbbbbbbbbbbbbbbbbbbb!";
	char str1_c[] = "bbbbbbbbbbbbbbbbbbbb!";
	
	char str2[] = "cccccccccccccccccccccccccccccccccccccc!";
	char str2_c[] = "cccccccccccccccccccccccccccccccccccccc!";
	
	char str3[] = "ddddddddddddddddddddddddddddddddddddddd!";
	char str3_c[] = "ddddddddddddddddddddddddddddddddddddddd!";
	
	char str4[] = "wowwwwwwwwwwww!";
	char str4_c[] = "wowwwwwwwwwwww!";
	
/* Test1 - n < 8 */	
	Memset(str, '*', 2); 
	printf("%s\n", str);
	assert(0 == strcmp(Memset(str, '*', 2), memset(str_c, '*', 2)));
	
/* Test2 - n > 8 */	 
	Memset(str1, '*', 12);
	printf("%s\n", str1);
	assert(0 == strcmp(Memset(str1, '*', 12), memset(str1_c, '*', 12)));
	
/* Test3 - address not aligned, n < 8 */	
	Memset(str2 + 3,'*', 4);
	printf("%s\n", str2);
	assert(0 == strcmp(Memset(str2 + 3,'*', 4), memset(str2_c + 3,'*', 4)));
	
/* Test4 - address not aligned, n > 8  */	
	Memset(str3 + 2,'*', 17);
	printf("%s\n", str3);	
	assert(0 == strcmp(Memset(str3 + 2,'*', 17), memset(str3_c + 2,'*', 17)));	
	
/* Test5 -  n = 0 */	
	Memset(str4,'*', 0);
	printf("%s\n", str4);	
	assert(0 == strcmp(Memset(str4,'*', 0), memset(str4_c,'*', 0)));	
}

