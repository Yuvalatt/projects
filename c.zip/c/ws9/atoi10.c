#include <stdio.h>
#include <stdlib.h> /*EXIT_SUCCESS*/
#include <string.h> /*strlen*/
#include <assert.h> /*for testing*/

#define BASE 10

int Atoi(const char *nptr);
static void TestAtoi(void);

/*******************************************************************************************/

int main()
{
	TestAtoi();
	return EXIT_SUCCESS;
}

/*******************************************************************************************/
/* from string to int:
 1. scan from end to start.
 2. for each char- save int as char - '0'
 3. num += digit, num* = 10
 4. check first char - equal to '-'?
    if yes - update to (-num), else add last digit */

int Atoi(const char *nptr)
{	
	char *end = (char *)nptr + strlen(nptr) - 1;
	int digit = 0;
	int num = 0;
	int flag = 1;
	assert(nptr);
	
	if ('-' == *nptr)
	{
		flag = -1;
	}
	else
	{
		digit = *nptr - '0';
		num = (num * BASE) + digit;
	}
	 
	nptr++;
	while (nptr <= end)
	{
		digit = *nptr - '0';
		num = (num * 10) + digit;
	 	nptr++;
	}
	 
	return (flag * num);
}

/*******************************************************************************************/

static void TestAtoi(void)
{
	const char *str= "-245698795";
	const char *str1= "12999";
	const char *str2= "0";
	
	assert(-245698795 == Atoi(str));
	assert(12999 == Atoi(str1));
	assert(0 == Atoi(str2));
	
	puts("SUCCESS - Atoi base 10");
	
}
