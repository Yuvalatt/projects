#include <stdio.h>
#include <stdlib.h> /* EXIT_SUCCESS */

#define CHARS_SIZE 256 
#define ARRAY_SIZE(a)(sizeof(a)/sizeof(a[0]))

static void ScanArray(const char arr[], int size, int chars[], int n);
static void PrintChars(int chars[]);

/*******************************************************************************************

 Psudo - code: Printing mutual chars of first and second array that not found in
				 third array, without duplicates.
				 
				 1. Define chars_array in size 257. Initialize with zeros.
				 	each index from 0-256 represent a char.
				 	
				 2. Scan first array: For each char check- if chars_array[char] is 0 increase by 1.
				 	Scan second array: For each char check- if chars_array[char] is 1 increase by 1.
				 	Scan third array: For each char check- if chars_array[char] is 2 increase by  1.
				 	
				 3.	Scan chars_array, if chars_array[i] == 2 print char i. 

*******************************************************************************************/
	
int main()
{
	const char arr1[] = {'a','g','5','9','$','0','8','T','k','L','L', '9'};
	const char arr2[] = {'X','k', 'u', '5', '9', '$', '0', '7', 'b', '2', 'L'};
	const char arr3[] = {'5', '*', 'L', '0', 'o', '4', 'm', 'M', ')','&'};
	
	int chars[CHARS_SIZE] = {0};
	
	ScanArray(arr1, ARRAY_SIZE(arr1), chars, 0);	
	ScanArray(arr2, ARRAY_SIZE(arr2), chars, 1);
	ScanArray(arr3, ARRAY_SIZE(arr3), chars, 2);

	PrintChars(chars);
	
	return EXIT_SUCCESS;
}

/*******************************************************************************************/    

static void ScanArray(const char arr[], int size, int chars[], int n)
{
	int i = 0;
	for (i = 0; i < size; i++)
	{
		if (n == chars[arr[i]])
		{
			chars[arr[i]] = (n + 1);
		}	
	}
}

/*******************************************************************************************/

static void PrintChars(int chars[])
{
	int i = 0;
	for (i = 0; i < CHARS_SIZE; i++)
	{
		if (2 == chars[i])
		{
			printf("%c", i);
		}
	}
	puts("");
}	
	
	
