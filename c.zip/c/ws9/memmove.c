#include <stdio.h>
#include <stdlib.h> /*EXIT_SUCCESS*/
#include <string.h> /* strcmp */
#include <assert.h> /*for testing*/

#define WORD_SIZE 8

typedef size_t word_t;

void * Memmove(void *dest, const void *src, size_t n);
void TestMemmove(void); 

void * Memcpy(void *dest, const void *src, size_t n);

/*******************************************************************************************/

int main()
{
	TestMemmove();
	return EXIT_SUCCESS;
}

/*******************************************************************************************/
				
void * Memmove(void *dest, const void *src, size_t n)
{	
	char *src_runner = (char *)src;
	char *dest_runner = (char *)dest;
	
	int distance = (char *)dest - (char *)src;
	int over = ((char *)src + n - (char *)dest);
	
	if ((over > 0) && (distance > 0)) /* Checking if src and dest overlap and dest > src */
	{
		dest_runner += distance;
		src_runner = dest;
		
		Memcpy(dest_runner, src_runner, over);  /* copy overlap bytes to end of dest */ 
		Memcpy(dest, src, distance);            /* copy start of src to the start of dest*/ 
	}
	else
	{
		 Memcpy(dest, src, n);
	}
	
	return dest;
}

/*******************************************************************************************/

void TestMemmove(void)
{
	char dest[] = "abcdefghijttttttk!";
	char dest1[] = "abcdefghijttttttk!";
	char src[] = "12345678**1234!";
	char src1[] = "12345678**1234!";
	char str2[] = "abcdefghijklmnopqrstuvwxyz";
	char str3[] = "abcdefghijklmnopqrstuvwxyz";
	char str4[] = "abcdefghijklmnopqrstuvwxyz";
	char str5[] = "abcdefghijklmnopqrstuvwxyz";
	
	assert(0 == strcmp(memmove(dest, dest + 8, 3), Memmove(dest1, dest1 + 8, 3)));		
	assert(0 == strcmp(memmove(src + 4, src, 8), Memmove(src1 + 4, src1, 8)));
	assert(0 == strcmp(memmove(str2, str2 + 8, 15), Memmove(str3, str3 + 8, 15)));
	assert(0 == strcmp(memmove(str4 + 8, str4, 15), Memmove(str5 + 8, str5, 15)));

	puts("SUCCESS - Memmove");
	
}


/*******************************************************************************************/

/* For implementation of memmove */

void * Memcpy(void *dest, const void *src, size_t n)
{	
	char *dest_runner = dest;
	word_t *word_dest = dest;
	
	const char *src_runner = src;
	const word_t *word_src = src;
	
	while ((0 != ((word_t)src_runner % WORD_SIZE)) && (n > 0))
	{
		*dest_runner = *(char *)(src_runner);
		dest_runner++;
		src_runner++;
		n--;
	}
	
	word_src = (word_t *)src_runner;
	word_dest = dest;
	
	while (n >= WORD_SIZE)             /*address is divided by 8*/
	{	
		*word_dest = *(word_t *)(word_src);
		word_src++; 
		word_dest++;                  /* promote s in WORD_SIZE */
		n -= WORD_SIZE;
	}
	
	src_runner = (char *)word_src;
	dest_runner = (char *)word_dest;
	
	while (n > 0)                   /*for last padding if needed*/
	{
		*dest_runner = *(char *)(src_runner);
		dest_runner++;
		src_runner++;
		n--;
	}	
	return dest;
}
