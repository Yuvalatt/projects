#include <stdio.h>
#include <stdlib.h> /* EXIT_SUCCESS */

#define IS_ENDIAN(x)((1 == *(short *)"\1") ? 1 : 0)

void EndianTest(void);


int main()
{
	EndianTest();
	return EXIT_SUCCESS;
}

void EndianTest(void)
{
	int num = 1; 
	
	puts("Test1:");
	(1 == *(char *)&num) ? puts("System is Big Endian.\n") : puts("System is Little Endian.\n");
	
	puts("Test2:");
	(1 == IS_ENDIAN(num)) ? puts("System is Big Endian.\n") : puts("System is Little Endian.\n");
}
