#include <stdio.h>
#include <assert.h>
#include <ctype.h> /* tolower() */
#include <string.h> /* strlen() */
#include <stdlib.h> /* EXIT_SUCCESS */





int main()
{
	char *buff;
	char * str="1234567";
	int arr[10]= {1,2,3,4,5,6,7,8,9,10};
	
	/*buff = (char *) malloc(8 * sizeof(char));
	strcpy(buff,str);
	
	printf("%c\n", *buff);
	free(buff);*/
	
	while(1)
	{
		puts("yyy");
	}
	
	return EXIT_SUCCESS;
}





