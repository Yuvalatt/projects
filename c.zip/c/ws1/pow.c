#include <stdio.h>
#include <stdlib.h> /*EXIT_SUCCESS*/
#include <math.h> /*for testing*/


/***************************************************************
 *  The program prints the power of 10 by a given exponant     *
 *                                                             *
 ***************************************************************/

double Pow10(int);
void CheckPow(int);


int main()
{
	CheckPow(3);
	CheckPow(-3);
	CheckPow(0);
	return EXIT_SUCCESS;
}




double Pow10(int exp)
{
	int i;
	double result = 1.0, base = 10.0;

/*If input is negative- change sign of the input, devide multiply*/
	if (exp < 0)
	{
		exp = -exp;
		base = 0.1;
	}

/*Calculation of 10 ^ exp*/
	for ( i = 0; i < exp; i++)
	{
		result *= base;
	}		
	return result;
}


/****** Testing *******/
void CheckPow(int num)
{
	printf("10^%d = %f\n", num, Pow10(num));

}
