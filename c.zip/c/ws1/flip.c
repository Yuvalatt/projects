#include <stdio.h>
#include <stdlib.h> /*EXIT_SUCCESS*/

/***************************************************************
 *      The program flips and prints a given number            *
 *                                                             *
 ***************************************************************/
 
int FlipNumber(int);
void CheckFlip();


int main()
{
	CheckFlip(12340);
	CheckFlip(-12340);
	CheckFlip(56005);
	CheckFlip(30022300);

	return EXIT_SUCCESS;
}

/*****  Gets an integer number ****/
int FlipNumber(int number)
{
	int ans = 0;	
/*****  Suming up the flipped number ****/
	while( 0 != number)
	{
		ans = ans * 10 + (number % 10);
		number /= 10;
	}
		
	return ans;
}

/*****  Testing   *****/
void CheckFlip(int x)
{
	printf("%d --> %d\n", x, FlipNumber(x));
}
