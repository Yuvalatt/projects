#include <stdio.h>
#include <stdlib.h> /*EXIT_SUCCESS*/


/***************************************************************************
 * The program swaps the location of two numbers & prints their values     *
 *                                                                         *
 ***************************************************************************/

void Swap(int, int);
void CheckSwap(int, int);

int main()
{
	CheckSwap(3,4);
	CheckSwap(-6,0);

	return EXIT_SUCCESS;
}


void Swap(int *num1, int *num2)
{
	int temp = *num1;
	*num1 = *num2;
	*num2 = temp;
}


void CheckSwap(int x, int y)
{
	printf("Before swaping:\n");
	printf("(%d,%d)\n", x, y);
	printf("After swaping:\n");
	Swap(&x, &y);
	printf("(%d,%d)\n", x, y);
}
