#include <stdio.h>
#include <stdlib.h> /* EXIT_SUCCESS */

/***************************************************************
 *  The program prints "Hello world" using hexadecimal input   *
 *                                                             *
 ***************************************************************/
 

void PrintHelloWorld()
{
	puts("\x22\x48\x65\x6c\x6c\x6f\x20\x77\x6f\x72\x6c\x64\x21\x22");
}

int main()
{
	PrintHelloWorld();	
	return EXIT_SUCCESS;
}
