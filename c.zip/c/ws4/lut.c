#include <stdio.h>
#include <stdlib.h> /*EXIT_SUCCESS*/

#define Esc 27
#define A 65
#define T 84	 
#define LUT_SIZE 265
#define Execute(c)(*lut[c])()


void IfElse(unsigned int c);
void SwitchCase(unsigned int c);
void LUT(unsigned int c);

void InitLUT(void);

void A_Run(void);
void T_Run(void);
void Escape(void);
void Empty(void);

static void(*lut[LUT_SIZE])(void) = {NULL};


int main()
{
	unsigned int ch = 0;
	system("stty -icanon -echo"); /*Get input from user without wating for ENTER key*/	
	
	while (Esc != ch)
	{
		puts("\nPlease enter a char. Enter 'Esc' to exit.");
		ch = getchar();	
		LUT(ch);
	}
	
	system("stty icanon echo");
	
	return EXIT_SUCCESS;
}


void IfElse(unsigned int c)
{
	if(T == c)
	{
		puts("T pressed\n");
	}
	
	else if(A == c)
	{
		puts("A pressed\n");
	}
	
	else if (Esc == c)
	{
		puts("Bye!\n");
	}
	else
	{
		puts("Please enter a 'A' or 'T'. enter 'Esc' to exit.");
	}	
}

void SwitchCase(unsigned int c)
{
	switch(c)
	{
		case T:
		{
			puts("T pressed");
			break;
		}
		case A:
		{
			puts("A pressed");
			break;
		}
		case Esc:
		{
			puts("Bye!");
			break;
		}
		default:
		{
			puts("Please enter a 'A' or 'T'. enter 'Esc' to exit.");
		}
	}	
}

void LUT(unsigned int c)
{
 	InitLUT();
 	Execute(c);			
}

void InitLUT(void)
{
	int i;
	for (i=0; i< LUT_SIZE; i++)
	{
		if(A == i)
		{
			lut[A]=&A_Run;
		}
		else if(T == i)
		{
			lut[T]=&T_Run;
		}
		else if(Esc == i)
		{
			lut[Esc]=&Escape;
		}
		else
		{
			lut[i]=&Empty;
		}
	}
}

void A_Run(void)
{
	puts("A pressed");
}

void T_Run(void)
{
	puts("T pressed");
}

void Escape(void)
{
	puts("Bye!");
}

void Empty(void)
{
	return;
}
