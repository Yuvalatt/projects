#include <stdio.h>
#include <stdlib.h> /* EXIT_SUCCESS */

#define VARIABLE_SIZE(x)((size_t)(&x + 1) - (size_t)(&x))
#define INT_SIZE()((int *)0 + 1)
#define CHAR_SIZE()((char *)0 + 1)
#define FLOAT_SIZE()((float *)0 + 1)

int g1;
static int g2;
static int g3 = 0;
static int g4 = 8;

extern void bar();
					    						 
/********************************************************************************/

static void foo1()
{
	static int g5;
	int ll = 9;
}
	
/********************************************************************************/	

static void foo2()
{
	static int g6 = 0;
	static int g7 = 7;
}
	
/********************************************************************************/

int main(void) 
{

	char t = 8;
	printf("Size of variable t is %d bytes.\n", VARIABLE_SIZE(t));
	printf("Size of type int is %d bytes.\n", INT_SIZE());
	printf("Size of type char is %d bytes.\n", CHAR_SIZE());
	printf("Size of type float is %d bytes.\n", FLOAT_SIZE());
	
	return EXIT_SUCCESS;
}	
