#include <stdio.h>
#include <string.h> 
#include <stdlib.h> /* EXIT_SUCCESS */

#define UNUSED(x)(void)(x)
#define ARRAY_SIZE(arr)(sizeof(arr)/sizeof(arr[0]))


struct ws8;

typedef void (*print_func_t)(const struct ws8 *el);
typedef void (*add_func_t)(struct ws8 *el, int x);
typedef void (*free_func_t)(const struct ws8 *el);


struct ws8
{
	void *data; /* data union */
	print_func_t Print;
	add_func_t Add;
	free_func_t Free;
};

static void PrintInt(const struct ws8 *el);
static void PrintFloat(const struct ws8 *el);
static void PrintString(const struct ws8 *el);

static void AddInt(struct ws8 *el, int x);
static void AddFloat(struct ws8 *el, int x);
static void AddString(struct ws8 *el, int x);

static void FreeString(const struct ws8 *el);
static void Empty(const struct ws8 *el);

								 
/********************************************************************************/

static void PrintInt(const struct ws8 *el)
{
	printf("%d\n",*((int *)(&el->data)));
}

static void PrintFloat(const struct ws8 *el)
{
	printf("%f \n",*((float *)(&el->data)));
}


static void PrintString(const struct ws8 *el)
{
	printf("%s\n", (char *)(el->data));
}

/********************************************************************************/

static void AddInt(struct ws8 *el, int x)
{
	*((int *)(&el->data)) += x;
}


static void AddFloat(struct ws8 *el, int x)
{
	*((float *)(&el->data)) += x;
}

static void AddString(struct ws8 *el, int x)
{
	 static char buffer[11] = {0};
	 sprintf(buffer, "%d", x);
	 el-> data = realloc(el-> data, strlen(el-> data) + strlen(buffer) + 1);
	 strcat(el-> data, buffer);
}

/********************************************************************************/

static void FreeString(const struct ws8 *el)
{
	free(el->data);
}

static void Empty(const struct ws8 *el)
{
	UNUSED(el);
}

/********************************************************************************/

int main()
{
	int i = 0;
	struct ws8 array[] ={{NULL, &PrintInt, &AddInt, &Empty},
						{NULL, &PrintFloat, &AddFloat, &Empty},
						{NULL, &PrintString, &AddString, &FreeString}};
						  
	char *str = malloc(sizeof(char)*10);
	strcpy(str, "aaaaa");
	
	 				  
	*((int *)&array[0].data) = 3;
	*((float *)&array[1].data) = 3.54;
	array[2].data = str;

	for (i = 0; i < ARRAY_SIZE(array); i++)
	{
		(array[i].Print)(&array[i]);
		(array[i].Add)(&array[i],3);
		(array[i].Print)(&array[i]);
		(array[i].Free)(&array[i]);	
	}
	
	
	return (EXIT_SUCCESS);
}	
