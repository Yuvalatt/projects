#include <stdio.h>
#include <assert.h> /* for testing */
#include <string.h> /* for testing */
#include <stdlib.h> /* EXIT_SUCCESS */

#define ARRAY_SIZE 10

struct DateOfBirth
{
	size_t day;
	size_t month;
	size_t year;
};
	
struct Contact
{
	char f_name[50];
	char l_name[50];
	struct DateOfBirth dob;
	size_t ID;
};
								    
static void WriteData(struct Contact *arr);
static void ReadData(struct Contact *arr);
static void PrintData(const struct Contact *arr);
static void TestWriteRead(struct Contact *arr1, struct Contact *arr2);
						 
/********************************************************************************/

static void WriteData(struct Contact *arr)
{
	int written = 0;
	FILE *fp = fopen("cont.txt", "w");
	if (NULL == fp)
	{
 	   puts("Error: failed opening to file.");
	}
	else
	{
		written = fwrite(arr, sizeof(arr[0]), ARRAY_SIZE, fp);
		if (written != ARRAY_SIZE) 
		{
 	 	  puts("Error: failed writing to file.");
		}
		fclose(fp);
	}
}
	
/********************************************************************************/

static void ReadData(struct Contact *arr)
{
	int written = 0;
	FILE *fp = fopen("cont.txt", "r");
	if (NULL == fp)
	{
 	   puts("Error: failed opening to file.");
	}
	else
	{
		written = fread(arr, sizeof(arr[0]), ARRAY_SIZE, fp);
		if (written != ARRAY_SIZE) 
		{
 	   	puts("Error: failed reading the file.");
		}
		fclose(fp);
	}
}

/********************************************************************************/	
	
static void PrintData(const struct Contact *array)
{
	int i = 0;
	for(i = 0; i < ARRAY_SIZE ; i++)
	{
		printf("Full name: %s %s    ", array[i].f_name, array[i].l_name);
		printf("ID: %lu    ", array[i].ID);
		printf("Birth Date: %lu.%lu.%lu\n", array[i].dob.day, array[i].dob.month, array[i].dob.year);
	}
}

/********************************************************************************/	

static void TestWriteRead(struct Contact *arr1, struct Contact *arr2)
{
	int i = 0;
	for(i = 0; i < ARRAY_SIZE ; i++)
	{
		assert(strcmp(arr1[i].f_name, arr2[i].f_name) == 0);
		assert(strcmp(arr1[i].l_name, arr2[i].l_name) == 0);
		assert(arr1[i].dob.day == arr2[i].dob.day);
		assert(arr1[i].dob.month == arr2[i].dob.month);
		assert(arr1[i].dob.year == arr2[i].dob.year);
		assert(arr1[i].ID == arr2[i].ID);
		
	}
	 puts("SUCCESS - TestWriteRead");
}

/********************************************************************************/	

int main(void) 
{
	struct Contact array[ARRAY_SIZE] = {0};
	struct Contact contacts[]= {{"Yuval","Att", {10, 8, 1990}, 1111}, 
							    {"Hey","Joe", {21, 7, 1885}, 2222},
							    {"Amit","cohen", {3, 11, 1880}, 1233},
							    {"Nir","Perl", {9, 11, 1885}, 1234},
							    {"Yael","Milikowsky", {21, 2, 1958}, 1234},
							    {"Maayan","Levin", {2, 9, 1992}, 3434},
							    {"Dror","Attar", {14, 11, 1956}, 5555},
							    {"Gal","Gold", {5, 3, 1988}, 6666},
							    {"Shir","Amir", {18, 6, 1992}, 7777},
							    {"Dor","Giladi", {6, 7, 1990}, 8888}};				 
	WriteData(contacts);
	ReadData(array);
	PrintData(array);
	TestWriteRead(array, contacts);
	
	return EXIT_SUCCESS;
}	
