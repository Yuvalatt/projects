#include <stdio.h>
#include <assert.h>
#include <string.h> /*strlen()*/
#include <stdlib.h> /*EXIT_SUCCESS*/

int IsPalindrome(const char *str);
void IsPalindromeTest(void);


/* Program assumption - string str doesn't include spaces */
 
int IsPalindrome(const char *str)
{
	const char *last = str + strlen(str) -1;
	
	assert(NULL != str);
	
	while (last > str)
	{
		if (*str != *last)
		{
			return 0;
		}
		else
		{
			last--;
			str++;
		}
	}	
	return 1;
}

void TestIsPalindrome()
{
 	IsPalindrome("abba") ? printf("Wow it's a Palindrome!\n") : printf("Not a Palindrome!\n");
	IsPalindrome("aba") ? printf("Wow it's a Palindrome!\n") : printf("Not a Palindrome!\n");
	IsPalindrome("a a") ? printf("Wow it's a Palindrome!\n") : printf("Not a Palindrome!\n");
	IsPalindrome("a") ? printf("Wow it's a Palindrome!\n") : printf("Not a Palindrome!\n");
	IsPalindrome("atysf") ? printf("Wow it's a Palindrome!\n") : printf("Not a Palindrome!\n");
	IsPalindrome("abc eba") ? printf("Wow it's a Palindrome!\n") : printf("Not a Palindrome!\n");	
	IsPalindrome("NULL") ? printf("Wow it's a Palindrome!\n") : printf("Not a Palindrome!\n");
}


int main()
{
	TestIsPalindrome();
	return EXIT_SUCCESS;
}
