#include <stdio.h>
#include <assert.h>
#include <stdlib.h> /* EXIT_SUCCESS */
#include <string.h> /* strlen()    */


void BigAdd(char *num1, char *num2, char result[]);

int main()
{
	char n1[] = "1";
	char n2[] = "99999";
	static char res[22]; 
	BigAdd(n1, n2, res);
    puts(res);
	return EXIT_SUCCESS;
}

/*Psudo-code: 1. Check validation of input
	   		2. Locate longer number- using strlen()
	        3. Set a pointer to the end of each string
	        4. For each char sum up with the char below
	        5. set result to sum + carry, set carry to 0.
		       If result is over 10- set to (sum % 10) & save a carry of 1 
	           If not - set result to sum.
	        6.  At the end of short number scan (from rigth to left).
			    If carry is 1- concat 1 before long number
		    7.  Return long number as result */


void BigAdd(char *num1, char *num2, char *result)
{
	char *long_num = NULL;
	char *short_num = NULL;
	char *short_head = NULL; /* A pointer to the start of the shorter number */
	char *long_head = NULL;
	
	int sum = 0;
	int carry = 0;
	
	assert(num1 && num2);
 
	 if (strlen(num1) > strlen(num2))
		{ 		
			long_num = num1 + strlen(num1) - 1;		/* Define num1 as the longer number*/
			short_num = num2 + strlen(num2) - 1;
			long_head = num1;
			short_head = num2; 	
		}
	else
		{ 										
			long_num = num2 + strlen(num2) - 1;		/* Define num2 as the longer number*/
			short_num = num1 + strlen(num1) - 1;
			long_head = num2;
			short_head = num1;
		}
	
	result += strlen(long_head);
	*(result + 1) = '\0';
	
	while (long_num >= long_head) /* scans long number */
	{	 
		sum = 0;
		
		if (short_num < short_head) /* If short num ended- sum long number only */
		{
			sum = (*long_num - '0') + carry;
		}	  
		else 
		{
			sum	= (*long_num - '0') + (*short_num - '0') + carry;
		}
		
		carry = 0;
		
		if (sum >= 10) /* Update carry if needed */
		{
			carry = 1;
			sum -= 10;	
		}
		
		*result = sum + '0';
		result--; 
		
		short_num--;
		/*long_num--;*/
	}
		*result = carry + '0';		
}
