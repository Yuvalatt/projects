#include <stdio.h>
#include <assert.h>
#include <stdlib.h> /*EXIT_SUCCESS*/

#define SEVEN_DEVISION(num)(num % 7 == 0 ? 1 : 0)

int IncludeSeven(int num);
void Boom(int start, int end);

int main()
{
	Boom(-7,17);
	Boom(-80,-62);
	Boom(10,77);
	Boom(0,6);

	return EXIT_SUCCESS;
}


int IncludeSeven(int num)
{
	int flag = 0;

	while (0 != num)
	{
		if (7 == num % 10 || -7 == num % 10)
		{
			flag = 1;
			break;
		}		
		num /= 10;
	}	
	return flag;
}


void Boom(int start, int end)
{
	int i = 0;
	
	assert(start <= end);
	
	for (i = start; i <= end ; i++)
		{ 	
			 (1 == IncludeSeven(i) || 1 == SEVEN_DEVISION(i) ? puts("Boom!") : printf("%d\n",i));
		}
}
