#include <stdio.h>
#include <assert.h>
#include <ctype.h> /*tolower()*/
#include <stdlib.h> /*EXIT_SUCCESS*/
#include <string.h> /*For TESTS*/


size_t Strlen(const char *s);
int Strcmp(const char *s1, const char *s2);
int Strcasecmp(const char *s1, const char *s2);
char *Strcpy(char *dest, const char *src);
char *Strchr( char *s, int c);
char *Strdup(const char *str);
char *Strcat(char *dest, const char *src);
char *Strncat(char *dest , const char *src, size_t n);
char *Strstr(const char *haystack, const char *needle);

void StrlenTest(void);
void StrcmpTest(void);
void StrcasecmpTest(void);
void StrcpyTest(void);
void StrncpyTest(void);
void StrchrTest(void);
void StrdupTest(void);
void StrcatTest(void);
void StrncatTest(void);
void StrstrTest(void);



/*
CR:
1. in Strlen, no need to use a counter, use arythmeticof pointers.
2. in Strcpy, it's easier to write *dest++ = *src++ (just for advice)
3.1. in Strncpy, use variables with more meaning than tmp.
3.2. in Strncpy, you don't need to use a counter i. (if you can avoid it, the better)
4. in Strdup, you don't need to write "else", it'll do it anyway if the compiler got that far
5. in Strcat, you could've write it all in one lign.
*/

int main()
{
	StrlenTest();
	StrcmpTest();
	StrcasecmpTest();
	StrcpyTest();
	StrncpyTest();
	StrchrTest();
	StrdupTest();
	StrcatTest();
	StrncatTest();
	StrstrTest();

return EXIT_SUCCESS;
}

/*Returns the length of a string*/
size_t Strlen(const char *s)
{
 	const char *start= s;
	assert(s);
	
	while ('\0' != *s)
			s++;		

	return (s - start);
}

/*Compares 2 strings values*/
int Strcmp(const char *s1, const char *s2)
{
	assert(s1 && s2);

	while (*s1 == *s2 && s1)
	{
		s1++;
		s2++;
	}

	return (*s1 - *s2);
}

/*Compares 2 strings values - not considering upper/lower case*/
int Strcasecmp(const char *s1, const char *s2)
{
	assert(s1 && s2);

	while (tolower(*s1) == tolower(*s2) && s1 )
	{
		s1++;
		s2++;
	}

	return (tolower(*s1) - tolower(*s2));
}

/*Copies a string src to a string dest, returns a pointer to dest*/
char *Strcpy(char *dest, const char *src)
{
	char *start = dest;
	
	assert(dest && src);
	
		while ('\0' != *src )
		{
			*dest = *src;
			src++;
			dest++;
		}
	*dest = '\0';

	return start;
} 

/*Copies a string src to string a dest (limited by n characters), returns a pointer to dest*/
char *Strncpy(char *dest, const char *src, size_t n)
{
	char *dest_ptr = dest;
	assert(dest && src);

	while ('\0' != *src)
	{
		if (n > 0)
			*dest = *src;
		else
			*dest = '\0';

		src++;
		dest++;
		n--;
	}
	
	return (dest_ptr);
}

 /***** UPDATE c='\0' ******/
/*Returns a pointer to the first accurance of char c in string s*/
char *Strchr( char *s, int c)
{
	assert(s);
	
	if ('\0' == c)
		{
			s = '\0';
			return s;
		}

	while( s && *s != c )
	    	s++;
	
	return ( (*s =='\0') ? NULL : s );
}

/*Returns a pointer to the start of a duplicate string*/

/*Psudo-code: 1. Assign a pointer for a duplicate string
			  2. copy str to a duplicate string 
			  3. Return a pointer to the start of the new_str*/

char *Strdup(const char *str)
{
	char *new_str;
	assert(str);
 	new_str= malloc(Strlen(str) + 1);	
	
	if (new_str == NULL)
		{	
			return NULL;
		}
	return Strcpy(new_str, str);	
}

/*Concatenates 2 strings*/

/*Psudo-code: 1. Override dest '\0' bit
			  2. Append src string to the end of dest 
			  3. Add '\0' bit at the end of dest
			  4. Return a pointer to start of dest*/

char *Strcat(char *dest , const char *src)
{		
	assert(dest && src);
	
	Strcpy(dest + Strlen(dest), src);

	return dest;	 
}

char *Strncat(char *dest , const char *src,  size_t n)
{	
	assert(dest && src);

	Strncpy(dest + Strlen(dest), src, n);
	*(dest + n) = '\0';
	
	return dest;
}

/*Locate a substring (needle) in a string (haystack)*/

/*Psudo-code: 1. Scan string haystack, promote haystack by 1
			  2. If char equals to char in needle, promote needle by 1
			  3. If end of needle - return location of needle
			  4. If not found- reutrn NULL */

char *Strstr(const char *haystack, const char *needle)
{
	const char *current_needle = needle;
	assert(haystack && needle);

	while ('\0' != *haystack)
	{
		if (*haystack == *current_needle)
		{
			current_needle++;
		}
		else 
		{
			haystack -= (current_needle - needle);
			current_needle = needle;
		}
		haystack++;
		
		if ('\0' == *current_needle )
		{
			return (char *)(haystack - (current_needle - needle));
		}	
	}
	return NULL;
}



/*** TESTS ****/
void StrlenTest()
{
	char str[]="Hey Youuuuuu!";
	char str1[]="\0";
	char str2[]="y1268\0sfgh";
	char str3[]="135 g";

	assert(Strlen(str) == strlen(str));
	assert(Strlen(str1) == strlen(str1));
	assert(Strlen(str2) == strlen(str2));
	assert(Strlen(str3) == strlen(str3));
	
	printf("SUCCESS - StrlenTest\n");
}

void StrcmpTest()
{
	char str1[]="abc";
	char str2[]="a\0b";
	char str3[]="cde";
	char str4[]="Cde";

	assert(Strcmp(str1,str2) == strcmp(str1,str2));
	assert(Strcmp(str1,str2) == strcmp(str1,str2));
	assert(Strcmp(str2,str3) == strcmp(str2,str3));
	assert(Strcmp(str3,str4) == strcmp(str3,str4));
	
	printf("SUCCESS - StrcmpTest\n");
}

void StrcasecmpTest()
{
	char str1[]="abc";
	char str2[]="ABc";

	assert(Strcmp(str1,str2) == strcmp(str1,str2));
	
	printf("SUCCESS - StrcasecmpTest\n");
}

void StrcpyTest()
{
	char source[200]="aaa";
	char dest[200]="bbb";

	assert(Strcpy(dest,source) == strcpy(dest,source));	
	printf("SUCCESS - StrcpyTest\n");
}

void StrncpyTest()
{
	char source1[200]="at";
	char dest[200]="bbytr";
	assert(Strncpy(dest,source1,1) == strncpy(dest,source1,1));	
	printf("SUCCESS - StrncpyTest\n");
}

void StrchrTest()
{

	char ch= 'A';
	char *s1="facintingcAAA!";
	
	assert(*(Strchr(s1,ch)) ==  *(strchr(s1,ch)));
	printf("SUCCESS - StrchrTest\n");
}

void StrdupTest()
{
	const char *source = "So exciting!!";
	assert(strcmp(Strdup(source), source) == 0);
	printf("SUCCESS - StrdupTest\n");
}

void StrcatTest()
{
	char str1[100] = "Hi";
	char *str2 = "you";
	assert(strcmp(Strcat(str1,str2) , strcat(str1,str2)) == 0);
	printf("SUCCESS - StrcatTest\n");
}

void StrncatTest()
{
	char str1[100] = "Hi";
	char *str2 = "you";
	assert(strcmp(Strncat(str1,str2,1) , strncat(str1,str2,1)) == 0);
	printf("SUCCESS - StrncatTest\n");
}

void StrstrTest()
{
	char *str1="Heyyou";
	char *str2="you";
	assert(strcmp(Strstr(str1,str2) , strstr(str1,str2)) == 0);
	printf("SUCCESS - StrstrTest\n");
}



