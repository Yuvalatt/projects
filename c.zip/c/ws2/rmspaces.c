#include <stdio.h>
#include <assert.h>
#include <string.h> /*strlen()*/
#include <stdlib.h> /*EXIT_SUCCESS*/

#define IS_BLANK(c) (( ' ' == c || '\t' == c) ? 1 :0)
#define TRUE 1

void RmSpaces(char *str);
void TestRmSpaces(void);

/*Psudo-code: 1. Define a pointer to the START and END of the string
			  3. Initialize a space counter
			  4. From START TO END check- if not a SPACE or TAB, copy char to original str & initialize space counter
			  5. If one space exactly and not first char of string, keep it- copy space to original str
				 If more than one space - skip it*/
				 				 
void RmSpaces(char *str)
{
	char *curr = str;
	char *end = str + strlen(str)-1;
  	int space_counter = 0;
 	int first_char = 1;
 	
	assert(str);
	
	while (curr <= end) 
		{
			if (TRUE == IS_BLANK(*curr)) /* Found a SPACE or a TAB */
			{
					space_counter++;
									
					if (1 == space_counter && 0 == first_char) /*If one space only & not first char- copy it. Else- skip it*/
					{
						*str = *curr;
						str++;
					}		
			}
			else /* If found a CHAR- copy it*/
			{
				space_counter = 0;
				*str = *curr;
				str++;
			}
			curr++;
			first_char = 0;
		}
	*str='\0';
}

void TestRmSpaces()
{
	char s2[] = "	c	!    ";
	char s3[] = "a		     b	 	c d e     fg!";
	char s4[] = "abcd 		ef	g!";
	char s5[] = "                   ";
	
	RmSpaces(s2);
	RmSpaces(s3);
	RmSpaces(s4);
	RmSpaces(s5);

	printf("%s\n", s2);
	printf("%s\n", s3);
	printf("%s\n", s4);
	printf("%s", s5);
}

int main()
{
	TestRmSpaces();
	return EXIT_SUCCESS;
}
