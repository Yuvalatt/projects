#include <stdio.h>
#include <assert.h>
#include <stdlib.h> /*EXIT_SUCCESS*/

void PtrSwap(int **first_ptr, int **second_ptr);
void TestPtrSwap(int num1, int num2);


void PtrSwap(int **first_ptr, int **second_ptr)
{
	int *temp = *first_ptr;
	*first_ptr = *second_ptr;
	*second_ptr = temp;
} 


void TestPtrSwap(int num1, int num2)
{
	int *pt1 = &num1;
	int *pt2 = &num2;

	int **p1 = &pt1; 
	int **p2 = &pt2;
	
	printf("Before swap numbers order is (%d,%d)\n",**p1, **p2);   
	PtrSwap(p1,p2);
	
	printf("After swap numbers order is (%d,%d)\n",**p1, **p2); 
	assert((**p1 == num2) && (**p2 == num1));
}

int main()
{
	TestPtrSwap(3,4);
	return EXIT_SUCCESS;
}

