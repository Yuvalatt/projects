#include <stdio.h>
#include <assert.h>
#include <stdlib.h>



int main()
{

	size_t i = 3;
	size_t arr[] = {0,1,2,3,4,5};
	printf("%lu\n", i[arr]);


return EXIT_SUCCESS;

}

